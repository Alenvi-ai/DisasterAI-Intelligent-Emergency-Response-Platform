import { initializeApp } from 'firebase/app';
import {
  getAuth,
  GoogleAuthProvider,
  signInWithPopup,
  signOut as firebaseSignOut,
  type User,
} from 'firebase/auth';
import {
  doc,
  getDoc,
  getDocFromServer,
  getFirestore,
  serverTimestamp,
  setDoc,
  updateDoc,
} from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';
import type { HospitalAlert, Incident, UserRole } from '../types/disaster';

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null
): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo:
        auth.currentUser?.providerData?.map((provider) => ({
          providerId: provider.providerId,
          email: provider.email,
        })) || [],
    },
    operationType,
    path,
  };
  console.error('Firestore Error:', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

export async function testFirestoreConnection(): Promise<void> {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.error('Please check your Firebase configuration.');
    }
  }
}

export async function signInWithGooglePopup() {
  return signInWithPopup(auth, googleProvider);
}

export async function signOutFirebase() {
  return firebaseSignOut(auth);
}

export async function ensureUserProfile(
  firebaseUser: User,
  preferredRole?: UserRole
): Promise<{ role: UserRole; city: string; displayName: string }> {
  const userPath = `users/${firebaseUser.uid}`;
  const isBootstrappedAdmin =
    firebaseUser.email?.toLowerCase() === 'jawadali0936@gmail.com' &&
    firebaseUser.emailVerified;

  let role: UserRole = isBootstrappedAdmin ? 'Administrator' : 'Citizen';
  let city = 'Karachi';
  const displayName = (firebaseUser.displayName || 'DisasterAI User').slice(0, 120);

  try {
    const snap = await getDoc(doc(db, 'users', firebaseUser.uid));
    if (snap.exists()) {
      const data = snap.data();
      role = (data.role as UserRole) || role;
      city = (data.city as string) || city;
      if (isBootstrappedAdmin && preferredRole && preferredRole !== role) {
        await updateDoc(doc(db, 'users', firebaseUser.uid), {
          role: preferredRole,
          updatedAt: serverTimestamp(),
        });
        role = preferredRole;
      }
    } else {
      const targetRole: UserRole = isBootstrappedAdmin
        ? preferredRole || 'Administrator'
        : 'Citizen';
      await setDoc(doc(db, 'users', firebaseUser.uid), {
        uid: firebaseUser.uid,
        displayName,
        role: targetRole,
        city,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      role = targetRole;

      await setDoc(doc(db, 'users', firebaseUser.uid, 'private', 'info'), {
        uid: firebaseUser.uid,
        email: firebaseUser.email || 'unknown@disasterai.pk',
        updatedAt: serverTimestamp(),
      });
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, userPath);
  }

  return { role, city, displayName };
}

export async function persistIncidentToFirestore(incident: Incident): Promise<void> {
  if (!auth.currentUser || !auth.currentUser.emailVerified) return;
  const docId = incident.id;
  const path = `incidents/${docId}`;
  try {
    await setDoc(doc(db, 'incidents', docId), {
      incidentCode: incident.incidentCode,
      reporterUid: auth.currentUser.uid,
      reporterName: incident.reporterName.slice(0, 120),
      contactPhone: (incident.contactPhone || '').slice(0, 32),
      category: incident.category,
      title: incident.title.slice(0, 160),
      description: incident.description.slice(0, 3000),
      city: incident.city.slice(0, 80),
      address: incident.address.slice(0, 300),
      lat: incident.lat,
      lng: incident.lng,
      peopleAffected: incident.peopleAffected,
      injuredCount: incident.injuredCount,
      trapped: incident.trapped,
      hazards: incident.hazards.slice(0, 10),
      imageUrls: incident.imageUrls
        .filter((u) => u.length < 4000)
        .slice(0, 6),
      status: 'Submitted',
      severityScore: incident.severityScore,
      priority: incident.priority,
      aiConfidence: incident.aiConfidence,
      aiExplanation: incident.aiExplanation.slice(0, 1500),
      aiRecommendedActions: incident.aiRecommendedActions.slice(0, 8),
      isPublicAlert: incident.isPublicAlert,
      isDemo: incident.isDemo,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function persistHospitalAlertToFirestore(alert: HospitalAlert): Promise<void> {
  if (!auth.currentUser || !auth.currentUser.emailVerified) return;
  const docId = alert.id;
  const path = `hospital_alerts/${docId}`;
  try {
    await setDoc(doc(db, 'hospital_alerts', docId), {
      incidentId: alert.incidentId,
      incidentCode: alert.incidentCode,
      hospitalId: alert.hospitalId,
      hospitalName: alert.hospitalName.slice(0, 160),
      distanceKm: Math.max(0, Number(alert.distanceKm) || 0),
      status: alert.status,
      firstAidEtaMinutes: Math.max(0, Math.min(1440, Math.round(alert.firstAidEtaMinutes || 5))),
      notifiedByUid: auth.currentUser.uid,
      notes: (alert.notes || '').slice(0, 500),
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}
