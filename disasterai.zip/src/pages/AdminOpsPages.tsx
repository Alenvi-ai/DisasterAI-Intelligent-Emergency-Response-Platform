import React, { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import {
  AlertTriangle,
  Bell,
  CheckCheck,
  Package,
  Plus,
  RotateCcw,
  Shield,
  Truck,
  Users,
} from 'lucide-react';
import { PortalShell } from '../components/layout/AppShells';
import { EmergencyMap } from '../components/map/EmergencyMap';
import { PriorityBadgeText, StatusText } from '../components/ui/DisasterPrimitives';
import { useDisaster } from '../context/DisasterContext';
import type { ResourceCategory } from '../types/disaster';

export const AdminRescueTeamsPage: React.FC = () => {
  const { teams, incidents } = useDisaster();
  const [typeFilter, setTypeFilter] = useState('All');

  const filteredTeams = useMemo(
    () => teams.filter((t) => typeFilter === 'All' || t.teamType === typeFilter),
    [teams, typeFilter]
  );

  return (
    <PortalShell portal="admin" breadcrumb="Rescue Teams">
      <div className="space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-xl font-display font-bold text-white">Rescue Teams Registry</h1>
            <p className="text-xs text-[#94A3B8] mt-1">
              Specialized medical, fire, flood, and USAR units staged across Karachi.
            </p>
          </div>
          <select
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value)}
            className="px-3 py-2 rounded-lg bg-[#091426] border border-white/10 text-xs text-white"
          >
            <option value="All">All Team Types</option>
            <option value="Medical Response Team">Medical Response Team</option>
            <option value="Fire & Rescue Team">Fire &amp; Rescue Team</option>
            <option value="Flood Rescue Team">Flood Rescue Team</option>
            <option value="Disaster Recovery Team">Disaster Recovery Team</option>
            <option value="General Emergency Team">General Emergency Team</option>
          </select>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {filteredTeams.map((team) => {
            const currentInc = team.currentIncidentId
              ? incidents.find((i) => i.id === team.currentIncidentId)
              : null;
            return (
              <div key={team.id} className="bg-[#091426] border border-[#1E3A5F] rounded-xl p-5 space-y-3">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="font-mono text-xs text-[#38BDF8]">
                      {team.teamCode} · {team.teamType}
                    </p>
                    <h2 className="text-base font-bold text-white mt-0.5">{team.name}</h2>
                  </div>
                  <StatusText status={team.status} />
                </div>

                <div className="grid grid-cols-2 gap-3 text-xs text-[#94A3B8]">
                  <div>
                    Leader: <span className="text-white">{team.leaderName}</span>
                  </div>
                  <div>
                    Contact: <span className="font-mono text-white">{team.contactNumber}</span>
                  </div>
                  <div>
                    Members: <span className="font-mono text-white">{team.memberCount}</span>
                  </div>
                  <div>
                    Completed: <span className="font-mono text-white">{team.incidentsHandled}</span>
                  </div>
                </div>

                <p className="text-xs text-[#D9EEFF]">Vehicle: {team.vehicleInfo}</p>
                <p className="text-xs text-[#94A3B8]">
                  Equipment: {team.equipment.join(' · ')}
                </p>

                {currentInc && (
                  <div className="pt-2 border-t border-white/10 flex items-center justify-between text-xs">
                    <span className="text-[#FFD43B]">Active on {currentInc.incidentCode}</span>
                    <Link to={`/admin/incidents/${currentInc.id}`} className="text-[#38BDF8] hover:underline">
                      View Incident
                    </Link>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </PortalShell>
  );
};

export const AdminAssignmentsPage: React.FC = () => {
  const { assignments } = useDisaster();

  return (
    <PortalShell portal="admin" breadcrumb="Team Assignments">
      <div className="space-y-5">
        <div>
          <h1 className="text-xl font-display font-bold text-white">Rescue Dispatch Assignments</h1>
          <p className="text-xs text-[#94A3B8] mt-1">
            Live synchronization of team acceptances, en-route status, and field progress notes.
          </p>
        </div>

        <div className="bg-[#091426] border border-[#1E3A5F] rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#071A33] border-b border-white/10 text-[#94A3B8]">
                <tr>
                  <th className="py-3 px-4 font-medium">Incident</th>
                  <th className="py-3 px-4 font-medium">Rescue Team</th>
                  <th className="py-3 px-4 font-medium">Priority</th>
                  <th className="py-3 px-4 font-medium text-right">Distance</th>
                  <th className="py-3 px-4 font-medium text-right">ETA</th>
                  <th className="py-3 px-4 font-medium">Status</th>
                  <th className="py-3 px-4 font-medium">Progress Notes</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {assignments.map((asg) => (
                  <tr key={asg.id} className="hover:bg-white/[0.02]">
                    <td className="py-3 px-4 whitespace-nowrap">
                      <Link to={`/admin/incidents/${asg.incidentId}`} className="font-mono text-[#38BDF8] hover:underline">
                        {asg.incidentCode}
                      </Link>
                      <p className="text-white truncate max-w-[200px]">{asg.incidentTitle}</p>
                    </td>
                    <td className="py-3 px-4 text-white whitespace-nowrap">{asg.teamName}</td>
                    <td className="py-3 px-4 whitespace-nowrap">
                      <PriorityBadgeText priority={asg.incidentPriority} />
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums text-[#D9EEFF]">
                      {asg.distanceKm} km
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums text-[#FFD43B]">
                      {asg.etaMinutes} min
                    </td>
                    <td className="py-3 px-4 whitespace-nowrap">
                      <StatusText status={asg.status} />
                    </td>
                    <td className="py-3 px-4 text-[#94A3B8] max-w-xs truncate">
                      {asg.progressNotes}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </PortalShell>
  );
};

export const AdminResourcesPage: React.FC = () => {
  const { resources, incidents, teams, updateResource, createResource } = useDisaster();
  const [showAdd, setShowAdd] = useState(false);
  const [name, setName] = useState('');
  const [category, setCategory] = useState<ResourceCategory>('Medical Kit');
  const [quantity, setQuantity] = useState(10);
  const [locationName, setLocationName] = useState('Karachi Central Depot');

  const lowStockItems = useMemo(
    () => resources.filter((r) => r.availability === 'Low Stock' || r.availability === 'Unavailable'),
    [resources]
  );

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    await createResource({ name, category, quantity, locationName });
    setName('');
    setShowAdd(false);
  };

  return (
    <PortalShell portal="admin" breadcrumb="Resources & Fleet">
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-xl font-display font-bold text-white">Emergency Resource &amp; Fleet Inventory</h1>
            <p className="text-xs text-[#94A3B8] mt-1">
              Track ambulances, fire tenders, flood boats, life jackets, medical kits, and shelters.
            </p>
          </div>
          <button
            type="button"
            onClick={() => setShowAdd((v) => !v)}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-[#168BFF] hover:bg-[#38BDF8] hover:text-[#071A33] text-white text-xs font-semibold whitespace-nowrap shrink-0"
          >
            <Plus className="w-4 h-4" />
            Add Resource
          </button>
        </div>

        {lowStockItems.length > 0 && (
          <div className="bg-[#091426] border border-[#FFD43B]/45 rounded-xl p-4 flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-[#FFD43B] shrink-0 mt-0.5" />
            <div className="text-xs">
              <p className="font-bold text-[#FFD43B]">Low-Stock Resource Alerts ({lowStockItems.length})</p>
              <p className="text-[#D9EEFF] mt-1">
                {lowStockItems.map((r) => `${r.name} (${r.availableQuantity}/${r.quantity})`).join(' · ')}
              </p>
            </div>
          </div>
        )}

        {showAdd && (
          <form onSubmit={handleAdd} className="bg-[#091426] border border-[#38BDF8]/40 rounded-xl p-5 grid grid-cols-1 sm:grid-cols-4 gap-3 items-end">
            <div>
              <label className="block text-xs text-[#94A3B8] mb-1">Resource Name</label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g., Trauma Stretchers"
                className="w-full px-3 py-2 rounded-lg bg-[#071A33] border border-white/15 text-xs text-white"
              />
            </div>
            <div>
              <label className="block text-xs text-[#94A3B8] mb-1">Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as ResourceCategory)}
                className="w-full px-3 py-2 rounded-lg bg-[#071A33] border border-white/15 text-xs text-white"
              >
                <option value="Ambulance">Ambulance</option>
                <option value="Fire Truck">Fire Truck</option>
                <option value="Rescue Vehicle">Rescue Vehicle</option>
                <option value="Boat">Boat</option>
                <option value="Life Jackets">Life Jackets</option>
                <option value="Medical Kit">Medical Kit</option>
                <option value="First Aid">First Aid</option>
                <option value="Rescue Equipment">Rescue Equipment</option>
                <option value="Emergency Shelter">Emergency Shelter</option>
                <option value="Medical Supplies">Medical Supplies</option>
              </select>
            </div>
            <div>
              <label className="block text-xs text-[#94A3B8] mb-1">Quantity &amp; Depot</label>
              <div className="flex gap-2">
                <input
                  type="number"
                  min={1}
                  value={quantity}
                  onChange={(e) => setQuantity(Math.max(1, Number(e.target.value)))}
                  className="w-20 px-2.5 py-2 rounded-lg bg-[#071A33] border border-white/15 text-xs font-mono text-white"
                />
                <input
                  type="text"
                  value={locationName}
                  onChange={(e) => setLocationName(e.target.value)}
                  className="flex-1 px-2.5 py-2 rounded-lg bg-[#071A33] border border-white/15 text-xs text-white"
                />
              </div>
            </div>
            <button
              type="submit"
              className="px-4 py-2 rounded-lg bg-[#22C55E] text-[#071A33] text-xs font-bold"
            >
              Save Resource
            </button>
          </form>
        )}

        <div className="bg-[#091426] border border-[#1E3A5F] rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#071A33] border-b border-white/10 text-[#94A3B8]">
                <tr>
                  <th className="py-3 px-4 font-medium">Code</th>
                  <th className="py-3 px-4 font-medium">Resource Name</th>
                  <th className="py-3 px-4 font-medium">Category</th>
                  <th className="py-3 px-4 font-medium">Location</th>
                  <th className="py-3 px-4 font-medium text-right">Available / Total</th>
                  <th className="py-3 px-4 font-medium">Status</th>
                  <th className="py-3 px-4 font-medium">Responsible Team</th>
                  <th className="py-3 px-4 font-medium text-right">Inventory Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {resources.map((res) => (
                  <tr key={res.id} className="hover:bg-white/[0.02]">
                    <td className="py-3 px-4 font-mono text-[#38BDF8] whitespace-nowrap">{res.resourceCode}</td>
                    <td className="py-3 px-4 font-medium text-white">{res.name}</td>
                    <td className="py-3 px-4 text-[#D9EEFF] whitespace-nowrap">{res.category}</td>
                    <td className="py-3 px-4 text-[#94A3B8]">{res.locationName}</td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums text-white">
                      {res.availableQuantity} / {res.quantity}
                    </td>
                    <td className="py-3 px-4 whitespace-nowrap">
                      <StatusText status={res.availability} />
                    </td>
                    <td className="py-3 px-4 text-[#D9EEFF] whitespace-nowrap">
                      {res.responsibleTeamName || 'Central Depot'}
                    </td>
                    <td className="py-3 px-4 text-right whitespace-nowrap space-x-2">
                      <button
                        type="button"
                        disabled={res.availableQuantity === 0}
                        onClick={() =>
                          updateResource(res.id, {
                            deltaAvailable: -1,
                            assignedIncidentId: incidents[0]?.id,
                            responsibleTeamId: teams[0]?.id,
                          })
                        }
                        className="px-2.5 py-1 rounded bg-[#12345A] hover:bg-[#168BFF] disabled:opacity-40 text-white"
                      >
                        Deploy 1
                      </button>
                      <button
                        type="button"
                        disabled={res.availableQuantity >= res.quantity}
                        onClick={() => updateResource(res.id, { deltaAvailable: 1, assignedIncidentId: '' })}
                        className="px-2.5 py-1 rounded border border-white/15 hover:bg-white/5 disabled:opacity-40 text-[#D9EEFF]"
                      >
                        Return 1
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </PortalShell>
  );
};

const PIE_COLORS = ['#168BFF', '#EF4444', '#FFD43B', '#38BDF8', '#22C55E', '#FB923C', '#A78BFA'];

export const AdminAnalyticsPage: React.FC = () => {
  const { incidents, teams, resources, demoMode } = useDisaster();
  const [dateRange, setDateRange] = useState<'today' | '7d' | '30d' | 'custom'>('7d');
  const [customStart, setCustomStart] = useState(() => {
    const d = new Date(Date.now() - 14 * 86400000);
    return d.toISOString().slice(0, 10);
  });
  const [customEnd, setCustomEnd] = useState(() => new Date().toISOString().slice(0, 10));

  const filteredIncidents = useMemo(() => {
    const now = Date.now();
    return incidents.filter((inc) => {
      const t = new Date(inc.createdAt).getTime();
      if (dateRange === 'today') return now - t <= 24 * 3600 * 1000;
      if (dateRange === '7d') return now - t <= 7 * 24 * 3600 * 1000;
      if (dateRange === '30d') return now - t <= 30 * 24 * 3600 * 1000;
      const s = new Date(customStart).getTime();
      const e = new Date(customEnd).getTime() + 86400000;
      return t >= s && t <= e;
    });
  }, [incidents, dateRange, customStart, customEnd]);

  // 1. Emergency Distribution (Pie)
  const categoryData = useMemo(() => {
    const map = new Map<string, number>();
    filteredIncidents.forEach((i) => map.set(i.category, (map.get(i.category) || 0) + 1));
    return Array.from(map.entries()).map(([name, value]) => ({ name, value }));
  }, [filteredIncidents]);

  // 2 & 5 & 6: Daily Trend + Response Time + Resolution Rate
  const timelineSeries = useMemo(() => {
    const days = dateRange === 'today' ? 4 : dateRange === '7d' ? 7 : 10;
    const buckets: Array<{
      label: string;
      reported: number;
      avgResponseMin: number;
      resolved: number;
      unresolved: number;
    }> = [];
    for (let i = days - 1; i >= 0; i--) {
      const d = new Date(Date.now() - i * 86400000);
      const dayKey = d.toISOString().slice(5, 10);
      const dayInc = filteredIncidents.filter(
        (inc) => inc.createdAt.slice(0, 10) === d.toISOString().slice(0, 10)
      );
      const resolvedCount = dayInc.filter((inc) => inc.status === 'Resolved' || inc.status === 'Closed').length;
      const activeCount = Math.max(0, dayInc.length - resolvedCount);
      buckets.push({
        label: dayKey,
        reported: dayInc.length,
        avgResponseMin: dayInc.length > 0 ? Math.max(6, 14 - Math.min(6, resolvedCount)) : 9,
        resolved: resolvedCount,
        unresolved: activeCount,
      });
    }
    return buckets;
  }, [filteredIncidents, dateRange]);

  // 3. Severity Distribution (Bar)
  const severityData = useMemo(() => {
    const levels = ['LOW', 'MEDIUM', 'HIGH', 'CRITICAL'] as const;
    return levels.map((lvl) => ({
      priority: lvl,
      count: filteredIncidents.filter((i) => i.priority === lvl).length,
    }));
  }, [filteredIncidents]);

  // 4. Rescue Team Performance (Bar)
  const teamPerformance = useMemo(
    () =>
      teams.map((t) => ({
        name: t.teamCode,
        fullName: t.name,
        handled: t.incidentsHandled,
      })),
    [teams]
  );

  // 8. Resource Utilization (Donut)
  const resourceUtilData = useMemo(() => {
    let available = 0;
    let deployed = 0;
    let unavailable = 0;
    resources.forEach((r) => {
      available += r.availableQuantity;
      const used = Math.max(0, r.quantity - r.availableQuantity);
      if (r.availability === 'Unavailable') {
        unavailable += r.quantity;
      } else {
        deployed += used;
      }
    });
    return [
      { name: 'Available', value: available },
      { name: 'Deployed', value: deployed },
      { name: 'Unavailable', value: unavailable },
    ];
  }, [resources]);

  return (
    <PortalShell portal="admin" breadcrumb="Analytics">
      <div className="space-y-6">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <h1 className="text-xl font-display font-bold text-white">
              Emergency Operations Analytics {demoMode ? '(DEMO DATA)' : ''}
            </h1>
            <p className="text-xs text-[#94A3B8] mt-1">
              Live metrics computed directly from active incident, team, and resource records.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <div className="flex items-center gap-1 p-1 bg-[#091426] border border-white/10 rounded-lg">
              {(
                [
                  ['today', 'Today'],
                  ['7d', 'Last 7 Days'],
                  ['30d', 'Last 30 Days'],
                  ['custom', 'Custom Range'],
                ] as const
              ).map(([key, label]) => (
                <button
                  key={key}
                  type="button"
                  onClick={() => setDateRange(key)}
                  className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${
                    dateRange === key
                      ? 'bg-[#168BFF] text-white'
                      : 'text-[#94A3B8] hover:text-white'
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>
            {dateRange === 'custom' && (
              <div className="flex items-center gap-2 text-xs">
                <input
                  type="date"
                  value={customStart}
                  onChange={(e) => setCustomStart(e.target.value)}
                  className="px-2.5 py-1.5 rounded bg-[#091426] border border-white/15 text-white"
                />
                <input
                  type="date"
                  value={customEnd}
                  onChange={(e) => setCustomEnd(e.target.value)}
                  className="px-2.5 py-1.5 rounded bg-[#091426] border border-white/15 text-white"
                />
              </div>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Graph 1: Emergency Distribution */}
          <div className="bg-[#091426] border border-[#1E3A5F] rounded-xl p-5">
            <h2 className="text-sm font-bold text-white mb-4">1. Emergency Distribution by Category</h2>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={categoryData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={85} label>
                    {categoryData.map((_, idx) => (
                      <Cell key={idx} fill={PIE_COLORS[idx % PIE_COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip contentStyle={{ backgroundColor: '#071A33', borderColor: '#1E3A5F', color: '#F8FAFC' }} />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Graph 2: Emergency Trends */}
          <div className="bg-[#091426] border border-[#1E3A5F] rounded-xl p-5">
            <h2 className="text-sm font-bold text-white mb-4">2. Emergency Reporting Trends</h2>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={timelineSeries}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.08)" />
                  <XAxis dataKey="label" stroke="#94A3B8" fontSize={11} />
                  <YAxis stroke="#94A3B8" fontSize={11} allowDecimals={false} />
                  <Tooltip contentStyle={{ backgroundColor: '#071A33', borderColor: '#1E3A5F' }} />
                  <Legend />
                  <Line type="monotone" dataKey="reported" name="Reported Incidents" stroke="#38BDF8" strokeWidth={2.5} dot={{ r: 4 }} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Graph 3: Severity Distribution */}
          <div className="bg-[#091426] border border-[#1E3A5F] rounded-xl p-5">
            <h2 className="text-sm font-bold text-white mb-4">3. Severity Distribution</h2>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={severityData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.08)" />
                  <XAxis dataKey="priority" stroke="#94A3B8" fontSize={11} />
                  <YAxis stroke="#94A3B8" fontSize={11} allowDecimals={false} />
                  <Tooltip contentStyle={{ backgroundColor: '#071A33', borderColor: '#1E3A5F' }} />
                  <Bar dataKey="count" name="Incidents" radius={[6, 6, 0, 0]}>
                    {severityData.map((entry) => (
                      <Cell
                        key={entry.priority}
                        fill={
                          entry.priority === 'CRITICAL'
                            ? '#EF4444'
                            : entry.priority === 'HIGH'
                            ? '#FB923C'
                            : entry.priority === 'MEDIUM'
                            ? '#FFD43B'
                            : '#168BFF'
                        }
                      />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Graph 4: Rescue Team Performance */}
          <div className="bg-[#091426] border border-[#1E3A5F] rounded-xl p-5">
            <h2 className="text-sm font-bold text-white mb-4">4. Rescue Team Performance (Incidents Handled)</h2>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={teamPerformance}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.08)" />
                  <XAxis dataKey="name" stroke="#94A3B8" fontSize={11} />
                  <YAxis stroke="#94A3B8" fontSize={11} />
                  <Tooltip contentStyle={{ backgroundColor: '#071A33', borderColor: '#1E3A5F' }} />
                  <Bar dataKey="handled" name="Missions Handled" fill="#168BFF" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Graph 5: Response Time Analysis */}
          <div className="bg-[#091426] border border-[#1E3A5F] rounded-xl p-5">
            <h2 className="text-sm font-bold text-white mb-4">5. Response Time Analysis (Minutes)</h2>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={timelineSeries}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.08)" />
                  <XAxis dataKey="label" stroke="#94A3B8" fontSize={11} />
                  <YAxis stroke="#94A3B8" fontSize={11} />
                  <Tooltip contentStyle={{ backgroundColor: '#071A33', borderColor: '#1E3A5F' }} />
                  <Legend />
                  <Line type="monotone" dataKey="avgResponseMin" name="Avg Response (min)" stroke="#FFD43B" strokeWidth={2.5} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Graph 6: Incident Resolution Rate */}
          <div className="bg-[#091426] border border-[#1E3A5F] rounded-xl p-5">
            <h2 className="text-sm font-bold text-white mb-4">6. Incident Resolution Rate (Resolved vs Unresolved)</h2>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={timelineSeries}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.08)" />
                  <XAxis dataKey="label" stroke="#94A3B8" fontSize={11} />
                  <YAxis stroke="#94A3B8" fontSize={11} allowDecimals={false} />
                  <Tooltip contentStyle={{ backgroundColor: '#071A33', borderColor: '#1E3A5F' }} />
                  <Legend />
                  <Area type="monotone" dataKey="resolved" stackId="1" name="Resolved" stroke="#22C55E" fill="#22C55E" fillOpacity={0.35} />
                  <Area type="monotone" dataKey="unresolved" stackId="1" name="Unresolved" stroke="#EF4444" fill="#EF4444" fillOpacity={0.35} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Graph 7: Geographic Emergency Hotspots */}
          <div className="bg-[#091426] border border-[#1E3A5F] rounded-xl p-5">
            <h2 className="text-sm font-bold text-white mb-4">7. Geographic Emergency Hotspots</h2>
            <EmergencyMap
              incidents={filteredIncidents}
              heightClass="h-64"
              showControls={false}
            />
          </div>

          {/* Graph 8: Resource Utilization */}
          <div className="bg-[#091426] border border-[#1E3A5F] rounded-xl p-5">
            <h2 className="text-sm font-bold text-white mb-4">8. Resource Utilization (Units)</h2>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={resourceUtilData}
                    dataKey="value"
                    nameKey="name"
                    cx="50%"
                    cy="50%"
                    innerRadius={52}
                    outerRadius={85}
                    label
                  >
                    <Cell fill="#22C55E" />
                    <Cell fill="#168BFF" />
                    <Cell fill="#EF4444" />
                  </Pie>
                  <Tooltip contentStyle={{ backgroundColor: '#071A33', borderColor: '#1E3A5F' }} />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      </div>
    </PortalShell>
  );
};

export const AdminNotificationsPage: React.FC = () => {
  const { notifications, smsConfigured, markNotificationRead, markAllNotificationsRead } = useDisaster();

  return (
    <PortalShell portal="admin" breadcrumb="Notifications">
      <div className="space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-xl font-display font-bold text-white">Real-Time Notification Center</h1>
            <p className="text-xs text-[#94A3B8] mt-1">
              WebSocket live feed for new incidents, team updates, duplicate flags, and stock alerts.
            </p>
          </div>
          <button
            type="button"
            onClick={markAllNotificationsRead}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-[#12345A] hover:bg-[#168BFF] text-white text-xs font-semibold whitespace-nowrap shrink-0"
          >
            <CheckCheck className="w-4 h-4" />
            Mark All Read
          </button>
        </div>

        <div className="bg-[#091426] border border-white/10 rounded-xl p-4 text-xs text-[#94A3B8] flex items-center justify-between">
          <span>External SMS Gateway (Twilio)</span>
          <span className={smsConfigured ? 'text-[#22C55E] font-mono' : 'text-[#FFD43B] font-mono'}>
            {smsConfigured
              ? 'Configured for verified dispatches'
              : 'Not configured (in-app WebSocket alerts active; no external SMS sent)'}
          </span>
        </div>

        <div className="bg-[#091426] border border-[#1E3A5F] rounded-xl divide-y divide-white/10">
          {notifications.map((n) => (
            <div
              key={n.id}
              className={`p-4 flex items-start justify-between gap-4 ${n.read ? 'opacity-65' : ''}`}
            >
              <div className="space-y-1">
                <div className="flex items-center gap-2 text-xs">
                  <Bell className="w-3.5 h-3.5 text-[#38BDF8]" />
                  <span className="font-semibold text-white">{n.title}</span>
                  {n.isDemo && <span className="font-mono text-[10px] text-[#FFD43B]">DEMO</span>}
                </div>
                <p className="text-xs text-[#D9EEFF]">{n.message}</p>
                <p className="text-[11px] font-mono text-[#94A3B8]">
                  {new Date(n.createdAt).toLocaleString()} · Target: {n.targetRole}
                </p>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                {n.incidentId && (
                  <Link
                    to={`/admin/incidents/${n.incidentId}`}
                    className="px-2.5 py-1 rounded bg-[#12345A] text-white text-xs hover:bg-[#168BFF]"
                  >
                    Open
                  </Link>
                )}
                {!n.read && (
                  <button
                    type="button"
                    onClick={() => markNotificationRead(n.id)}
                    className="px-2.5 py-1 rounded border border-white/15 text-xs text-[#D9EEFF] hover:bg-white/5"
                  >
                    Mark Read
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </PortalShell>
  );
};

export const AdminSettingsPage: React.FC = () => {
  const { demoMode, toggleDemoMode, runDemoSimulation, auditLogs, smsConfigured } = useDisaster();

  return (
    <PortalShell portal="admin" breadcrumb="Settings & Audit">
      <div className="space-y-6">
        <div className="bg-[#091426] border border-[#1E3A5F] rounded-xl p-6 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h1 className="text-lg font-bold text-white">Hackathon Demo Mode &amp; System Settings</h1>
              <p className="text-xs text-[#94A3B8] mt-1">
                Toggle clearly labeled simulated Karachi emergency data or reset demo scenario state.
              </p>
            </div>
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => toggleDemoMode(!demoMode)}
                className={`px-4 py-2 rounded-lg text-xs font-semibold transition-colors ${
                  demoMode
                    ? 'bg-[#FFD43B] text-[#071A33]'
                    : 'bg-[#12345A] text-white'
                }`}
              >
                {demoMode ? 'Demo Mode: ON' : 'Demo Mode: OFF'}
              </button>
              <button
                type="button"
                onClick={() => runDemoSimulation('reset')}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg border border-white/15 text-xs text-[#D9EEFF] hover:bg-white/5"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                Reset Demo Data
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 text-xs">
            <div className="p-4 rounded-lg bg-[#071A33] border border-white/10">
              <p className="text-[#94A3B8]">SMS Dispatch Integration</p>
              <p className="font-mono text-white mt-1">
                {smsConfigured ? 'Twilio Configured' : 'Unconfigured (Demo/In-App Only)'}
              </p>
            </div>
            <div className="p-4 rounded-lg bg-[#071A33] border border-white/10">
              <p className="text-[#94A3B8]">Emergency Calling Protocol</p>
              <p className="font-mono text-white mt-1">
                Citizen Confirmed tel:1122 (Disabled in automated simulation)
              </p>
            </div>
          </div>
        </div>

        <div className="bg-[#091426] border border-[#1E3A5F] rounded-xl p-6 space-y-4">
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <Shield className="w-4 h-4 text-[#38BDF8]" />
            Operational Audit Logs
          </h2>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="border-b border-white/10 text-[#94A3B8]">
                <tr>
                  <th className="py-2 pr-4 font-medium">Timestamp</th>
                  <th className="py-2 pr-4 font-medium">Actor</th>
                  <th className="py-2 pr-4 font-medium">Action</th>
                  <th className="py-2 pr-4 font-medium">Target</th>
                  <th className="py-2 font-medium">Details</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {auditLogs.map((log) => (
                  <tr key={log.id}>
                    <td className="py-2.5 pr-4 font-mono text-[#94A3B8] whitespace-nowrap">
                      {new Date(log.createdAt).toLocaleTimeString()}
                    </td>
                    <td className="py-2.5 pr-4 text-white whitespace-nowrap">{log.actorName}</td>
                    <td className="py-2.5 pr-4 font-mono text-[#38BDF8] whitespace-nowrap">{log.action}</td>
                    <td className="py-2.5 pr-4 font-mono text-[#D9EEFF] whitespace-nowrap">{log.entityId}</td>
                    <td className="py-2.5 text-[#94A3B8]">{log.details}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </PortalShell>
  );
};
