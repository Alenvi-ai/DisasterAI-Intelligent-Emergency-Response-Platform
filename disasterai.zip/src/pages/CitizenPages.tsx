import React, { useEffect, useMemo, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import {
  AlertTriangle,
  Ambulance,
  BellRing,
  Building2,
  CheckCircle2,
  Clock,
  Cpu,
  Flame,
  LocateFixed,
  MapPin,
  PhoneCall,
  Search,
  ShieldCheck,
  Truck,
  Upload,
} from 'lucide-react';
import { PortalShell } from '../components/layout/AppShells';
import { EmergencyMap } from '../components/map/EmergencyMap';
import {
  Call1122Modal,
  EmergencyQuickDialStrip,
  PriorityBadgeText,
  SAFETY_PROTOCOLS,
  StatusText,
} from '../components/ui/DisasterPrimitives';
import { useDisaster } from '../context/DisasterContext';
import type {
  AIAnalysisResult,
  DuplicateMatch,
  Hospital,
  IncidentCategory,
} from '../types/disaster';

const KARACHI_AREAS = [
  { label: 'Saddar / Regal Chowk', lat: 24.8592, lng: 67.0267 },
  { label: 'Korangi Sector 15', lat: 24.8384, lng: 67.1168 },
  { label: 'Lyari / Chakiwara', lat: 24.8768, lng: 66.9956 },
  { label: 'Clifton Block 4', lat: 24.8172, lng: 67.0241 },
  { label: 'Gulshan-e-Iqbal 13-D', lat: 24.9145, lng: 67.0819 },
  { label: 'Nazimabad Block 3', lat: 24.9165, lng: 67.0322 },
  { label: 'Shahrah-e-Faisal Nursery', lat: 24.8615, lng: 67.0628 },
  { label: 'DHA Phase 6', lat: 24.7937, lng: 67.0644 },
];

export const CitizenDashboardPage: React.FC = () => {
  const { incidents, sessionUser, fetchNearbyHospitals } = useDisaster();
  const [callOpen, setCallOpen] = useState(false);
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number; label: string }>({
    lat: 24.8607,
    lng: 67.0011,
    label: 'Karachi Metropolitan Area',
  });
  const [locLoading, setLocLoading] = useState(false);
  const [nearbyHospitals, setNearbyHospitals] = useState<Hospital[]>([]);

  useEffect(() => {
    let active = true;
    fetchNearbyHospitals(userLocation.lat, userLocation.lng, 4).then((list) => {
      if (active) setNearbyHospitals(list);
    });
    return () => {
      active = false;
    };
  }, [fetchNearbyHospitals, userLocation.lat, userLocation.lng]);

  const activeAlerts = useMemo(
    () => incidents.filter((i) => i.isPublicAlert && i.status !== 'Closed' && i.status !== 'Resolved').slice(0, 4),
    [incidents]
  );

  const recentReports = useMemo(() => incidents.slice(0, 6), [incidents]);

  const detectLocation = () => {
    if (!navigator.geolocation) return;
    setLocLoading(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setUserLocation({
          lat: Number(pos.coords.latitude.toFixed(5)),
          lng: Number(pos.coords.longitude.toFixed(5)),
          label: `GPS Locked (${pos.coords.latitude.toFixed(4)}, ${pos.coords.longitude.toFixed(4)})`,
        });
        setLocLoading(false);
      },
      () => {
        setLocLoading(false);
      },
      { timeout: 6000 }
    );
  };

  return (
    <PortalShell portal="citizen" breadcrumb="Emergency Home">
      <div className="space-y-6">
        {/* Welcome & Quick Action Banner */}
        <div className="bg-[#091426] border border-[#1E3A5F] rounded-xl p-6 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-xs text-[#38BDF8]">
              <span>DisasterAI Citizen Response</span>
              <span aria-hidden="true">·</span>
              <span className="font-mono">{userLocation.label}</span>
            </div>
            <h1 className="text-2xl font-display font-bold text-white">
              Welcome, {sessionUser?.displayName || 'Citizen'}
            </h1>
            <p className="text-sm text-[#94A3B8] max-w-2xl">
              Report life-safety emergencies with GPS coordinates and photos, place confirmed 1122 rescue calls, and track assigned teams in real time.
            </p>
            <button
              type="button"
              onClick={detectLocation}
              className="inline-flex items-center gap-1.5 text-xs font-medium text-[#38BDF8] hover:underline pt-1"
            >
              <LocateFixed className="w-3.5 h-3.5" />
              {locLoading ? 'Acquiring GPS coordinates...' : 'Refresh My GPS Location'}
            </button>
          </div>

          <div className="flex flex-wrap items-center gap-3 shrink-0">
            <Link
              to="/citizen/report-emergency"
              className="inline-flex items-center gap-2 px-5 py-3 rounded-lg bg-[#168BFF] hover:bg-[#38BDF8] hover:text-[#071A33] text-white text-sm font-semibold transition-colors"
            >
              <AlertTriangle className="w-4 h-4" />
              Report an Emergency
            </Link>
            <button
              type="button"
              onClick={() => setCallOpen(true)}
              className="inline-flex items-center gap-2 px-5 py-3 rounded-lg bg-[#EF4444] hover:bg-red-600 text-white text-sm font-semibold transition-colors"
            >
              <PhoneCall className="w-4 h-4" />
              Emergency Helplines
            </button>
          </div>
        </div>

        {/* Direct Calling: Edhi 115, Chhipa 1020, Fire Brigade 101, Rescue 1122 */}
        <EmergencyQuickDialStrip />

        {/* Active Emergency Alerts */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-7 bg-[#091426] border border-[#1E3A5F] rounded-xl p-5 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-base font-bold text-white">Active Emergency Alerts</h2>
              <Link to="/citizen/my-reports" className="text-xs text-[#38BDF8] hover:underline">
                View All Reports
              </Link>
            </div>

            {activeAlerts.length === 0 ? (
              <p className="text-sm text-[#94A3B8] py-4">No active public alerts in your district.</p>
            ) : (
              <div className="divide-y divide-white/10">
                {activeAlerts.map((inc) => (
                  <div key={inc.id} className="py-3.5 first:pt-0 last:pb-0 flex items-start justify-between gap-4">
                    <div className="space-y-1 min-w-0">
                      <div className="flex items-center gap-2 text-xs">
                        <span className="font-mono text-[#38BDF8]">{inc.incidentCode}</span>
                        <span aria-hidden="true">·</span>
                        <span className="text-[#94A3B8]">{inc.category}</span>
                        <span aria-hidden="true">·</span>
                        <PriorityBadgeText priority={inc.priority} />
                      </div>
                      <p className="text-sm font-semibold text-white truncate">{inc.title}</p>
                      <p className="text-xs text-[#94A3B8] truncate">{inc.address}</p>
                    </div>
                    <Link
                      to={`/citizen/track/${inc.id}`}
                      className="px-3 py-1.5 rounded-lg border border-white/10 hover:border-[#38BDF8] text-xs font-medium text-[#D9EEFF] whitespace-nowrap shrink-0"
                    >
                      Track
                    </Link>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Safety Quick Guide */}
          <div className="lg:col-span-5 bg-[#091426] border border-[#1E3A5F] rounded-xl p-5 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-base font-bold text-white">Immediate Safety Instructions</h2>
              <Link to="/citizen/safety-center" className="text-xs text-[#38BDF8] hover:underline">
                Full Safety Center
              </Link>
            </div>
            <div className="space-y-3">
              {SAFETY_PROTOCOLS.slice(0, 3).map((guide) => (
                <div key={guide.id} className="p-3.5 rounded-lg bg-[#071A33] border border-white/5 space-y-1">
                  <p className="text-sm font-semibold text-[#F8FAFC]">{guide.title}</p>
                  <p className="text-xs text-[#94A3B8] leading-relaxed">{guide.steps[0]}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Nearby Hospitals Ready for First Aid */}
        <div className="bg-[#091426] border border-[#1E3A5F] rounded-xl p-5 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <Building2 className="w-4 h-4 text-[#22C55E]" />
              <h2 className="text-base font-bold text-white">Nearby Hospitals Ready for First Aid</h2>
            </div>
            <span className="text-xs font-mono text-[#94A3B8]">
              Sorted by proximity to {userLocation.label}
            </span>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
            {nearbyHospitals.map((hosp) => (
              <div
                key={hosp.id}
                className="bg-[#071A33] border border-white/10 rounded-lg p-4 flex flex-col justify-between gap-3"
              >
                <div className="space-y-1">
                  <div className="flex items-center justify-between gap-2 text-[11px] font-mono">
                    <span className="text-[#22C55E]">{hosp.traumaLevel}</span>
                    <span className="text-[#38BDF8] tabular-nums">
                      {hosp.distanceKm} km · ~{hosp.etaMinutes} min
                    </span>
                  </div>
                  <h3 className="text-sm font-semibold text-white">{hosp.name}</h3>
                  <p className="text-xs text-[#94A3B8] line-clamp-2">{hosp.address}</p>
                </div>
                <div className="flex items-center justify-between gap-2 pt-2 border-t border-white/10 text-xs">
                  <a
                    href={`tel:${hosp.emergencyPhone.replace(/[^+\d]/g, '')}`}
                    className="inline-flex items-center gap-1.5 font-mono text-[#38BDF8] hover:underline"
                  >
                    <PhoneCall className="w-3.5 h-3.5" />
                    {hosp.emergencyPhone}
                  </a>
                  <Link
                    to="/citizen/report-emergency"
                    className="text-[#22C55E] hover:underline font-medium whitespace-nowrap"
                  >
                    Request First Aid
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Recently Reported Incidents */}
        <div className="bg-[#091426] border border-[#1E3A5F] rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-white">Recently Reported Incidents</h2>
            <span className="text-xs text-[#94A3B8] font-mono tabular-nums">
              {recentReports.length} shown
            </span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-white/10 text-[#94A3B8]">
                  <th className="py-2.5 pr-4 font-medium">Incident ID</th>
                  <th className="py-2.5 pr-4 font-medium">Category</th>
                  <th className="py-2.5 pr-4 font-medium">Title &amp; Location</th>
                  <th className="py-2.5 pr-4 font-medium">Priority</th>
                  <th className="py-2.5 pr-4 font-medium">Status</th>
                  <th className="py-2.5 text-right font-medium">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {recentReports.map((inc) => (
                  <tr key={inc.id} className="hover:bg-white/[0.02]">
                    <td className="py-3 pr-4 font-mono text-[#38BDF8] whitespace-nowrap">{inc.incidentCode}</td>
                    <td className="py-3 pr-4 text-[#D9EEFF] whitespace-nowrap">{inc.category}</td>
                    <td className="py-3 pr-4 max-w-xs">
                      <p className="font-medium text-white truncate">{inc.title}</p>
                      <p className="text-[#94A3B8] truncate">{inc.address}</p>
                    </td>
                    <td className="py-3 pr-4 whitespace-nowrap">
                      <PriorityBadgeText priority={inc.priority} />
                    </td>
                    <td className="py-3 pr-4 whitespace-nowrap">
                      <StatusText status={inc.status} />
                    </td>
                    <td className="py-3 text-right whitespace-nowrap">
                      <Link to={`/citizen/track/${inc.id}`} className="text-[#38BDF8] hover:underline font-medium">
                        Track Status
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <Call1122Modal open={callOpen} onClose={() => setCallOpen(false)} />
    </PortalShell>
  );
};

export const ReportEmergencyPage: React.FC = () => {
  const {
    analyzeDraftIncident,
    checkDraftDuplicates,
    submitIncident,
    fetchNearbyHospitals,
    notifyNearbyHospitals,
    hospitalAlerts,
    pushToast,
  } = useDisaster();
  const navigate = useNavigate();

  const [category, setCategory] = useState<IncidentCategory>('Flood');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [city, setCity] = useState('Karachi');
  const [address, setAddress] = useState('');
  const [lat, setLat] = useState(24.8607);
  const [lng, setLng] = useState(67.0011);
  const [peopleAffected, setPeopleAffected] = useState(5);
  const [injuredCount, setInjuredCount] = useState(0);
  const [trapped, setTrapped] = useState(false);
  const [hazards, setHazards] = useState<string[]>([]);
  const [contactPhone, setContactPhone] = useState('+92-300-');
  const [imageUrls, setImageUrls] = useState<string[]>([]);
  const [videoName, setVideoName] = useState<string | null>(null);

  const [gpsStatus, setGpsStatus] = useState<string>('Manual or preset coordinates active');
  const [aiPreview, setAiPreview] = useState<AIAnalysisResult | null>(null);
  const [duplicatePreview, setDuplicatePreview] = useState<DuplicateMatch[]>([]);
  const [nearbyHospitals, setNearbyHospitals] = useState<Hospital[]>([]);
  const [analyzing, setAnalyzing] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [notifyingHospitals, setNotifyingHospitals] = useState(false);
  const [submittedId, setSubmittedId] = useState<string | null>(null);
  const [submittedCode, setSubmittedCode] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    fetchNearbyHospitals(lat, lng, 3).then((list) => {
      if (active) setNearbyHospitals(list);
    });
    return () => {
      active = false;
    };
  }, [fetchNearbyHospitals, lat, lng]);

  const isFireEmergency =
    category === 'Fire' ||
    hazards.includes('Fire / Explosion Risk') ||
    hazards.includes('Toxic Smoke');
  const isAmbulanceNeeded =
    category === 'Medical Emergency' || category === 'Road Accident' || injuredCount > 0;

  const submittedHospitalAlerts = useMemo(
    () => (submittedId ? hospitalAlerts.filter((a) => a.incidentId === submittedId) : []),
    [hospitalAlerts, submittedId]
  );

  const HAZARD_OPTIONS = ['Fire / Explosion Risk', 'Flooding', 'Structural Collapse', 'Toxic Smoke', 'Electrocution Risk'];

  const toggleHazard = (h: string) => {
    setHazards((prev) => (prev.includes(h) ? prev.filter((x) => x !== h) : [...prev, h]));
  };

  const handleGetGPS = () => {
    if (!navigator.geolocation) {
      setGpsStatus('Browser GPS unsupported; click map to pick location.');
      return;
    }
    setGpsStatus('Requesting device GPS...');
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setLat(Number(pos.coords.latitude.toFixed(6)));
        setLng(Number(pos.coords.longitude.toFixed(6)));
        setGpsStatus(`GPS acquired (±${Math.round(pos.coords.accuracy)}m)`);
        pushToast({ title: 'GPS location captured', tone: 'success' });
      },
      () => {
        setGpsStatus('GPS permission denied or unavailable; click on the map to set pin.');
        pushToast({ title: 'GPS unavailable — select pin on map', tone: 'warning' });
      },
      { enableHighAccuracy: true, timeout: 7000 }
    );
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []).slice(0, 4);
    for (const file of files) {
      if (!file.type.startsWith('image/')) continue;
      if (file.size > 4 * 1024 * 1024) {
        pushToast({ title: `${file.name} exceeds 4MB limit`, tone: 'warning' });
        continue;
      }
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          setImageUrls((prev) => [...prev.slice(0, 3), reader.result as string]);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRunAIPreview = async () => {
    if (!title.trim() || !description.trim()) {
      pushToast({ title: 'Enter title and description first', tone: 'warning' });
      return;
    }
    setAnalyzing(true);
    try {
      const [ai, dups] = await Promise.all([
        analyzeDraftIncident({
          category,
          title,
          description,
          city,
          address: address || city,
          peopleAffected,
          injuredCount,
          trapped,
          hazards,
          imageUrls,
        }),
        checkDraftDuplicates({ category, title, description, lat, lng }),
      ]);
      setAiPreview(ai);
      setDuplicatePreview(dups);
    } catch {
      pushToast({ title: 'Could not run AI preview', tone: 'warning' });
    } finally {
      setAnalyzing(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !description.trim() || !address.trim()) {
      pushToast({ title: 'Please fill title, description, and address', tone: 'warning' });
      return;
    }
    setSubmitting(true);
    try {
      const created = await submitIncident({
        category,
        title,
        description,
        city,
        address,
        lat,
        lng,
        peopleAffected,
        injuredCount,
        trapped,
        hazards,
        imageUrls,
        videoUrl: videoName || undefined,
        contactPhone,
      });
      setSubmittedId(created.id);
      setSubmittedCode(created.incidentCode);
    } catch (err: any) {
      pushToast({ title: err?.message || 'Submission failed', tone: 'critical' });
    } finally {
      setSubmitting(false);
    }
  };

  if (submittedId && submittedCode) {
    return (
      <PortalShell portal="citizen" breadcrumb="Report Confirmed">
        <div className="max-w-3xl mx-auto space-y-5">
          <div className="bg-[#091426] border border-[#22C55E]/40 rounded-xl p-8 space-y-5">
            <div className="flex items-center gap-3 text-[#22C55E]">
              <CheckCircle2 className="w-7 h-7" />
              <div>
                <h1 className="text-2xl font-display font-bold text-white">Emergency Report Submitted</h1>
                <p className="text-xs text-[#94A3B8]">Transmitted to DisasterAI Emergency Command Center</p>
              </div>
            </div>

            <div className="bg-[#071A33] border border-white/10 rounded-lg p-4 flex items-center justify-between">
              <span className="text-xs text-[#94A3B8]">Unique Incident ID</span>
              <span className="font-mono text-xl font-bold text-[#38BDF8]">{submittedCode}</span>
            </div>

            <p className="text-sm text-[#D9EEFF] leading-relaxed">
              AI severity triage and duplicate verification have completed. Operators in the Command Center have received your coordinates and can now dispatch the nearest specialized rescue squad.
            </p>

            {/* Nearby Hospital First-Aid Status */}
            <div className="bg-[#071A33] border border-white/10 rounded-lg p-4 space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div className="flex items-center gap-2 text-xs font-semibold text-[#22C55E]">
                  <Building2 className="w-4 h-4" />
                  <span>Nearby Hospital First-Aid Notifications</span>
                </div>
                {submittedHospitalAlerts.length === 0 && (
                  <button
                    type="button"
                    disabled={notifyingHospitals}
                    onClick={async () => {
                      setNotifyingHospitals(true);
                      try {
                        await notifyNearbyHospitals(submittedId);
                      } finally {
                        setNotifyingHospitals(false);
                      }
                    }}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#22C55E]/20 border border-[#22C55E]/40 hover:bg-[#22C55E] hover:text-[#071A33] text-xs font-semibold text-white transition-colors"
                  >
                    <BellRing className="w-3.5 h-3.5" />
                    {notifyingHospitals ? 'Notifying Hospitals...' : 'Notify Nearby Hospitals for First Aid'}
                  </button>
                )}
              </div>

              {submittedHospitalAlerts.length > 0 ? (
                <div className="space-y-2">
                  {submittedHospitalAlerts.map((ha) => (
                    <div
                      key={ha.id}
                      className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs py-2 border-t border-white/10 first:border-none first:pt-0"
                    >
                      <div>
                        <p className="font-semibold text-white">{ha.hospitalName}</p>
                        <p className="text-[#94A3B8]">
                          {ha.distanceKm} km away · First Aid ETA ~{ha.firstAidEtaMinutes} min
                        </p>
                      </div>
                      <StatusText status={ha.status} />
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-[#94A3B8]">
                  No hospitals notified yet. Click &quot;Notify Nearby Hospitals for First Aid&quot; above to alert the nearest hospitals immediately.
                </p>
              )}
            </div>

            <div className="flex flex-wrap gap-3 pt-2">
              <button
                type="button"
                onClick={() => navigate(`/citizen/track/${submittedId}`)}
                className="px-5 py-2.5 rounded-lg bg-[#168BFF] hover:bg-[#38BDF8] hover:text-[#071A33] text-white text-sm font-semibold transition-colors"
              >
                Track My Emergency
              </button>
              <button
                type="button"
                onClick={() => {
                  setSubmittedId(null);
                  setSubmittedCode(null);
                  setTitle('');
                  setDescription('');
                  setImageUrls([]);
                  setAiPreview(null);
                }}
                className="px-5 py-2.5 rounded-lg border border-white/15 hover:bg-white/5 text-sm font-medium text-[#D9EEFF]"
              >
                Submit Another Report
              </button>
            </div>
          </div>

          <EmergencyQuickDialStrip
            compact
            highlightFire={isFireEmergency}
            highlightAmbulance={isAmbulanceNeeded}
          />
        </div>
      </PortalShell>
    );
  }

  return (
    <PortalShell portal="citizen" breadcrumb="Report an Emergency">
      <form onSubmit={handleSubmit} className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-7 bg-[#091426] border border-[#1E3A5F] rounded-xl p-6 space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h1 className="text-xl font-display font-bold text-white">Submit Emergency Report</h1>
              <p className="text-xs text-[#94A3B8] mt-1">
                Provide accurate location and hazard details for immediate AI severity scoring and dispatch.
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-2 shrink-0">
              <a
                href="tel:101"
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#FFD43B] hover:bg-[#FFF0A6] text-[#071A33] text-xs font-semibold whitespace-nowrap"
              >
                <Flame className="w-3.5 h-3.5" />
                Fire Brigade 101
              </a>
              <a
                href="tel:115"
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#12345A] hover:bg-[#168BFF] text-white text-xs font-semibold whitespace-nowrap"
              >
                <Ambulance className="w-3.5 h-3.5" />
                Edhi 115
              </a>
              <a
                href="tel:1020"
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#12345A] hover:bg-[#168BFF] text-white text-xs font-semibold whitespace-nowrap"
              >
                <Ambulance className="w-3.5 h-3.5" />
                Chhipa 1020
              </a>
            </div>
          </div>

          {isFireEmergency && (
            <div className="bg-[#EF4444]/15 border border-[#EF4444]/50 rounded-lg p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="space-y-1">
                <div className="flex items-center gap-2 text-[#FFD43B] text-xs font-bold">
                  <Flame className="w-4 h-4 text-[#EF4444]" />
                  <span>Active Fire Location Alert — Call Fire Brigade Immediately</span>
                </div>
                <p className="text-xs text-[#D9EEFF]">
                  If you are at a fire scene right now, evacuate upwind first and call Fire Brigade 101 directly while submitting this report.
                </p>
              </div>
              <a
                href="tel:101"
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-[#EF4444] hover:bg-red-600 text-white text-xs font-semibold whitespace-nowrap shrink-0"
              >
                <PhoneCall className="w-4 h-4" />
                Call Fire Brigade 101
              </a>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-[#D9EEFF] mb-1.5">Emergency Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as IncidentCategory)}
                className="w-full px-3 py-2.5 rounded-lg bg-[#071A33] border border-white/15 text-sm text-white focus:outline-none focus:border-[#38BDF8]"
              >
                <option value="Flood">Flood</option>
                <option value="Fire">Fire</option>
                <option value="Building Collapse">Building Collapse</option>
                <option value="Road Accident">Road Accident</option>
                <option value="Medical Emergency">Medical Emergency</option>
                <option value="Earthquake">Earthquake</option>
                <option value="Missing Person">Missing Person</option>
                <option value="Rescue Request">Rescue Request</option>
                <option value="Other">Other</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-[#D9EEFF] mb-1.5">City</label>
              <select
                value={city}
                onChange={(e) => setCity(e.target.value)}
                className="w-full px-3 py-2.5 rounded-lg bg-[#071A33] border border-white/15 text-sm text-white focus:outline-none focus:border-[#38BDF8]"
              >
                <option value="Karachi">Karachi</option>
                <option value="Lahore">Lahore</option>
                <option value="Islamabad">Islamabad</option>
                <option value="Rawalpindi">Rawalpindi</option>
                <option value="Hyderabad">Hyderabad</option>
                <option value="Multan">Multan</option>
                <option value="Peshawar">Peshawar</option>
                <option value="Quetta">Quetta</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-[#D9EEFF] mb-1.5">Emergency Title</label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g., Flash flood water trapping family in Korangi Sector 15"
              className="w-full px-3.5 py-2.5 rounded-lg bg-[#071A33] border border-white/15 text-sm text-white placeholder:text-[#94A3B8] focus:outline-none focus:border-[#38BDF8]"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-[#D9EEFF] mb-1.5">Detailed Description</label>
            <textarea
              required
              rows={4}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe water depth, smoke/flames, structural damage, accessibility, and immediate medical needs..."
              className="w-full px-3.5 py-2.5 rounded-lg bg-[#071A33] border border-white/15 text-sm text-white placeholder:text-[#94A3B8] focus:outline-none focus:border-[#38BDF8]"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-[#D9EEFF] mb-1.5">Address or Nearby Landmark</label>
            <input
              type="text"
              required
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              placeholder="Street, block, sector, or nearest landmark"
              className="w-full px-3.5 py-2.5 rounded-lg bg-[#071A33] border border-white/15 text-sm text-white placeholder:text-[#94A3B8] focus:outline-none focus:border-[#38BDF8]"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-medium text-[#D9EEFF] mb-1.5">People Affected</label>
              <input
                type="number"
                min={0}
                value={peopleAffected}
                onChange={(e) => setPeopleAffected(Math.max(0, Number(e.target.value)))}
                className="w-full px-3 py-2 rounded-lg bg-[#071A33] border border-white/15 text-sm font-mono text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-[#D9EEFF] mb-1.5">Injured People</label>
              <input
                type="number"
                min={0}
                value={injuredCount}
                onChange={(e) => setInjuredCount(Math.max(0, Number(e.target.value)))}
                className="w-full px-3 py-2 rounded-lg bg-[#071A33] border border-white/15 text-sm font-mono text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-[#D9EEFF] mb-1.5">Contact Phone</label>
              <input
                type="tel"
                value={contactPhone}
                onChange={(e) => setContactPhone(e.target.value)}
                placeholder="+92-300-1234567"
                className="w-full px-3 py-2 rounded-lg bg-[#071A33] border border-white/15 text-sm font-mono text-white"
              />
            </div>
          </div>

          <div className="space-y-2.5">
            <label className="flex items-center gap-2.5 text-sm text-white cursor-pointer">
              <input
                type="checkbox"
                checked={trapped}
                onChange={(e) => setTrapped(e.target.checked)}
                className="w-4 h-4 rounded accent-[#EF4444]"
              />
              <span>Anyone trapped or unable to evacuate safely</span>
            </label>

            <div>
              <p className="text-xs font-medium text-[#D9EEFF] mb-2">Active Hazards Present</p>
              <div className="flex flex-wrap gap-2">
                {HAZARD_OPTIONS.map((h) => {
                  const active = hazards.includes(h);
                  return (
                    <button
                      key={h}
                      type="button"
                      onClick={() => toggleHazard(h)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors ${
                        active
                          ? 'bg-[#EF4444]/20 border-[#EF4444] text-white'
                          : 'bg-[#071A33] border-white/10 text-[#94A3B8] hover:text-white'
                      }`}
                    >
                      {h}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Media Uploads */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
            <div>
              <label className="block text-xs font-medium text-[#D9EEFF] mb-1.5">
                Upload Emergency Photos (up to 4)
              </label>
              <label className="flex items-center justify-center gap-2 px-4 py-3 rounded-lg bg-[#071A33] border border-dashed border-white/20 hover:border-[#38BDF8] text-xs text-[#D9EEFF] cursor-pointer">
                <Upload className="w-4 h-4 text-[#38BDF8]" />
                <span>Select Images for AI Vision</span>
                <input
                  type="file"
                  accept="image/*"
                  multiple
                  onChange={handleImageUpload}
                  className="hidden"
                />
              </label>
              {imageUrls.length > 0 && (
                <div className="grid grid-cols-4 gap-2 mt-2">
                  {imageUrls.map((url, idx) => (
                    <img
                      key={idx}
                      src={url}
                      alt={`Uploaded emergency preview ${idx + 1}`}
                      className="h-14 w-full object-cover rounded border border-white/15"
                    />
                  ))}
                </div>
              )}
            </div>

            <div>
              <label className="block text-xs font-medium text-[#D9EEFF] mb-1.5">
                Optional Video Attachment
              </label>
              <label className="flex items-center justify-center gap-2 px-4 py-3 rounded-lg bg-[#071A33] border border-dashed border-white/20 hover:border-[#38BDF8] text-xs text-[#D9EEFF] cursor-pointer">
                <Upload className="w-4 h-4 text-[#94A3B8]" />
                <span className="truncate">{videoName || 'Attach Video Clip'}</span>
                <input
                  type="file"
                  accept="video/*"
                  onChange={(e) => {
                    const f = e.target.files?.[0];
                    if (f) setVideoName(f.name);
                  }}
                  className="hidden"
                />
              </label>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3 pt-2 border-t border-white/10">
            <button
              type="button"
              disabled={analyzing}
              onClick={handleRunAIPreview}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg border border-[#38BDF8]/40 bg-[#12345A]/50 hover:bg-[#12345A] text-[#38BDF8] text-xs font-semibold transition-colors"
            >
              <Cpu className="w-4 h-4" />
              {analyzing ? 'Running AI Triage...' : 'Preview AI Triage & Duplicate Check'}
            </button>

            <button
              type="submit"
              disabled={submitting}
              className="inline-flex items-center gap-2 px-6 py-2.5 rounded-lg bg-[#168BFF] hover:bg-[#38BDF8] hover:text-[#071A33] disabled:opacity-60 text-white text-sm font-semibold transition-colors ml-auto"
            >
              {submitting ? 'Submitting & Analyzing...' : 'Submit Emergency Report'}
            </button>
          </div>
        </div>

        {/* Right Column: GPS + Map Picker + AI Preview */}
        <div className="lg:col-span-5 space-y-5">
          <div className="bg-[#091426] border border-[#1E3A5F] rounded-xl p-5 space-y-3">
            <div className="flex items-center justify-between gap-2">
              <h2 className="text-sm font-bold text-white">Incident Location Pin</h2>
              <button
                type="button"
                onClick={handleGetGPS}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#168BFF]/20 border border-[#168BFF]/40 text-[#38BDF8] text-xs font-medium hover:bg-[#168BFF] hover:text-white transition-colors"
              >
                <LocateFixed className="w-3.5 h-3.5" />
                Use My GPS
              </button>
            </div>
            <p className="text-xs text-[#94A3B8]">{gpsStatus}</p>

            <div className="grid grid-cols-2 gap-2 text-xs font-mono">
              <div className="bg-[#071A33] border border-white/10 rounded-lg px-3 py-2">
                <span className="text-[#94A3B8]">Lat: </span>
                <span className="text-white">{lat}</span>
              </div>
              <div className="bg-[#071A33] border border-white/10 rounded-lg px-3 py-2">
                <span className="text-[#94A3B8]">Lng: </span>
                <span className="text-white">{lng}</span>
              </div>
            </div>

            <div className="flex flex-wrap gap-1.5">
              {KARACHI_AREAS.slice(0, 6).map((area) => (
                <button
                  key={area.label}
                  type="button"
                  onClick={() => {
                    setLat(area.lat);
                    setLng(area.lng);
                    if (!address) setAddress(area.label + ', Karachi');
                  }}
                  className="px-2 py-1 rounded bg-[#071A33] border border-white/10 hover:border-[#38BDF8] text-[11px] text-[#D9EEFF]"
                >
                  {area.label}
                </button>
              ))}
            </div>

            <EmergencyMap
              incidents={[]}
              hospitals={nearbyHospitals}
              pickLocationMode
              pickedCoords={{ lat, lng }}
              onPickCoords={(newLat, newLng) => {
                setLat(newLat);
                setLng(newLng);
                setGpsStatus('Manual map coordinates selected');
              }}
              heightClass="h-[260px]"
              showControls={false}
              center={[lat, lng]}
              zoom={13}
            />
          </div>

          <div className="bg-[#091426] border border-[#1E3A5F] rounded-xl p-5 space-y-3">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <Building2 className="w-4 h-4 text-[#22C55E]" />
                <h2 className="text-sm font-bold text-white">Nearby Hospitals (First Aid)</h2>
              </div>
              <span className="text-[11px] font-mono text-[#22C55E]">Auto-alert enabled</span>
            </div>
            <p className="text-xs text-[#94A3B8]">
              Closest medical centers to your pinned coordinates are notified automatically when injuries, medical emergencies, fire, or high-risk hazards are reported.
            </p>
            <div className="space-y-2">
              {nearbyHospitals.map((hosp) => (
                <div
                  key={hosp.id}
                  className="bg-[#071A33] border border-white/10 rounded-lg p-3 flex items-center justify-between gap-3 text-xs"
                >
                  <div className="min-w-0">
                    <p className="font-semibold text-white truncate">{hosp.name}</p>
                    <p className="text-[#94A3B8] font-mono tabular-nums">
                      {hosp.distanceKm} km · First Aid ~{hosp.etaMinutes} min
                    </p>
                  </div>
                  <a
                    href={`tel:${hosp.emergencyPhone.replace(/[^+\d]/g, '')}`}
                    className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded bg-[#12345A] hover:bg-[#168BFF] text-white font-mono text-[11px] whitespace-nowrap shrink-0"
                  >
                    <PhoneCall className="w-3 h-3" />
                    Call ER
                  </a>
                </div>
              ))}
            </div>
          </div>

          {aiPreview && (
            <div className="bg-[#091426] border border-[#38BDF8]/40 rounded-xl p-5 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-[#38BDF8]">
                  AI Triage Preview ({aiPreview.modelUsed})
                </span>
                <span className="font-mono text-sm font-bold text-white">
                  {aiPreview.severityScore}/100 · <PriorityBadgeText priority={aiPreview.priority} />
                </span>
              </div>
              <p className="text-xs text-[#D9EEFF] leading-relaxed">{aiPreview.explanation}</p>
              {aiPreview.imageAnalysis && (
                <div className="p-2.5 rounded-lg bg-[#071A33] border border-white/10 text-xs text-[#94A3B8]">
                  <span className="text-[#38BDF8] font-medium">Vision Check: </span>
                  {aiPreview.imageAnalysis.visualFindings}
                </div>
              )}
              {duplicatePreview.length > 0 && (
                <div className="p-2.5 rounded-lg bg-[#FFD43B]/10 border border-[#FFD43B]/40 text-xs text-[#FFF0A6]">
                  Possible duplicate of {duplicatePreview[0].incidentCode} ({duplicatePreview[0].distanceKm} km away). Report will still be recorded for operator verification.
                </div>
              )}
            </div>
          )}
        </div>
      </form>
    </PortalShell>
  );
};

export const CitizenMyReportsPage: React.FC = () => {
  const { incidents, sessionUser } = useDisaster();
  const [query, setQuery] = useState('');

  const visibleReports = useMemo(() => {
    const ownedOrDemo = sessionUser?.isDemoSession
      ? incidents
      : incidents.filter((i) => !sessionUser || i.reporterUid === sessionUser.uid || i.isDemo);

    return ownedOrDemo.filter((i) => {
      if (!query.trim()) return true;
      const q = query.toLowerCase();
      return (
        i.incidentCode.toLowerCase().includes(q) ||
        i.title.toLowerCase().includes(q) ||
        i.address.toLowerCase().includes(q)
      );
    });
  }, [incidents, query, sessionUser]);

  return (
    <PortalShell portal="citizen" breadcrumb="My Reports">
      <div className="space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-xl font-display font-bold text-white">Submitted Emergency Reports</h1>
            <p className="text-xs text-[#94A3B8] mt-1">
              Track response progression and rescue team assignments.
            </p>
          </div>
          <div className="relative w-full sm:w-72">
            <Search className="w-4 h-4 text-[#94A3B8] absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search by ID or address..."
              className="w-full pl-9 pr-3 py-2 rounded-lg bg-[#091426] border border-white/10 text-xs text-white"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {visibleReports.map((inc) => (
            <div key={inc.id} className="bg-[#091426] border border-[#1E3A5F] rounded-xl p-5 space-y-3">
              <div className="flex items-center justify-between text-xs">
                <span className="font-mono text-[#38BDF8]">{inc.incidentCode} · {inc.category}</span>
                <PriorityBadgeText priority={inc.priority} />
              </div>
              <h3 className="text-base font-bold text-white">{inc.title}</h3>
              <p className="text-xs text-[#94A3B8] flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 shrink-0" />
                <span className="truncate">{inc.address}</span>
              </p>
              <div className="flex items-center justify-between pt-3 border-t border-white/10 text-xs">
                <StatusText status={inc.status} />
                <Link to={`/citizen/track/${inc.id}`} className="text-[#38BDF8] font-semibold hover:underline">
                  Open Live Tracker
                </Link>
              </div>
            </div>
          ))}
        </div>
      </div>
    </PortalShell>
  );
};

const TIMELINE_STEPS = [
  'Submitted',
  'Under Review',
  'Verified',
  'Team Assigned',
  'Team En Route',
  'Rescue in Progress',
  'Resolved',
  'Closed',
];

export const TrackEmergencyPage: React.FC = () => {
  const { incidentId } = useParams<{ incidentId: string }>();
  const {
    incidents,
    teams,
    hospitalAlerts,
    fetchNearbyHospitals,
    notifyNearbyHospitals,
  } = useDisaster();
  const [nearbyHospitals, setNearbyHospitals] = useState<Hospital[]>([]);
  const [notifying, setNotifying] = useState(false);

  const incident = useMemo(
    () => incidents.find((i) => i.id === incidentId || i.incidentCode === incidentId) || incidents[0],
    [incidents, incidentId]
  );

  useEffect(() => {
    if (!incident) return;
    let active = true;
    fetchNearbyHospitals(incident.lat, incident.lng, 3).then((list) => {
      if (active) setNearbyHospitals(list);
    });
    return () => {
      active = false;
    };
  }, [fetchNearbyHospitals, incident]);

  const incidentHospitalAlerts = useMemo(
    () => (incident ? hospitalAlerts.filter((a) => a.incidentId === incident.id) : []),
    [hospitalAlerts, incident]
  );

  if (!incident) {
    return (
      <PortalShell portal="citizen" breadcrumb="Track Emergency">
        <div className="bg-[#091426] border border-[#1E3A5F] rounded-xl p-8 text-center space-y-3">
          <p className="text-base font-semibold text-white">Incident record not found</p>
          <Link to="/citizen/my-reports" className="text-xs text-[#38BDF8] hover:underline">
            Return to My Reports
          </Link>
        </div>
      </PortalShell>
    );
  }

  const currentStepIdx = Math.max(0, TIMELINE_STEPS.indexOf(incident.status));
  const assignedTeam = incident.assignedTeamId
    ? teams.filter((t) => t.id === incident.assignedTeamId)
    : [];

  return (
    <PortalShell portal="citizen" breadcrumb={`Track ${incident.incidentCode}`}>
      <div className="space-y-6">
        <div className="bg-[#091426] border border-[#1E3A5F] rounded-xl p-6 space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 text-xs font-mono text-[#38BDF8]">
                <span>{incident.incidentCode}</span>
                <span aria-hidden="true">·</span>
                <span>{incident.category}</span>
                <span aria-hidden="true">·</span>
                <PriorityBadgeText priority={incident.priority} />
              </div>
              <h1 className="text-2xl font-display font-bold text-white mt-1">{incident.title}</h1>
              <p className="text-xs text-[#94A3B8] mt-1">{incident.address}</p>
            </div>
            <div className="bg-[#071A33] border border-white/10 rounded-lg px-4 py-3 text-right shrink-0">
              <p className="text-[11px] text-[#94A3B8]">Current Status</p>
              <div className="mt-0.5">
                <StatusText status={incident.status} />
              </div>
            </div>
          </div>

          {/* 8-Stage Progress Stepper */}
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-2 pt-2">
            {TIMELINE_STEPS.map((step, idx) => {
              const reached = idx <= currentStepIdx;
              const isCurrent = idx === currentStepIdx;
              return (
                <div
                  key={step}
                  className={`p-2.5 rounded-lg border text-xs ${
                    isCurrent
                      ? 'bg-[#168BFF]/20 border-[#38BDF8] text-white font-semibold'
                      : reached
                      ? 'bg-[#22C55E]/10 border-[#22C55E]/30 text-[#D9EEFF]'
                      : 'bg-[#071A33] border-white/5 text-[#94A3B8]'
                  }`}
                >
                  <p className="font-mono text-[10px] opacity-75">0{idx + 1}</p>
                  <p className="mt-0.5 truncate">{step}</p>
                </div>
              );
            })}
          </div>
        </div>

        <EmergencyQuickDialStrip
          compact
          highlightFire={incident.category === 'Fire'}
          highlightAmbulance={
            incident.category === 'Medical Emergency' ||
            incident.category === 'Road Accident' ||
            incident.injuredCount > 0
          }
        />

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-5 space-y-5">
            <div className="bg-[#091426] border border-[#1E3A5F] rounded-xl p-5 space-y-3">
              <h2 className="text-sm font-bold text-white flex items-center gap-2">
                <Truck className="w-4 h-4 text-[#38BDF8]" />
                Assigned Rescue Team
              </h2>
              {incident.assignedTeamName ? (
                <div className="space-y-1.5 text-sm">
                  <p className="font-semibold text-white">{incident.assignedTeamName}</p>
                  <p className="text-xs text-[#94A3B8]">
                    Estimated Arrival:{' '}
                    <span className="font-mono text-[#FFD43B]">
                      {incident.etaMinutes && incident.etaMinutes > 0
                        ? `${incident.etaMinutes} min`
                        : incident.status === 'Rescue in Progress' || incident.status === 'Resolved'
                        ? 'On Site / Completed'
                        : 'Calculating'}
                    </span>
                  </p>
                </div>
              ) : (
                <p className="text-xs text-[#94A3B8]">
                  Awaiting command center team assignment. Operators have prioritized this report at {incident.severityScore}/100.
                </p>
              )}
            </div>

            {/* Nearby Hospital First-Aid Alerts */}
            <div className="bg-[#091426] border border-[#1E3A5F] rounded-xl p-5 space-y-3">
              <div className="flex items-center justify-between gap-2">
                <h2 className="text-sm font-bold text-white flex items-center gap-2">
                  <Building2 className="w-4 h-4 text-[#22C55E]" />
                  Nearby Hospital First-Aid Alerts
                </h2>
                {incidentHospitalAlerts.length < 2 && (
                  <button
                    type="button"
                    disabled={notifying}
                    onClick={async () => {
                      setNotifying(true);
                      try {
                        await notifyNearbyHospitals(incident.id);
                      } finally {
                        setNotifying(false);
                      }
                    }}
                    className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-[#22C55E]/20 border border-[#22C55E]/40 hover:bg-[#22C55E] hover:text-[#071A33] text-[11px] font-semibold text-white transition-colors whitespace-nowrap"
                  >
                    <BellRing className="w-3 h-3" />
                    {notifying ? 'Alerting...' : 'Notify Nearby Hospitals'}
                  </button>
                )}
              </div>

              {incidentHospitalAlerts.length > 0 ? (
                <div className="space-y-2.5">
                  {incidentHospitalAlerts.map((ha) => (
                    <div
                      key={ha.id}
                      className="bg-[#071A33] border border-white/10 rounded-lg p-3 space-y-1.5 text-xs"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="font-semibold text-white">{ha.hospitalName}</span>
                        <StatusText status={ha.status} />
                      </div>
                      <p className="text-[#94A3B8] font-mono tabular-nums">
                        {ha.distanceKm} km · First Aid ETA ~{ha.firstAidEtaMinutes} min
                      </p>
                      {ha.notes && <p className="text-[#D9EEFF] text-[11px]">{ha.notes}</p>}
                      <a
                        href={`tel:${ha.hospitalPhone.replace(/[^+\d]/g, '')}`}
                        className="inline-flex items-center gap-1 font-mono text-[11px] text-[#38BDF8] hover:underline"
                      >
                        <PhoneCall className="w-3 h-3" />
                        {ha.hospitalPhone}
                      </a>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-[#94A3B8]">
                  No nearby hospital alert sent yet. Click &quot;Notify Nearby Hospitals&quot; to request rapid first aid.
                </p>
              )}
            </div>

            <div className="bg-[#091426] border border-[#1E3A5F] rounded-xl p-5 space-y-4">
              <h2 className="text-sm font-bold text-white flex items-center gap-2">
                <Clock className="w-4 h-4 text-[#38BDF8]" />
                Status Timeline
              </h2>
              <div className="space-y-3">
                {incident.statusHistory.map((h) => (
                  <div key={h.id} className="pb-3 border-b border-white/5 last:border-none last:pb-0">
                    <div className="flex items-center justify-between text-xs">
                      <StatusText status={h.status} />
                      <span className="font-mono text-[11px] text-[#94A3B8]">
                        {new Date(h.createdAt).toLocaleTimeString()}
                      </span>
                    </div>
                    <p className="text-xs text-[#D9EEFF] mt-1">{h.note}</p>
                    <p className="text-[11px] text-[#94A3B8] mt-0.5">By {h.actorName}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="lg:col-span-7">
            <EmergencyMap
              incidents={[incident]}
              teams={assignedTeam}
              hospitals={nearbyHospitals}
              selectedIncidentId={incident.id}
              heightClass="h-[480px]"
              showControls={false}
              center={[incident.lat, incident.lng]}
              zoom={13}
            />
          </div>
        </div>
      </div>
    </PortalShell>
  );
};

export const CitizenSafetyCenterPage: React.FC = () => {
  return (
    <PortalShell portal="citizen" breadcrumb="Safety Center">
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-display font-bold text-white">Citizen Safety Center</h1>
          <p className="text-sm text-[#94A3B8] mt-1">
            Standard operating preparedness instructions for Pakistan emergencies.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {SAFETY_PROTOCOLS.map((guide) => (
            <div key={guide.id} className="bg-[#091426] border border-[#1E3A5F] rounded-xl p-6 space-y-3">
              <div className="flex items-center gap-2 text-[#38BDF8]">
                <ShieldCheck className="w-5 h-5" />
                <h2 className="text-lg font-bold text-white">{guide.title}</h2>
              </div>
              <p className="text-xs text-[#94A3B8]">{guide.summary}</p>
              <ul className="space-y-2 text-sm text-[#D9EEFF] pt-1">
                {guide.steps.map((s, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-[#22C55E] shrink-0 mt-0.5" />
                    <span>{s}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </PortalShell>
  );
};
