import React, { useMemo, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  Activity,
  AlertTriangle,
  ArrowRight,
  CheckCircle2,
  Cpu,
  MapPin,
  PhoneCall,
  Radio,
  Shield,
  ShieldCheck,
  Truck,
  Users,
} from 'lucide-react';
import { PublicTopBar } from '../components/layout/AppShells';
import {
  Call1122Modal,
  EmergencyQuickDialStrip,
  PriorityBadgeText,
  SAFETY_PROTOCOLS,
  StatusText,
} from '../components/ui/DisasterPrimitives';
import { useDisaster } from '../context/DisasterContext';
import type { UserRole } from '../types/disaster';

export const LandingPage: React.FC = () => {
  const { incidents, teams, demoMode, signInDemoRole } = useDisaster();
  const [callOpen, setCallOpen] = useState(false);
  const navigate = useNavigate();

  const stats = useMemo(() => {
    const active = incidents.filter((i) => i.status !== 'Resolved' && i.status !== 'Closed' && i.status !== 'Rejected').length;
    const critical = incidents.filter((i) => i.priority === 'CRITICAL' && i.status !== 'Resolved' && i.status !== 'Closed').length;
    const availableTeams = teams.filter((t) => t.status === 'Available').length;
    const resolved = incidents.filter((i) => i.status === 'Resolved' || i.status === 'Closed').length;
    return { active, critical, availableTeams, resolved, total: incidents.length };
  }, [incidents, teams]);

  const publicAlerts = useMemo(
    () => incidents.filter((i) => i.isPublicAlert && i.status !== 'Closed').slice(0, 4),
    [incidents]
  );

  const openPortal = (role: UserRole, path: string) => {
    signInDemoRole(role);
    navigate(path);
  };

  return (
    <div className="min-h-screen bg-[#071A33] text-[#F8FAFC] flex flex-col">
      <PublicTopBar />

      {/* Hero Split */}
      <section className="max-w-7xl mx-auto w-full px-6 pt-10 pb-12">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          <div className="lg:col-span-7 flex flex-col justify-center space-y-6">
            <div className="flex items-center gap-3 text-xs text-[#38BDF8] font-medium">
              <span>Pakistan Emergency Network</span>
              <span aria-hidden="true">·</span>
              <span>Karachi Command Hub</span>
              {demoMode && (
                <>
                  <span aria-hidden="true">·</span>
                  <span className="text-[#FFD43B] font-mono">DEMO DATA</span>
                </>
              )}
            </div>

            <h1 className="text-4xl sm:text-5xl font-display font-bold tracking-tight text-white leading-[1.12] [text-wrap:balance]">
              Intelligent Emergency Response &amp; Rescue Coordination
            </h1>

            <p className="text-base text-[#D9EEFF]/85 max-w-2xl leading-relaxed">
              DisasterAI connects citizens in distress with emergency command operators and field rescue squads through AI severity triage, duplicate incident detection, and live GIS routing across Karachi and major Pakistani cities.
            </p>

            <div className="flex flex-wrap items-center gap-3 pt-1">
              <button
                type="button"
                onClick={() => openPortal('Citizen', '/citizen/report-emergency')}
                className="inline-flex items-center gap-2 px-5 py-3 rounded-lg bg-[#168BFF] hover:bg-[#38BDF8] hover:text-[#071A33] text-white text-sm font-semibold transition-colors"
              >
                Report an Emergency
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                type="button"
                onClick={() => setCallOpen(true)}
                className="inline-flex items-center gap-2 px-5 py-3 rounded-lg bg-[#EF4444] hover:bg-red-600 text-white text-sm font-semibold transition-colors"
              >
                <PhoneCall className="w-4 h-4" />
                Emergency Call 1122
              </button>

              <button
                type="button"
                onClick={() => openPortal('Emergency Operator', '/admin/dashboard')}
                className="inline-flex items-center gap-2 px-4 py-3 rounded-lg border border-white/15 hover:bg-white/5 text-[#D9EEFF] text-sm font-medium transition-colors"
              >
                Command Center
              </button>
            </div>
          </div>

          <div className="lg:col-span-5">
            <div className="relative rounded-xl overflow-hidden border border-[#1E3A5F] bg-[#091426] h-72 lg:h-full min-h-[300px]">
              <img
                src="/src/assets/images/hero_command_karachi_1794977833026.jpg"
                alt="Karachi urban infrastructure and emergency arterial corridor at dusk"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#071A33] via-[#071A33]/40 to-transparent" />
              <div className="absolute bottom-4 left-4 right-4 space-y-1">
                <p className="text-xs font-mono text-[#38BDF8]">
                  24.8607° N · 67.0011° E · KARACHI SECTOR
                </p>
                <p className="text-sm font-semibold text-white">
                  Real-time arterial dispatch &amp; multimodal AI hazard triage
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Direct Emergency Calling Strip */}
        <div className="mt-8">
          <EmergencyQuickDialStrip />
        </div>

        {/* 4-column KPI strip below hero */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mt-6">
          <div className="bg-[#091426] border border-[#1E3A5F] rounded-xl p-5">
            <p className="text-xs text-[#94A3B8]">Active Emergencies</p>
            <p className="text-3xl font-mono font-bold text-white mt-1 tabular-nums">{stats.active}</p>
            <p className="text-xs text-[#94A3B8] mt-1">Out of {stats.total} logged reports</p>
          </div>
          <div className="bg-[#091426] border border-[#EF4444]/35 rounded-xl p-5">
            <p className="text-xs text-[#94A3B8]">Critical Priority</p>
            <p className="text-3xl font-mono font-bold text-[#EF4444] mt-1 tabular-nums">{stats.critical}</p>
            <p className="text-xs text-[#94A3B8] mt-1">Severity score 75–100</p>
          </div>
          <div className="bg-[#091426] border border-[#1E3A5F] rounded-xl p-5">
            <p className="text-xs text-[#94A3B8]">Available Rescue Units</p>
            <p className="text-3xl font-mono font-bold text-[#22C55E] mt-1 tabular-nums">{stats.availableTeams}</p>
            <p className="text-xs text-[#94A3B8] mt-1">Across {teams.length} active squads</p>
          </div>
          <div className="bg-[#091426] border border-[#1E3A5F] rounded-xl p-5">
            <p className="text-xs text-[#94A3B8]">Resolved Incidents</p>
            <p className="text-3xl font-mono font-bold text-[#38BDF8] mt-1 tabular-nums">{stats.resolved}</p>
            <p className="text-xs text-[#94A3B8] mt-1">Completed &amp; verified</p>
          </div>
        </div>
      </section>

      {/* Three Portals Section */}
      <section className="max-w-7xl mx-auto w-full px-6 py-10 border-t border-white/10">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
          <div>
            <h2 className="text-2xl font-display font-bold text-white">Three Coordinated Portals</h2>
            <p className="text-sm text-[#94A3B8] mt-1">
              Role-isolated workflows synchronized over WebSockets for immediate multi-agency response.
            </p>
          </div>
          <Link to="/login" className="text-xs font-medium text-[#38BDF8] hover:underline whitespace-nowrap">
            Sign in with Google or Demo Role
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-[#091426] border border-[#1E3A5F] rounded-xl p-6 flex flex-col justify-between space-y-5">
            <div className="space-y-3">
              <div className="w-10 h-10 rounded-lg bg-[#168BFF]/15 border border-[#168BFF]/30 flex items-center justify-center text-[#38BDF8]">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <h3 className="text-lg font-bold text-white">Citizen Portal</h3>
              <p className="text-sm text-[#94A3B8] leading-relaxed">
                Submit geotagged emergency reports with photos, place confirmed 1122 calls, track rescue arrival timelines, and access survival guides.
              </p>
            </div>
            <button
              type="button"
              onClick={() => openPortal('Citizen', '/citizen/dashboard')}
              className="w-full py-2.5 px-4 rounded-lg bg-[#12345A] hover:bg-[#168BFF] text-white text-xs font-semibold transition-colors flex items-center justify-center gap-2"
            >
              Launch Citizen Portal
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="bg-[#091426] border border-[#38BDF8]/35 rounded-xl p-6 flex flex-col justify-between space-y-5">
            <div className="space-y-3">
              <div className="w-10 h-10 rounded-lg bg-[#168BFF]/15 border border-[#38BDF8]/40 flex items-center justify-center text-[#38BDF8]">
                <Shield className="w-5 h-5" />
              </div>
              <h3 className="text-lg font-bold text-white">Emergency Command Center</h3>
              <p className="text-sm text-[#94A3B8] leading-relaxed">
                Monitor the live Karachi GIS map, inspect explainable AI severity scores, merge duplicate alerts, dispatch recommended squads, and analyze trends.
              </p>
            </div>
            <button
              type="button"
              onClick={() => openPortal('Emergency Operator', '/admin/dashboard')}
              className="w-full py-2.5 px-4 rounded-lg bg-[#168BFF] hover:bg-[#38BDF8] hover:text-[#071A33] text-white text-xs font-semibold transition-colors flex items-center justify-center gap-2"
            >
              Launch Command Center
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="bg-[#091426] border border-[#1E3A5F] rounded-xl p-6 flex flex-col justify-between space-y-5">
            <div className="space-y-3">
              <div className="w-10 h-10 rounded-lg bg-[#22C55E]/15 border border-[#22C55E]/30 flex items-center justify-center text-[#22C55E]">
                <Truck className="w-5 h-5" />
              </div>
              <h3 className="text-lg font-bold text-white">Rescue Team Portal</h3>
              <p className="text-sm text-[#94A3B8] leading-relaxed">
                Receive dispatch orders in real time, accept or decline with reason, update En Route and On Site status, request supplies, and file final reports.
              </p>
            </div>
            <button
              type="button"
              onClick={() => openPortal('Rescue Team Leader', '/team/dashboard')}
              className="w-full py-2.5 px-4 rounded-lg bg-[#12345A] hover:bg-[#168BFF] text-white text-xs font-semibold transition-colors flex items-center justify-center gap-2"
            >
              Launch Rescue Portal
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </section>

      {/* Active Public Alerts */}
      <section className="max-w-7xl mx-auto w-full px-6 py-10 border-t border-white/10">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-xl font-display font-bold text-white">Active Public Alerts</h2>
            <p className="text-xs text-[#94A3B8] mt-1">
              Live verified high-priority advisories across monitored districts
            </p>
          </div>
          <Link to="/safety" className="text-xs text-[#38BDF8] hover:underline">
            Safety Guidelines
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {publicAlerts.map((inc) => (
            <div
              key={inc.id}
              className="bg-[#091426] border border-[#1E3A5F] rounded-xl p-4 flex flex-col justify-between gap-3"
            >
              <div className="space-y-1.5">
                <div className="flex items-center justify-between gap-2 text-xs">
                  <span className="font-mono text-[#38BDF8]">
                    {inc.incidentCode} · {inc.category}
                  </span>
                  <PriorityBadgeText priority={inc.priority} />
                </div>
                <h3 className="text-sm font-semibold text-white">{inc.title}</h3>
                <p className="text-xs text-[#94A3B8] flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5 shrink-0" />
                  <span className="truncate">{inc.address}</span>
                </p>
              </div>
              <div className="flex items-center justify-between text-xs pt-2 border-t border-white/5">
                <StatusText status={inc.status} />
                <Link
                  to={`/citizen/track/${inc.id}`}
                  className="text-[#38BDF8] hover:underline font-medium"
                >
                  Track Response
                </Link>
              </div>
            </div>
          ))}
        </div>
      </section>

      <footer className="mt-auto border-t border-white/10 bg-[#091426] py-6 px-6">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#94A3B8]">
          <span>DisasterAI — Emergency Response &amp; Rescue Coordination Platform (Pakistan)</span>
          <div className="flex items-center gap-6">
            <Link to="/about" className="hover:text-white">Architecture</Link>
            <Link to="/safety" className="hover:text-white">Safety Center</Link>
            <Link to="/login" className="hover:text-white">Portal Access</Link>
          </div>
        </div>
      </footer>

      <Call1122Modal open={callOpen} onClose={() => setCallOpen(false)} />
    </div>
  );
};

export const LoginPage: React.FC<{ mode?: 'login' | 'register' }> = ({ mode = 'login' }) => {
  const { signInWithGoogle, signInDemoRole, teams, pushToast } = useDisaster();
  const navigate = useNavigate();
  const [busy, setBusy] = useState(false);
  const [selectedTeamId, setSelectedTeamId] = useState(teams[3]?.id || 'team_gulshan_usar');

  const handleGoogleLogin = async () => {
    setBusy(true);
    try {
      await signInWithGoogle();
      navigate('/citizen/dashboard');
    } catch (err: any) {
      pushToast({
        title: 'Google Sign-In did not complete',
        description: err?.message || 'You can also use the instant Demo Role portals below.',
        tone: 'warning',
      });
    } finally {
      setBusy(false);
    }
  };

  const handleDemoAccess = (role: UserRole, path: string) => {
    signInDemoRole(
      role,
      undefined,
      role === 'Rescue Team Leader' ? selectedTeamId : undefined
    );
    navigate(path);
  };

  return (
    <div className="min-h-screen bg-[#071A33] text-[#F8FAFC] flex flex-col">
      <PublicTopBar />
      <div className="flex-1 flex items-center justify-center p-6">
        <div className="max-w-3xl w-full grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Google Auth Card */}
          <div className="bg-[#091426] border border-[#1E3A5F] rounded-xl p-6 space-y-5">
            <div>
              <h1 className="text-2xl font-display font-bold text-white">
                {mode === 'register' ? 'Create DisasterAI Account' : 'Sign In to DisasterAI'}
              </h1>
              <p className="text-sm text-[#94A3B8] mt-1">
                Authenticate securely with Firebase Auth to persist citizen reports and role permissions.
              </p>
            </div>

            <button
              type="button"
              disabled={busy}
              onClick={handleGoogleLogin}
              className="w-full py-3 px-4 rounded-lg bg-[#168BFF] hover:bg-[#38BDF8] hover:text-[#071A33] disabled:opacity-60 text-white text-sm font-semibold transition-colors flex items-center justify-center gap-2"
            >
              <ShieldCheck className="w-4 h-4" />
              {busy ? 'Connecting to Google...' : 'Continue with Google'}
            </button>

            <div className="pt-3 border-t border-white/10 text-xs text-[#94A3B8] space-y-1.5">
              <p>Role-Based Access Control:</p>
              <p>Citizen accounts track personal reports and receive public advisories. Verified Operators &amp; Administrators access dispatch, analytics, and audit controls.</p>
            </div>

            <p className="text-xs text-[#94A3B8]">
              {mode === 'register' ? (
                <>
                  Already registered?{' '}
                  <Link to="/login" className="text-[#38BDF8] hover:underline">
                    Sign in
                  </Link>
                </>
              ) : (
                <>
                  New citizen reporter?{' '}
                  <Link to="/register" className="text-[#38BDF8] hover:underline">
                    Register account
                  </Link>
                </>
              )}
            </p>
          </div>

          {/* Demo Role Switcher */}
          <div className="bg-[#091426] border border-[#FFD43B]/30 rounded-xl p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-bold text-white">Hackathon Demo Portals</h2>
              <span className="font-mono text-xs text-[#FFD43B]">DEMO MODE</span>
            </div>
            <p className="text-xs text-[#94A3B8]">
              Switch instantly between roles to test end-to-end citizen reporting, AI triage, command dispatch, and rescue field operations.
            </p>

            <div className="space-y-2.5">
              <button
                type="button"
                onClick={() => handleDemoAccess('Citizen', '/citizen/dashboard')}
                className="w-full p-3 rounded-lg bg-[#071A33] border border-white/10 hover:border-[#38BDF8] text-left transition-colors"
              >
                <p className="text-sm font-semibold text-white">Citizen Portal (DEMO)</p>
                <p className="text-xs text-[#94A3B8]">Report emergencies, GPS pin, Call 1122, track response</p>
              </button>

              <button
                type="button"
                onClick={() => handleDemoAccess('Emergency Operator', '/admin/dashboard')}
                className="w-full p-3 rounded-lg bg-[#071A33] border border-white/10 hover:border-[#38BDF8] text-left transition-colors"
              >
                <p className="text-sm font-semibold text-white">Emergency Command Center (DEMO)</p>
                <p className="text-xs text-[#94A3B8]">Live GIS map, AI scoring, duplicate merge, team dispatch</p>
              </button>

              <div className="p-3 rounded-lg bg-[#071A33] border border-white/10 space-y-2">
                <div className="flex items-center justify-between gap-2">
                  <p className="text-sm font-semibold text-white">Rescue Team Leader (DEMO)</p>
                </div>
                <select
                  value={selectedTeamId}
                  onChange={(e) => setSelectedTeamId(e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded bg-[#091426] border border-white/10 text-xs text-[#D9EEFF]"
                >
                  {teams.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.name} ({t.status})
                    </option>
                  ))}
                </select>
                <button
                  type="button"
                  onClick={() => handleDemoAccess('Rescue Team Leader', '/team/dashboard')}
                  className="w-full py-2 rounded-lg bg-[#12345A] hover:bg-[#168BFF] text-white text-xs font-semibold transition-colors"
                >
                  Enter Selected Rescue Team Portal
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export const AboutPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-[#071A33] text-[#F8FAFC] flex flex-col">
      <PublicTopBar />
      <main className="max-w-5xl mx-auto w-full px-6 py-12 space-y-10">
        <div className="space-y-3">
          <h1 className="text-3xl font-display font-bold text-white">
            DisasterAI System Architecture
          </h1>
          <p className="text-base text-[#94A3B8] max-w-3xl leading-relaxed">
            Built for urban disaster resilience across Karachi, Lahore, Islamabad, and coastal Sindh—unifying citizen distress telemetry, multimodal AI triage, geospatial routing, and rescue squad coordination.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-[#091426] border border-[#1E3A5F] rounded-xl p-6 space-y-2.5">
            <Cpu className="w-5 h-5 text-[#38BDF8]" />
            <h2 className="text-lg font-bold text-white">Explainable AI Severity &amp; Vision Triage</h2>
            <p className="text-sm text-[#94A3B8] leading-relaxed">
              Combines Gemini multimodal analysis with a transparent deterministic rule-based fallback. Every 0–100 score breaks down contributing risk factors while preserving human operator override authority.
            </p>
          </div>

          <div className="bg-[#091426] border border-[#1E3A5F] rounded-xl p-6 space-y-2.5">
            <Users className="w-5 h-5 text-[#FFD43B]" />
            <h2 className="text-lg font-bold text-white">Duplicate Detection &amp; Preservation</h2>
            <p className="text-sm text-[#94A3B8] leading-relaxed">
              Evaluates Haversine proximity, category alignment, reporting window, and text similarity to flag possible duplicate citizen reports without ever discarding original witness data.
            </p>
          </div>

          <div className="bg-[#091426] border border-[#1E3A5F] rounded-xl p-6 space-y-2.5">
            <Radio className="w-5 h-5 text-[#22C55E]" />
            <h2 className="text-lg font-bold text-white">Real-Time WebSocket Synchronization</h2>
            <p className="text-sm text-[#94A3B8] leading-relaxed">
              Status transitions—from citizen submission to operator verification, team acceptance, En Route GPS updates, and final resolution—propagate across all portals instantaneously.
            </p>
          </div>

          <div className="bg-[#091426] border border-[#1E3A5F] rounded-xl p-6 space-y-2.5">
            <Activity className="w-5 h-5 text-[#38BDF8]" />
            <h2 className="text-lg font-bold text-white">OpenStreetMap &amp; OSRM Dispatch Routing</h2>
            <p className="text-sm text-[#94A3B8] leading-relaxed">
              Computes live road routes and ETA estimates between rescue stations and incident coordinates, ranking squads by specialization, equipment readiness, and distance.
            </p>
          </div>
        </div>
      </main>
    </div>
  );
};

export const PublicSafetyPage: React.FC = () => {
  const [callOpen, setCallOpen] = useState(false);

  return (
    <div className="min-h-screen bg-[#071A33] text-[#F8FAFC] flex flex-col">
      <PublicTopBar />
      <main className="max-w-5xl mx-auto w-full px-6 py-12 space-y-8">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-display font-bold text-white">
              Emergency Safety &amp; Preparedness Center
            </h1>
            <p className="text-sm text-[#94A3B8] mt-1">
              Actionable response protocols for Pakistan&apos;s highest-frequency urban hazards.
            </p>
          </div>
          <button
            type="button"
            onClick={() => setCallOpen(true)}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-[#EF4444] hover:bg-red-600 text-white text-xs font-semibold whitespace-nowrap shrink-0"
          >
            <PhoneCall className="w-4 h-4" />
            Call 1122 / 115 / 101
          </button>
        </div>

        <EmergencyQuickDialStrip compact />

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {SAFETY_PROTOCOLS.map((guide) => (
            <div key={guide.id} className="bg-[#091426] border border-[#1E3A5F] rounded-xl p-6 space-y-4">
              <div>
                <h2 className="text-lg font-bold text-white">{guide.title}</h2>
                <p className="text-xs text-[#94A3B8] mt-1">{guide.summary}</p>
              </div>
              <ul className="space-y-2.5 text-sm text-[#D9EEFF]">
                {guide.steps.map((step, idx) => (
                  <li key={idx} className="flex items-start gap-2.5">
                    <CheckCircle2 className="w-4 h-4 text-[#22C55E] shrink-0 mt-0.5" />
                    <span>{step}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </main>
      <Call1122Modal open={callOpen} onClose={() => setCallOpen(false)} />
    </div>
  );
};
