import React, { useMemo, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import {
  CheckCircle2,
  ClipboardCheck,
  MapPin,
  Navigation,
  Package,
  Radio,
  Truck,
  Upload,
  XCircle,
} from 'lucide-react';
import { PortalShell } from '../components/layout/AppShells';
import { EmergencyMap } from '../components/map/EmergencyMap';
import { ConfirmDialog, PriorityBadgeText, StatusText } from '../components/ui/DisasterPrimitives';
import { useDisaster } from '../context/DisasterContext';

export const TeamDashboardPage: React.FC = () => {
  const { teams, assignments, incidents, sessionUser } = useDisaster();
  const [selectedTeamId, setSelectedTeamId] = useState<string>(
    sessionUser?.teamId || 'team_gulshan_usar'
  );

  const activeTeam = useMemo(
    () => teams.find((t) => t.id === selectedTeamId) || teams[0],
    [teams, selectedTeamId]
  );

  const teamAssignments = useMemo(
    () => assignments.filter((a) => !activeTeam || a.teamId === activeTeam.id),
    [assignments, activeTeam]
  );

  const activeAssignment = teamAssignments.find((a) => a.status !== 'Completed' && a.status !== 'Rejected');
  const activeIncident = activeAssignment
    ? incidents.find((i) => i.id === activeAssignment.incidentId)
    : null;

  return (
    <PortalShell portal="team" breadcrumb="Team Operations">
      <div className="space-y-6">
        <div className="bg-[#091426] border border-[#1E3A5F] rounded-xl p-6 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2 text-xs font-mono text-[#38BDF8]">
              <Radio className="w-3.5 h-3.5" />
              <span>{activeTeam?.teamCode}</span>
              <span aria-hidden="true">·</span>
              <span>{activeTeam?.teamType}</span>
            </div>
            <h1 className="text-2xl font-display font-bold text-white">{activeTeam?.name}</h1>
            <p className="text-xs text-[#94A3B8]">
              Leader: {activeTeam?.leaderName} · Vehicle: {activeTeam?.vehicleInfo}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <select
              value={selectedTeamId}
              onChange={(e) => setSelectedTeamId(e.target.value)}
              className="px-3 py-2 rounded-lg bg-[#071A33] border border-white/15 text-xs text-white"
              aria-label="Select rescue unit view"
            >
              {teams.map((t) => (
                <option key={t.id} value={t.id}>
                  {t.name} ({t.status})
                </option>
              ))}
            </select>
            <div className="px-3.5 py-2 rounded-lg bg-[#071A33] border border-white/10">
              <StatusText status={activeTeam?.status || 'Available'} />
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-5 space-y-5">
            <div className="bg-[#091426] border border-[#1E3A5F] rounded-xl p-5 space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-base font-bold text-white">Active Dispatch Order</h2>
                <Link to="/team/assignments" className="text-xs text-[#38BDF8] hover:underline">
                  All Assignments
                </Link>
              </div>

              {activeAssignment ? (
                <div className="space-y-3">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-mono text-[#38BDF8]">{activeAssignment.incidentCode}</span>
                    <PriorityBadgeText priority={activeAssignment.incidentPriority} />
                  </div>
                  <h3 className="text-base font-bold text-white">{activeAssignment.incidentTitle}</h3>
                  <p className="text-xs text-[#94A3B8] flex items-center gap-1.5">
                    <MapPin className="w-3.5 h-3.5 shrink-0" />
                    <span>{activeAssignment.incidentAddress}</span>
                  </p>
                  <div className="grid grid-cols-2 gap-3 text-xs pt-1">
                    <div className="bg-[#071A33] rounded-lg p-3 border border-white/5">
                      <p className="text-[#94A3B8]">Status</p>
                      <div className="mt-1">
                        <StatusText status={activeAssignment.status} />
                      </div>
                    </div>
                    <div className="bg-[#071A33] rounded-lg p-3 border border-white/5">
                      <p className="text-[#94A3B8]">Distance / ETA</p>
                      <p className="font-mono text-white mt-1">
                        {activeAssignment.distanceKm} km · {activeAssignment.etaMinutes} min
                      </p>
                    </div>
                  </div>
                  <Link
                    to={`/team/assignments/${activeAssignment.id}`}
                    className="block text-center w-full py-2.5 rounded-lg bg-[#168BFF] hover:bg-[#38BDF8] hover:text-[#071A33] text-white text-xs font-semibold transition-colors"
                  >
                    Open Field Operations Console
                  </Link>
                </div>
              ) : (
                <div className="py-6 text-center space-y-2">
                  <p className="text-sm font-semibold text-white">Unit Standby — Available</p>
                  <p className="text-xs text-[#94A3B8]">
                    No active dispatch assigned to {activeTeam?.name}. Select another unit above or await Command Center orders.
                  </p>
                </div>
              )}
            </div>

            <div className="bg-[#091426] border border-[#1E3A5F] rounded-xl p-5 space-y-3">
              <h2 className="text-sm font-bold text-white">Unit Equipment Readiness</h2>
              <ul className="space-y-1.5 text-xs text-[#D9EEFF]">
                {activeTeam?.equipment.map((item) => (
                  <li key={item} className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#22C55E] shrink-0" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="lg:col-span-7">
            <EmergencyMap
              incidents={activeIncident ? [activeIncident] : incidents.slice(0, 6)}
              teams={activeTeam ? [activeTeam] : teams}
              selectedIncidentId={activeIncident?.id}
              heightClass="h-[460px]"
              showControls={false}
              center={activeTeam ? [activeTeam.lat, activeTeam.lng] : [24.865, 67.045]}
              zoom={12}
            />
          </div>
        </div>
      </div>
    </PortalShell>
  );
};

export const TeamAssignmentsPage: React.FC = () => {
  const { assignments } = useDisaster();

  return (
    <PortalShell portal="team" breadcrumb="Active Assignments">
      <div className="space-y-5">
        <div>
          <h1 className="text-xl font-display font-bold text-white">All Field Assignments</h1>
          <p className="text-xs text-[#94A3B8] mt-1">
            Select an assignment to accept, update En Route/On Site status, request supplies, or submit final rescue reports.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {assignments.map((asg) => (
            <div key={asg.id} className="bg-[#091426] border border-[#1E3A5F] rounded-xl p-5 space-y-3">
              <div className="flex items-center justify-between text-xs">
                <span className="font-mono text-[#38BDF8]">
                  {asg.incidentCode} · {asg.incidentCategory}
                </span>
                <PriorityBadgeText priority={asg.incidentPriority} />
              </div>
              <h2 className="text-base font-bold text-white">{asg.incidentTitle}</h2>
              <p className="text-xs text-[#94A3B8]">Assigned Unit: {asg.teamName}</p>
              <p className="text-xs text-[#D9EEFF]">{asg.incidentAddress}</p>
              <div className="flex items-center justify-between pt-3 border-t border-white/10 text-xs">
                <StatusText status={asg.status} />
                <Link
                  to={`/team/assignments/${asg.id}`}
                  className="px-3 py-1.5 rounded-lg bg-[#12345A] hover:bg-[#168BFF] text-white font-semibold"
                >
                  Manage Mission
                </Link>
              </div>
            </div>
          ))}
        </div>
      </div>
    </PortalShell>
  );
};

export const TeamAssignmentDetailPage: React.FC = () => {
  const { assignmentId } = useParams<{ assignmentId: string }>();
  const {
    assignments,
    incidents,
    teams,
    updateAssignmentStatus,
    updateTeamLocation,
    pushToast,
  } = useDisaster();

  const assignment = useMemo(
    () => assignments.find((a) => a.id === assignmentId) || assignments[0],
    [assignments, assignmentId]
  );
  const incident = incidents.find((i) => i.id === assignment?.incidentId);
  const team = teams.find((t) => t.id === assignment?.teamId);

  const [progressNote, setProgressNote] = useState(assignment?.progressNotes || '');
  const [rejectReason, setRejectReason] = useState('');
  const [showRejectModal, setShowRejectModal] = useState(false);
  const [selectedResources, setSelectedResources] = useState<string[]>([]);
  const [summary, setSummary] = useState('');
  const [peopleRescued, setPeopleRescued] = useState(incident?.peopleAffected || 0);
  const [casualtiesTreated, setCasualtiesTreated] = useState(incident?.injuredCount || 0);
  const [photoUrls, setPhotoUrls] = useState<string[]>([]);

  if (!assignment) {
    return (
      <PortalShell portal="team" breadcrumb="Mission Not Found">
        <div className="bg-[#091426] border border-[#1E3A5F] rounded-xl p-8 text-center">
          <p className="text-white">Assignment not found.</p>
          <Link to="/team/assignments" className="text-xs text-[#38BDF8] hover:underline">
            Return to Assignments
          </Link>
        </div>
      </PortalShell>
    );
  }

  const RESOURCE_NEEDS = [
    'Additional ALS Ambulance',
    'Heavy Dewatering Pump',
    'Foam Fire Tender',
    'Life Jackets (20x)',
    'USAR Shoring Kit',
    'Emergency Medical Supplies',
  ];

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []).slice(0, 3);
    for (const f of files) {
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          setPhotoUrls((prev) => [...prev.slice(0, 2), reader.result as string]);
        }
      };
      reader.readAsDataURL(f);
    }
  };

  const handleStepGPS = async () => {
    if (!team || !incident) return;
    const midLat = Number(((team.lat + incident.lat) / 2).toFixed(6));
    const midLng = Number(((team.lng + incident.lng) / 2).toFixed(6));
    await updateTeamLocation(team.id, midLat, midLng, 'En Route');
    pushToast({ title: 'Team GPS coordinates updated on Command Map', tone: 'success' });
  };

  return (
    <PortalShell portal="team" breadcrumb={assignment.incidentCode}>
      <div className="space-y-6">
        <div className="bg-[#091426] border border-[#1E3A5F] rounded-xl p-6 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-xs font-mono text-[#38BDF8]">
              <span>{assignment.incidentCode}</span>
              <span aria-hidden="true">·</span>
              <span>{assignment.teamName}</span>
              <span aria-hidden="true">·</span>
              <PriorityBadgeText priority={assignment.incidentPriority} />
            </div>
            <h1 className="text-2xl font-display font-bold text-white">{assignment.incidentTitle}</h1>
            <p className="text-xs text-[#94A3B8]">{assignment.incidentAddress}</p>
          </div>
          <div className="bg-[#071A33] border border-white/10 rounded-lg px-4 py-2.5">
            <p className="text-[11px] text-[#94A3B8]">Mission Status</p>
            <StatusText status={assignment.status} />
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left: Field Controls */}
          <div className="lg:col-span-6 space-y-5">
            <div className="bg-[#091426] border border-[#1E3A5F] rounded-xl p-5 space-y-4">
              <h2 className="text-sm font-bold text-white">Mission Status Controls</h2>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                <button
                  type="button"
                  onClick={() => updateAssignmentStatus(assignment.id, { status: 'Accepted', progressNotes: 'Assignment accepted by unit leader.' })}
                  className="py-2.5 px-3 rounded-lg bg-[#22C55E]/20 border border-[#22C55E]/40 hover:bg-[#22C55E] hover:text-[#071A33] text-xs font-semibold text-white transition-colors"
                >
                  Accept Order
                </button>
                <button
                  type="button"
                  onClick={() => setShowRejectModal(true)}
                  className="py-2.5 px-3 rounded-lg border border-[#EF4444]/40 text-[#EF4444] hover:bg-[#EF4444] hover:text-white text-xs font-semibold transition-colors"
                >
                  Reject w/ Reason
                </button>
                <button
                  type="button"
                  onClick={() => updateAssignmentStatus(assignment.id, { status: 'En Route', progressNotes: 'Squad departed station and en route.' })}
                  className="py-2.5 px-3 rounded-lg bg-[#12345A] hover:bg-[#168BFF] text-xs font-semibold text-white transition-colors"
                >
                  Mark En Route
                </button>
                <button
                  type="button"
                  onClick={() => updateAssignmentStatus(assignment.id, { status: 'On Site', progressNotes: 'Team arrived at incident perimeter.' })}
                  className="py-2.5 px-3 rounded-lg bg-[#12345A] hover:bg-[#168BFF] text-xs font-semibold text-white transition-colors"
                >
                  Mark On Site
                </button>
                <button
                  type="button"
                  onClick={() => updateAssignmentStatus(assignment.id, { status: 'In Progress', progressNotes: 'Active rescue and stabilization underway.' })}
                  className="py-2.5 px-3 rounded-lg bg-[#168BFF] hover:bg-[#38BDF8] hover:text-[#071A33] text-xs font-semibold text-white transition-colors"
                >
                  Start Rescue Ops
                </button>
                <button
                  type="button"
                  onClick={handleStepGPS}
                  className="py-2.5 px-3 rounded-lg border border-[#38BDF8]/40 text-[#38BDF8] hover:bg-[#38BDF8]/10 text-xs font-semibold transition-colors"
                >
                  Update GPS Ping
                </button>
              </div>

              <div className="pt-2 space-y-2">
                <label className="block text-xs font-medium text-[#D9EEFF]">Field Progress Update</label>
                <textarea
                  rows={2}
                  value={progressNote}
                  onChange={(e) => setProgressNote(e.target.value)}
                  placeholder="Enter live situational update for Command Center..."
                  className="w-full px-3 py-2 rounded-lg bg-[#071A33] border border-white/15 text-xs text-white"
                />
                <button
                  type="button"
                  onClick={() => updateAssignmentStatus(assignment.id, { progressNotes: progressNote })}
                  className="px-4 py-2 rounded-lg bg-[#12345A] hover:bg-[#168BFF] text-white text-xs font-semibold"
                >
                  Send Progress Update
                </button>
              </div>
            </div>

            {/* Request Additional Resources */}
            <div className="bg-[#091426] border border-[#1E3A5F] rounded-xl p-5 space-y-3">
              <h2 className="text-sm font-bold text-white flex items-center gap-2">
                <Package className="w-4 h-4 text-[#FFD43B]" />
                Request Additional Resources
              </h2>
              <div className="flex flex-wrap gap-2">
                {RESOURCE_NEEDS.map((res) => {
                  const selected = selectedResources.includes(res);
                  return (
                    <button
                      key={res}
                      type="button"
                      onClick={() =>
                        setSelectedResources((prev) =>
                          prev.includes(res) ? prev.filter((x) => x !== res) : [...prev, res]
                        )
                      }
                      className={`px-2.5 py-1.5 rounded-lg text-xs border transition-colors ${
                        selected
                          ? 'bg-[#FFD43B]/20 border-[#FFD43B] text-[#FFF0A6]'
                          : 'bg-[#071A33] border-white/10 text-[#94A3B8]'
                      }`}
                    >
                      {res}
                    </button>
                  );
                })}
              </div>
              <button
                type="button"
                disabled={selectedResources.length === 0}
                onClick={() => {
                  updateAssignmentStatus(assignment.id, { requestedResources: selectedResources });
                  setSelectedResources([]);
                }}
                className="px-4 py-2 rounded-lg bg-[#FFD43B] text-[#071A33] disabled:opacity-40 text-xs font-bold"
              >
                Transmit Resource Request
              </button>
            </div>

            {/* Final Rescue Completion Report */}
            <div className="bg-[#091426] border border-[#22C55E]/35 rounded-xl p-5 space-y-3">
              <h2 className="text-sm font-bold text-white flex items-center gap-2">
                <ClipboardCheck className="w-4 h-4 text-[#22C55E]" />
                Complete Mission &amp; Submit Final Rescue Report
              </h2>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] text-[#94A3B8] mb-1">People Rescued</label>
                  <input
                    type="number"
                    min={0}
                    value={peopleRescued}
                    onChange={(e) => setPeopleRescued(Math.max(0, Number(e.target.value)))}
                    className="w-full px-3 py-2 rounded-lg bg-[#071A33] border border-white/15 text-xs font-mono text-white"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-[#94A3B8] mb-1">Casualties Treated</label>
                  <input
                    type="number"
                    min={0}
                    value={casualtiesTreated}
                    onChange={(e) => setCasualtiesTreated(Math.max(0, Number(e.target.value)))}
                    className="w-full px-3 py-2 rounded-lg bg-[#071A33] border border-white/15 text-xs font-mono text-white"
                  />
                </div>
              </div>
              <textarea
                rows={3}
                value={summary}
                onChange={(e) => setSummary(e.target.value)}
                placeholder="Final operational summary, evacuations completed, and scene handoff..."
                className="w-full px-3 py-2 rounded-lg bg-[#071A33] border border-white/15 text-xs text-white"
              />
              <label className="inline-flex items-center gap-2 px-3 py-2 rounded-lg bg-[#071A33] border border-dashed border-white/20 text-xs text-[#D9EEFF] cursor-pointer">
                <Upload className="w-3.5 h-3.5" />
                <span>Attach Operation Photos ({photoUrls.length})</span>
                <input type="file" accept="image/*" multiple onChange={handlePhotoUpload} className="hidden" />
              </label>

              <div>
                <button
                  type="button"
                  onClick={() =>
                    updateAssignmentStatus(assignment.id, {
                      status: 'Completed',
                      summary: summary || 'Rescue operations completed and incident stabilized.',
                      peopleRescued,
                      casualtiesTreated,
                      photoUrls,
                    })
                  }
                  className="px-5 py-2.5 rounded-lg bg-[#22C55E] hover:bg-green-500 text-[#071A33] text-xs font-bold"
                >
                  Mark Completed &amp; Submit Report
                </button>
              </div>
            </div>
          </div>

          {/* Right: Live Map */}
          <div className="lg:col-span-6">
            <EmergencyMap
              incidents={incident ? [incident] : []}
              teams={team ? [team] : []}
              selectedIncidentId={incident?.id}
              heightClass="h-[520px]"
              showControls={false}
              center={[assignment.incidentLat, assignment.incidentLng]}
              zoom={12}
            />
          </div>
        </div>
      </div>

      {showRejectModal && (
        <div className="fixed inset-0 z-[1200] bg-black/70 flex items-center justify-center p-4">
          <div className="max-w-md w-full bg-[#091426] border border-[#EF4444]/40 rounded-xl p-6 space-y-4">
            <div className="flex items-center gap-2 text-[#EF4444]">
              <XCircle className="w-5 h-5" />
              <h3 className="text-base font-bold text-white">Decline Assignment</h3>
            </div>
            <p className="text-xs text-[#94A3B8]">
              Provide an operational reason so Command Center can immediately re-dispatch another unit.
            </p>
            <textarea
              rows={3}
              value={rejectReason}
              onChange={(e) => setRejectReason(e.target.value)}
              placeholder="e.g., Vehicle mechanical fault / already committed to mass casualty"
              className="w-full px-3 py-2 rounded-lg bg-[#071A33] border border-white/15 text-xs text-white"
            />
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setShowRejectModal(false)}
                className="px-4 py-2 rounded-lg border border-white/15 text-xs text-[#94A3B8]"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={async () => {
                  await updateAssignmentStatus(assignment.id, {
                    status: 'Rejected',
                    rejectionReason: rejectReason || 'Unit unavailable',
                  });
                  setShowRejectModal(false);
                }}
                className="px-4 py-2 rounded-lg bg-[#EF4444] text-white text-xs font-semibold"
              >
                Confirm Rejection
              </button>
            </div>
          </div>
        </div>
      )}
    </PortalShell>
  );
};

export const TeamResourcesPage: React.FC = () => {
  const { resources } = useDisaster();

  return (
    <PortalShell portal="team" breadcrumb="Unit Resources">
      <div className="space-y-5">
        <div>
          <h1 className="text-xl font-display font-bold text-white">Field Unit Equipment &amp; Supplies</h1>
          <p className="text-xs text-[#94A3B8] mt-1">
            Available emergency vehicles, boats, medical kits, and rescue gear across Karachi depots.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {resources.map((res) => (
            <div key={res.id} className="bg-[#091426] border border-[#1E3A5F] rounded-xl p-5 space-y-2.5">
              <div className="flex items-center justify-between text-xs">
                <span className="font-mono text-[#38BDF8]">{res.resourceCode}</span>
                <StatusText status={res.availability} />
              </div>
              <h2 className="text-sm font-bold text-white">{res.name}</h2>
              <p className="text-xs text-[#94A3B8]">{res.category} · {res.locationName}</p>
              <p className="text-xs font-mono text-white pt-1">
                Available: {res.availableQuantity} / {res.quantity}
              </p>
            </div>
          ))}
        </div>
      </div>
    </PortalShell>
  );
};

export const TeamHistoryPage: React.FC = () => {
  const { reports } = useDisaster();

  return (
    <PortalShell portal="team" breadcrumb="Mission History">
      <div className="space-y-5">
        <div>
          <h1 className="text-xl font-display font-bold text-white">Completed Rescue Operation Reports</h1>
          <p className="text-xs text-[#94A3B8] mt-1">
            Archived field operation summaries submitted by rescue squad leaders.
          </p>
        </div>

        <div className="space-y-4">
          {reports.map((rep) => (
            <div key={rep.id} className="bg-[#091426] border border-[#1E3A5F] rounded-xl p-5 space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                <span className="font-mono text-[#38BDF8]">
                  {rep.incidentCode} · {rep.teamName}
                </span>
                <span className="font-mono text-[#94A3B8]">
                  {new Date(rep.createdAt).toLocaleString()}
                </span>
              </div>
              <p className="text-sm text-[#D9EEFF] leading-relaxed">{rep.summary}</p>
              <div className="flex flex-wrap gap-6 text-xs font-mono text-white pt-1">
                <span>People Rescued: {rep.peopleRescued}</span>
                <span>Casualties Treated: {rep.casualtiesTreated}</span>
                <span>Submitted By: {rep.submittedByName}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </PortalShell>
  );
};
