import React, { useEffect, useMemo, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import {
  AlertTriangle,
  BellRing,
  Building2,
  CheckCircle2,
  Cpu,
  GitMerge,
  Layers,
  MapPin,
  Navigation,
  PhoneCall,
  Play,
  RotateCcw,
  Search,
  SlidersHorizontal,
  Truck,
  XCircle,
} from 'lucide-react';
import { PortalShell } from '../components/layout/AppShells';
import { EmergencyMap } from '../components/map/EmergencyMap';
import {
  ConfirmDialog,
  PriorityBadgeText,
  StatusText,
} from '../components/ui/DisasterPrimitives';
import { useDisaster } from '../context/DisasterContext';
import type {
  Hospital,
  Incident,
  IncidentCategory,
  IncidentStatus,
  PriorityLevel,
  TeamRecommendation,
} from '../types/disaster';

export const AdminDashboardPage: React.FC = () => {
  const { incidents, teams, hospitals, demoMode, runDemoSimulation } = useDisaster();
  const [selectedIncident, setSelectedIncident] = useState<Incident | null>(null);
  const [simBusy, setSimBusy] = useState<string | null>(null);

  const kpis = useMemo(() => {
    const total = incidents.length;
    const active = incidents.filter(
      (i) => i.status !== 'Resolved' && i.status !== 'Closed' && i.status !== 'Rejected'
    ).length;
    const critical = incidents.filter(
      (i) => i.priority === 'CRITICAL' && i.status !== 'Resolved' && i.status !== 'Closed'
    ).length;
    const pendingVerify = incidents.filter(
      (i) => i.status === 'Submitted' || i.status === 'Under Review'
    ).length;
    const availableTeams = teams.filter((t) => t.status === 'Available').length;
    const deployedTeams = teams.filter(
      (t) => t.status === 'Assigned' || t.status === 'En Route' || t.status === 'On Site' || t.status === 'Busy'
    ).length;
    const resolved = incidents.filter(
      (i) => i.status === 'Resolved' || i.status === 'Closed'
    ).length;

    const assignedWithEta = incidents.filter((i) => typeof i.etaMinutes === 'number');
    const avgResp =
      assignedWithEta.length > 0
        ? Math.round(
            assignedWithEta.reduce((s, i) => s + (i.etaMinutes || 9), 0) /
              assignedWithEta.length
          )
        : 11;

    return {
      total,
      active,
      critical,
      pendingVerify,
      availableTeams,
      deployedTeams,
      resolved,
      avgResp,
    };
  }, [incidents, teams]);

  const priorityQueue = useMemo(() => {
    return [...incidents]
      .filter((i) => i.status !== 'Closed' && i.status !== 'Rejected')
      .sort((a, b) => b.severityScore - a.severityScore)
      .slice(0, 7);
  }, [incidents]);

  const handleSim = async (action: string) => {
    setSimBusy(action);
    try {
      await runDemoSimulation(action);
    } finally {
      setSimBusy(null);
    }
  };

  return (
    <PortalShell portal="admin" breadcrumb="Command Overview">
      <div className="space-y-6">
        {/* Hackathon Demo Bar */}
        {demoMode && (
          <div className="bg-[#091426] border border-[#FFD43B]/35 rounded-xl p-4 flex flex-col xl:flex-row xl:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 text-xs font-mono text-[#FFD43B]">
                <span>DEMO MODE ACTIVE</span>
                <span aria-hidden="true">·</span>
                <span>SIMULATED KARACHI DISPATCH SCENARIO</span>
              </div>
              <p className="text-xs text-[#94A3B8] mt-1">
                Trigger live simulated emergencies and field updates to watch AI triage, duplicate detection, and maps update across portals.
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                disabled={simBusy !== null}
                onClick={() => handleSim('new_flood')}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#12345A] hover:bg-[#168BFF] text-xs font-medium text-white transition-colors"
              >
                <Play className="w-3 h-3" />
                Simulate Flood
              </button>
              <button
                type="button"
                disabled={simBusy !== null}
                onClick={() => handleSim('critical_fire')}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#EF4444]/20 border border-[#EF4444]/40 hover:bg-[#EF4444] text-xs font-medium text-white transition-colors"
              >
                <Play className="w-3 h-3" />
                Simulate Critical Fire
              </button>
              <button
                type="button"
                disabled={simBusy !== null}
                onClick={() => handleSim('nearby_duplicate')}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#12345A] hover:bg-[#168BFF] text-xs font-medium text-white transition-colors"
              >
                <Layers className="w-3 h-3" />
                Simulate Duplicate
              </button>
              <button
                type="button"
                disabled={simBusy !== null}
                onClick={() => handleSim('team_enroute')}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#12345A] hover:bg-[#168BFF] text-xs font-medium text-white transition-colors"
              >
                <Truck className="w-3 h-3" />
                Step Team En Route
              </button>
              <button
                type="button"
                disabled={simBusy !== null}
                onClick={() => handleSim('resolve_incident')}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#22C55E]/20 border border-[#22C55E]/40 hover:bg-[#22C55E] hover:text-[#071A33] text-xs font-medium text-white transition-colors"
              >
                <CheckCircle2 className="w-3 h-3" />
                Resolve Active
              </button>
              <button
                type="button"
                disabled={simBusy !== null}
                onClick={() => handleSim('reset')}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-white/15 hover:bg-white/5 text-xs font-medium text-[#94A3B8] hover:text-white transition-colors"
              >
                <RotateCcw className="w-3 h-3" />
                Reset
              </button>
            </div>
          </div>
        )}

        {/* 8 KPI Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-[#091426] border border-[#1E3A5F] rounded-xl p-4">
            <p className="text-xs text-[#94A3B8]">Total Reported Incidents</p>
            <p className="text-2xl font-mono font-bold text-white mt-1 tabular-nums">{kpis.total}</p>
          </div>
          <div className="bg-[#091426] border border-[#1E3A5F] rounded-xl p-4">
            <p className="text-xs text-[#94A3B8]">Active Emergencies</p>
            <p className="text-2xl font-mono font-bold text-[#38BDF8] mt-1 tabular-nums">{kpis.active}</p>
          </div>
          <div className="bg-[#091426] border border-[#EF4444]/40 rounded-xl p-4">
            <p className="text-xs text-[#94A3B8]">Critical Emergencies</p>
            <p className="text-2xl font-mono font-bold text-[#EF4444] mt-1 tabular-nums">{kpis.critical}</p>
          </div>
          <div className="bg-[#091426] border border-[#1E3A5F] rounded-xl p-4">
            <p className="text-xs text-[#94A3B8]">Pending Verification</p>
            <p className="text-2xl font-mono font-bold text-[#FFD43B] mt-1 tabular-nums">{kpis.pendingVerify}</p>
          </div>
          <div className="bg-[#091426] border border-[#1E3A5F] rounded-xl p-4">
            <p className="text-xs text-[#94A3B8]">Available Rescue Teams</p>
            <p className="text-2xl font-mono font-bold text-[#22C55E] mt-1 tabular-nums">{kpis.availableTeams}</p>
          </div>
          <div className="bg-[#091426] border border-[#1E3A5F] rounded-xl p-4">
            <p className="text-xs text-[#94A3B8]">Deployed Rescue Teams</p>
            <p className="text-2xl font-mono font-bold text-[#38BDF8] mt-1 tabular-nums">{kpis.deployedTeams}</p>
          </div>
          <div className="bg-[#091426] border border-[#1E3A5F] rounded-xl p-4">
            <p className="text-xs text-[#94A3B8]">Resolved Incidents</p>
            <p className="text-2xl font-mono font-bold text-[#22C55E] mt-1 tabular-nums">{kpis.resolved}</p>
          </div>
          <div className="bg-[#091426] border border-[#1E3A5F] rounded-xl p-4">
            <p className="text-xs text-[#94A3B8]">Avg. Response Time</p>
            <p className="text-2xl font-mono font-bold text-white mt-1 tabular-nums">{kpis.avgResp} min</p>
          </div>
        </div>

        {/* Map + Priority Triage Queue */}
        <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
          <div className="xl:col-span-7">
            <EmergencyMap
              incidents={incidents}
              teams={teams}
              hospitals={hospitals}
              selectedIncidentId={selectedIncident?.id}
              onSelectIncident={setSelectedIncident}
              heightClass="h-[500px]"
            />
          </div>

          <div className="xl:col-span-5 bg-[#091426] border border-[#1E3A5F] rounded-xl p-5 flex flex-col">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h2 className="text-base font-bold text-white">AI Priority Triage Queue</h2>
                <p className="text-xs text-[#94A3B8]">Sorted by severity score (0–100)</p>
              </div>
              <Link to="/admin/incidents" className="text-xs text-[#38BDF8] hover:underline">
                Full Table
              </Link>
            </div>

            <div className="divide-y divide-white/10 flex-1 overflow-y-auto">
              {priorityQueue.map((inc) => (
                <div
                  key={inc.id}
                  onClick={() => setSelectedIncident(inc)}
                  className={`py-3 px-2 rounded-lg cursor-pointer transition-colors ${
                    selectedIncident?.id === inc.id ? 'bg-[#12345A]/60' : 'hover:bg-white/[0.03]'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2 text-xs">
                    <span className="font-mono text-[#38BDF8]">
                      {inc.incidentCode} · {inc.category}
                    </span>
                    <span className="font-mono font-bold text-white tabular-nums">
                      {inc.severityScore}/100 · <PriorityBadgeText priority={inc.priority} />
                    </span>
                  </div>
                  <p className="text-sm font-semibold text-white mt-1 line-clamp-1">{inc.title}</p>
                  <div className="flex items-center justify-between mt-1.5 text-xs">
                    <StatusText status={inc.status} />
                    <Link
                      to={`/admin/incidents/${inc.id}`}
                      onClick={(e) => e.stopPropagation()}
                      className="text-[#38BDF8] hover:underline font-medium"
                    >
                      Inspect &amp; Dispatch
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </PortalShell>
  );
};

export const AdminLiveMapPage: React.FC = () => {
  const { incidents, teams, hospitals } = useDisaster();
  const [selected, setSelected] = useState<Incident | null>(incidents[0] || null);
  const navigate = useNavigate();

  return (
    <PortalShell portal="admin" breadcrumb="Live GIS Map">
      <div className="space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h1 className="text-xl font-display font-bold text-white">Real-Time Emergency GIS Map</h1>
            <p className="text-xs text-[#94A3B8]">
              Click any incident marker to compute live OSRM rescue routing and inspect details.
            </p>
          </div>
          {selected && (
            <button
              type="button"
              onClick={() => navigate(`/admin/incidents/${selected.id}`)}
              className="px-4 py-2 rounded-lg bg-[#168BFF] hover:bg-[#38BDF8] hover:text-[#071A33] text-white text-xs font-semibold whitespace-nowrap shrink-0"
            >
              Open {selected.incidentCode} Workbench
            </button>
          )}
        </div>

        <EmergencyMap
          incidents={incidents}
          teams={teams}
          hospitals={hospitals}
          selectedIncidentId={selected?.id}
          onSelectIncident={setSelected}
          heightClass="h-[640px]"
        />
      </div>
    </PortalShell>
  );
};

export const AdminIncidentsPage: React.FC = () => {
  const { incidents } = useDisaster();
  const [search, setSearch] = useState('');
  const [severityFilter, setSeverityFilter] = useState<PriorityLevel | 'All'>('All');
  const [categoryFilter, setCategoryFilter] = useState<IncidentCategory | 'All'>('All');
  const [dateFilter, setDateFilter] = useState<'all' | '24h' | '7d'>('all');
  const [sortBy, setSortBy] = useState<'priority' | 'recent'>('priority');

  const filtered = useMemo(() => {
    const now = Date.now();
    return incidents
      .filter((inc) => {
        if (severityFilter !== 'All' && inc.priority !== severityFilter) return false;
        if (categoryFilter !== 'All' && inc.category !== categoryFilter) return false;
        if (dateFilter === '24h' && now - new Date(inc.createdAt).getTime() > 24 * 3600 * 1000) return false;
        if (dateFilter === '7d' && now - new Date(inc.createdAt).getTime() > 7 * 24 * 3600 * 1000) return false;
        if (search.trim()) {
          const q = search.toLowerCase();
          return (
            inc.incidentCode.toLowerCase().includes(q) ||
            inc.title.toLowerCase().includes(q) ||
            inc.address.toLowerCase().includes(q) ||
            inc.city.toLowerCase().includes(q)
          );
        }
        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'priority') return b.severityScore - a.severityScore;
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      });
  }, [incidents, search, severityFilter, categoryFilter, dateFilter, sortBy]);

  return (
    <PortalShell portal="admin" breadcrumb="Incidents Queue">
      <div className="space-y-5">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <h1 className="text-xl font-display font-bold text-white">Emergency Incident Management</h1>
            <p className="text-xs text-[#94A3B8] mt-1">
              Verify incoming citizen alerts, review duplicate flags, and dispatch rescue teams.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2.5">
            <div className="relative">
              <Search className="w-4 h-4 text-[#94A3B8] absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search ID, title, address..."
                className="pl-9 pr-3 py-2 rounded-lg bg-[#091426] border border-white/10 text-xs text-white w-56"
              />
            </div>

            <select
              value={severityFilter}
              onChange={(e) => setSeverityFilter(e.target.value as PriorityLevel | 'All')}
              className="px-3 py-2 rounded-lg bg-[#091426] border border-white/10 text-xs text-white"
            >
              <option value="All">All Severities</option>
              <option value="CRITICAL">Critical</option>
              <option value="HIGH">High</option>
              <option value="MEDIUM">Medium</option>
              <option value="LOW">Low</option>
            </select>

            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value as IncidentCategory | 'All')}
              className="px-3 py-2 rounded-lg bg-[#091426] border border-white/10 text-xs text-white"
            >
              <option value="All">All Categories</option>
              <option value="Flood">Flood</option>
              <option value="Fire">Fire</option>
              <option value="Building Collapse">Building Collapse</option>
              <option value="Road Accident">Road Accident</option>
              <option value="Medical Emergency">Medical Emergency</option>
              <option value="Earthquake">Earthquake</option>
              <option value="Missing Person">Missing Person</option>
              <option value="Rescue Request">Rescue Request</option>
            </select>

            <select
              value={dateFilter}
              onChange={(e) => setDateFilter(e.target.value as 'all' | '24h' | '7d')}
              className="px-3 py-2 rounded-lg bg-[#091426] border border-white/10 text-xs text-white"
            >
              <option value="all">All Dates</option>
              <option value="24h">Last 24 Hours</option>
              <option value="7d">Last 7 Days</option>
            </select>

            <button
              type="button"
              onClick={() => setSortBy((s) => (s === 'priority' ? 'recent' : 'priority'))}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-[#12345A] text-xs font-medium text-white"
            >
              <SlidersHorizontal className="w-3.5 h-3.5" />
              Sort: {sortBy === 'priority' ? 'Severity' : 'Newest'}
            </button>
          </div>
        </div>

        <div className="bg-[#091426] border border-[#1E3A5F] rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#071A33] border-b border-white/10 text-[#94A3B8]">
                <tr>
                  <th className="py-3 px-4 font-medium">Incident ID</th>
                  <th className="py-3 px-4 font-medium">Emergency Type</th>
                  <th className="py-3 px-4 font-medium">Location</th>
                  <th className="py-3 px-4 font-medium">Reported Time</th>
                  <th className="py-3 px-4 font-medium">Severity</th>
                  <th className="py-3 px-4 font-medium text-right">Affected</th>
                  <th className="py-3 px-4 font-medium text-right">AI Conf.</th>
                  <th className="py-3 px-4 font-medium">Assigned Team</th>
                  <th className="py-3 px-4 font-medium">Status</th>
                  <th className="py-3 px-4 font-medium text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {filtered.length === 0 ? (
                  <tr>
                    <td colSpan={10} className="py-8 text-center text-[#94A3B8]">
                      No incidents match the active search or filters.
                    </td>
                  </tr>
                ) : (
                  filtered.map((inc) => (
                    <tr key={inc.id} className="hover:bg-white/[0.02]">
                      <td className="py-3 px-4 font-mono text-[#38BDF8] whitespace-nowrap">
                        {inc.incidentCode}
                        {inc.duplicateMatches && inc.duplicateMatches.length > 0 && (
                          <span className="ml-1.5 text-[#FFD43B]" title="Possible Duplicate Flag">
                            (DUP)
                          </span>
                        )}
                      </td>
                      <td className="py-3 px-4 text-white whitespace-nowrap">{inc.category}</td>
                      <td className="py-3 px-4 max-w-[220px]">
                        <p className="text-white truncate">{inc.title}</p>
                        <p className="text-[#94A3B8] truncate">{inc.address}</p>
                      </td>
                      <td className="py-3 px-4 font-mono text-[#94A3B8] whitespace-nowrap">
                        {new Date(inc.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </td>
                      <td className="py-3 px-4 whitespace-nowrap font-mono">
                        <span className="text-white mr-1.5 tabular-nums">{inc.severityScore}</span>
                        <PriorityBadgeText priority={inc.priority} />
                      </td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums text-white">
                        {inc.peopleAffected}
                      </td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums text-[#D9EEFF]">
                        {Math.round((inc.aiConfidence || 0.85) * 100)}%
                      </td>
                      <td className="py-3 px-4 text-[#D9EEFF] whitespace-nowrap">
                        {inc.assignedTeamName || 'Unassigned'}
                      </td>
                      <td className="py-3 px-4 whitespace-nowrap">
                        <StatusText status={inc.status} />
                      </td>
                      <td className="py-3 px-4 text-right whitespace-nowrap">
                        <Link
                          to={`/admin/incidents/${inc.id}`}
                          className="px-2.5 py-1 rounded bg-[#12345A] hover:bg-[#168BFF] text-white font-medium transition-colors"
                        >
                          Manage
                        </Link>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </PortalShell>
  );
};

export const AdminIncidentDetailPage: React.FC = () => {
  const { incidentId } = useParams<{ incidentId: string }>();
  const {
    incidents,
    teams,
    hospitalAlerts,
    updateIncident,
    mergeDuplicateIncident,
    fetchTeamRecommendations,
    assignRescueTeam,
    fetchNearbyHospitals,
    notifyNearbyHospitals,
    updateHospitalAlertStatus,
  } = useDisaster();
  const navigate = useNavigate();

  const incident = useMemo(
    () => incidents.find((i) => i.id === incidentId),
    [incidents, incidentId]
  );

  const [recommendations, setRecommendations] = useState<TeamRecommendation[]>([]);
  const [nearbyHospitals, setNearbyHospitals] = useState<Hospital[]>([]);
  const [hospitalBusyId, setHospitalBusyId] = useState<string | null>(null);
  const [overrideScore, setOverrideScore] = useState<number>(incident?.severityScore || 50);
  const [overrideStatus, setOverrideStatus] = useState<IncidentStatus>(incident?.status || 'Under Review');
  const [operatorNotes, setOperatorNotes] = useState(incident?.operatorNotes || '');
  const [confirmDispatchTeamId, setConfirmDispatchTeamId] = useState<string | null>(null);
  const [confirmMergeId, setConfirmMergeId] = useState<string | null>(null);

  useEffect(() => {
    if (!incident) return;
    setOverrideScore(incident.severityScore);
    setOverrideStatus(incident.status);
    setOperatorNotes(incident.operatorNotes || '');
    fetchTeamRecommendations(incident.id).then(setRecommendations);
    fetchNearbyHospitals(incident.lat, incident.lng, 4).then(setNearbyHospitals);
  }, [incident, fetchTeamRecommendations, fetchNearbyHospitals]);

  const incidentHospitalAlerts = useMemo(
    () => (incident ? hospitalAlerts.filter((a) => a.incidentId === incident.id) : []),
    [hospitalAlerts, incident]
  );

  if (!incident) {
    return (
      <PortalShell portal="admin" breadcrumb="Incident Not Found">
        <div className="bg-[#091426] border border-[#1E3A5F] rounded-xl p-8 text-center space-y-3">
          <p className="text-white font-semibold">Incident not found.</p>
          <Link to="/admin/incidents" className="text-xs text-[#38BDF8] hover:underline">
            Back to Incidents Queue
          </Link>
        </div>
      </PortalShell>
    );
  }

  const teamToDispatch = teams.find((t) => t.id === confirmDispatchTeamId);

  return (
    <PortalShell portal="admin" breadcrumb={incident.incidentCode}>
      <div className="space-y-6">
        {/* Header Bar */}
        <div className="bg-[#091426] border border-[#1E3A5F] rounded-xl p-6 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="flex flex-wrap items-center gap-2 text-xs font-mono">
              <span className="text-[#38BDF8]">{incident.incidentCode}</span>
              <span aria-hidden="true">·</span>
              <span className="text-[#D9EEFF]">{incident.category}</span>
              <span aria-hidden="true">·</span>
              <PriorityBadgeText priority={incident.priority} />
              <span aria-hidden="true">·</span>
              <StatusText status={incident.status} />
              {incident.isDemo && (
                <>
                  <span aria-hidden="true">·</span>
                  <span className="text-[#FFD43B]">DEMO DATA</span>
                </>
              )}
            </div>
            <h1 className="text-2xl font-display font-bold text-white">{incident.title}</h1>
            <p className="text-xs text-[#94A3B8] flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-[#38BDF8]" />
              <span>
                {incident.address}, {incident.city} ({incident.lat}, {incident.lng})
              </span>
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5 shrink-0">
            <button
              type="button"
              onClick={() =>
                updateIncident(incident.id, {
                  status: 'Verified',
                  note: 'Incident verified by Command Center Operator.',
                })
              }
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#22C55E]/20 border border-[#22C55E]/40 hover:bg-[#22C55E] hover:text-[#071A33] text-xs font-semibold text-white transition-colors"
            >
              <CheckCircle2 className="w-4 h-4" />
              Verify Report
            </button>
            <button
              type="button"
              onClick={() =>
                updateIncident(incident.id, {
                  status: 'Rejected',
                  note: 'Marked false alarm / rejected by operator.',
                })
              }
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg border border-white/15 hover:bg-white/5 text-xs font-medium text-[#94A3B8] hover:text-white"
            >
              <XCircle className="w-4 h-4" />
              Reject
            </button>
          </div>
        </div>

        {/* Duplicate Warning Banner */}
        {incident.duplicateMatches && incident.duplicateMatches.length > 0 && !incident.duplicateOfId && (
          <div className="bg-[#091426] border border-[#FFD43B]/50 rounded-xl p-5 space-y-3">
            <div className="flex items-center gap-2 text-[#FFD43B] text-sm font-bold">
              <AlertTriangle className="w-4 h-4" />
              <span>Possible Duplicate Incident Warning</span>
            </div>
            <p className="text-xs text-[#D9EEFF]">
              Our geospatial and semantic duplicate detector identified similar active reports nearby. Original citizen reports are always preserved when merging.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {incident.duplicateMatches.map((dup) => (
                <div
                  key={dup.incidentId}
                  className="bg-[#071A33] border border-white/10 rounded-lg p-3.5 flex items-center justify-between gap-3"
                >
                  <div className="min-w-0">
                    <p className="text-xs font-mono text-[#38BDF8]">{dup.incidentCode}</p>
                    <p className="text-xs font-semibold text-white truncate">{dup.title}</p>
                    <p className="text-[11px] text-[#94A3B8] mt-0.5">{dup.reason}</p>
                  </div>
                  <button
                    type="button"
                    onClick={() => setConfirmMergeId(dup.incidentId)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#FFD43B] text-[#071A33] text-xs font-semibold shrink-0 hover:bg-[#FFF0A6]"
                  >
                    <GitMerge className="w-3.5 h-3.5" />
                    Merge Into Primary
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left: Details, Media, AI Severity + Human Override */}
          <div className="lg:col-span-6 space-y-6">
            <div className="bg-[#091426] border border-[#1E3A5F] rounded-xl p-5 space-y-4">
              <h2 className="text-sm font-bold text-white">Citizen Report Details</h2>
              <p className="text-sm text-[#D9EEFF] leading-relaxed">{incident.description}</p>
              <div className="grid grid-cols-3 gap-3 pt-2 text-xs">
                <div className="bg-[#071A33] rounded-lg p-3 border border-white/5">
                  <p className="text-[#94A3B8]">Affected</p>
                  <p className="text-lg font-mono font-bold text-white">{incident.peopleAffected}</p>
                </div>
                <div className="bg-[#071A33] rounded-lg p-3 border border-white/5">
                  <p className="text-[#94A3B8]">Injured</p>
                  <p className="text-lg font-mono font-bold text-[#FFD43B]">{incident.injuredCount}</p>
                </div>
                <div className="bg-[#071A33] rounded-lg p-3 border border-white/5">
                  <p className="text-[#94A3B8]">Trapped</p>
                  <p className={`text-lg font-mono font-bold ${incident.trapped ? 'text-[#EF4444]' : 'text-[#22C55E]'}`}>
                    {incident.trapped ? 'YES' : 'NO'}
                  </p>
                </div>
              </div>
              <div className="text-xs text-[#94A3B8] flex flex-wrap gap-4 pt-1">
                <span>Reporter: <strong className="text-white">{incident.reporterName}</strong></span>
                {incident.contactPhone && <span>Contact: <strong className="font-mono text-white">{incident.contactPhone}</strong></span>}
              </div>

              {incident.imageUrls.length > 0 && (
                <div className="space-y-2 pt-2">
                  <p className="text-xs font-medium text-[#94A3B8]">Uploaded Incident Imagery</p>
                  <div className="grid grid-cols-2 gap-3">
                    {incident.imageUrls.map((url, idx) => (
                      <img
                        key={idx}
                        src={url}
                        alt={`Incident evidence ${idx + 1}`}
                        referrerPolicy="no-referrer"
                        className="w-full h-40 object-cover rounded-lg border border-white/10"
                      />
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Explainable AI Severity Panel + Human Override */}
            <div className="bg-[#091426] border border-[#38BDF8]/35 rounded-xl p-5 space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-sm font-bold text-white flex items-center gap-2">
                  <Cpu className="w-4 h-4 text-[#38BDF8]" />
                  Explainable AI Severity Assessment
                </h2>
                <span className="font-mono text-xs text-[#94A3B8]">
                  Conf: {Math.round((incident.aiConfidence || 0.85) * 100)}% · {incident.aiModelUsed || 'gemini-4-hydrogen'}
                </span>
              </div>

              <div className="flex items-center gap-4 bg-[#071A33] border border-white/10 rounded-lg p-4">
                <div>
                  <p className="text-xs text-[#94A3B8]">Severity Score</p>
                  <p className="text-3xl font-mono font-bold text-white tabular-nums">
                    {incident.severityScore}
                    <span className="text-sm text-[#94A3B8]">/100</span>
                  </p>
                </div>
                <div className="flex-1 text-xs text-[#D9EEFF] leading-relaxed">
                  {incident.aiExplanation}
                </div>
              </div>

              {incident.aiImageAnalysis && (
                <div className="p-3 rounded-lg bg-[#071A33] border border-white/10 text-xs">
                  <p className="text-[#38BDF8] font-semibold">
                    AI Image Classification: {incident.aiImageAnalysis.predictedCategory} ({Math.round(incident.aiImageAnalysis.confidence * 100)}%)
                  </p>
                  <p className="text-[#94A3B8] mt-1">{incident.aiImageAnalysis.visualFindings}</p>
                </div>
              )}

              <div className="space-y-2">
                <p className="text-xs font-semibold text-[#94A3B8]">Risk Factor Breakdown</p>
                {incident.aiRiskFactors.map((rf, idx) => (
                  <div key={idx} className="flex items-center justify-between text-xs py-1.5 border-b border-white/5 last:border-none">
                    <div>
                      <p className="text-white font-medium">{rf.factor}</p>
                      <p className="text-[11px] text-[#94A3B8]">{rf.detail}</p>
                    </div>
                    <span className="font-mono text-[#FFD43B] font-semibold shrink-0 ml-3">+{rf.impact}</span>
                  </div>
                ))}
              </div>

              {incident.aiRecommendedActions.length > 0 && (
                <div className="space-y-1.5 pt-1">
                  <p className="text-xs font-semibold text-[#94A3B8]">Recommended Response Actions</p>
                  <ul className="space-y-1 text-xs text-[#D9EEFF] list-disc list-inside">
                    {incident.aiRecommendedActions.map((act, idx) => (
                      <li key={idx}>{act}</li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Operator Override Controls */}
              <div className="pt-4 border-t border-white/10 space-y-3">
                <p className="text-xs font-bold text-[#FFD43B]">Operator Override &amp; Notes</p>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] text-[#94A3B8] mb-1">Override Severity (0–100)</label>
                    <input
                      type="number"
                      min={0}
                      max={100}
                      value={overrideScore}
                      onChange={(e) => setOverrideScore(Math.max(0, Math.min(100, Number(e.target.value))))}
                      className="w-full px-3 py-2 rounded-lg bg-[#071A33] border border-white/15 text-xs font-mono text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-[#94A3B8] mb-1">Update Status</label>
                    <select
                      value={overrideStatus}
                      onChange={(e) => setOverrideStatus(e.target.value as IncidentStatus)}
                      className="w-full px-3 py-2 rounded-lg bg-[#071A33] border border-white/15 text-xs text-white"
                    >
                      <option value="Submitted">Submitted</option>
                      <option value="Under Review">Under Review</option>
                      <option value="Verified">Verified</option>
                      <option value="Team Assigned">Team Assigned</option>
                      <option value="Team En Route">Team En Route</option>
                      <option value="Rescue in Progress">Rescue in Progress</option>
                      <option value="Resolved">Resolved</option>
                      <option value="Closed">Closed</option>
                    </select>
                  </div>
                </div>
                <textarea
                  rows={2}
                  value={operatorNotes}
                  onChange={(e) => setOperatorNotes(e.target.value)}
                  placeholder="Add command operator notes..."
                  className="w-full px-3 py-2 rounded-lg bg-[#071A33] border border-white/15 text-xs text-white"
                />
                <button
                  type="button"
                  onClick={() =>
                    updateIncident(incident.id, {
                      status: overrideStatus,
                      severityScore: overrideScore,
                      operatorNotes,
                      note: `Operator update: ${overrideStatus} (Severity ${overrideScore}/100).`,
                    })
                  }
                  className="px-4 py-2 rounded-lg bg-[#168BFF] hover:bg-[#38BDF8] hover:text-[#071A33] text-white text-xs font-semibold transition-colors"
                >
                  Save Operator Assessment
                </button>
              </div>
            </div>
          </div>

          {/* Right: Intelligent Team Assignment, Hospital First-Aid Alerts & Route Map */}
          <div className="lg:col-span-6 space-y-6">
            <EmergencyMap
              incidents={[incident]}
              teams={teams}
              hospitals={nearbyHospitals}
              selectedIncidentId={incident.id}
              heightClass="h-[320px]"
              showControls={false}
              center={[incident.lat, incident.lng]}
              zoom={12}
            />

            {/* Nearby Hospital First-Aid & Trauma Standby */}
            <div className="bg-[#091426] border border-[#22C55E]/35 rounded-xl p-5 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <h2 className="text-sm font-bold text-white flex items-center gap-2">
                    <Building2 className="w-4 h-4 text-[#22C55E]" />
                    Nearby Hospital First-Aid Coordination
                  </h2>
                  <p className="text-xs text-[#94A3B8] mt-0.5">
                    Notify closest hospitals to send mobile first aid and ready ER trauma bays.
                  </p>
                </div>
                <button
                  type="button"
                  disabled={hospitalBusyId !== null}
                  onClick={async () => {
                    setHospitalBusyId('batch');
                    try {
                      await notifyNearbyHospitals(incident.id);
                    } finally {
                      setHospitalBusyId(null);
                    }
                  }}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#22C55E]/20 border border-[#22C55E]/40 hover:bg-[#22C55E] hover:text-[#071A33] text-xs font-semibold text-white transition-colors whitespace-nowrap shrink-0"
                >
                  <BellRing className="w-3.5 h-3.5" />
                  {hospitalBusyId === 'batch' ? 'Notifying...' : 'Notify Closest Hospitals'}
                </button>
              </div>

              {incidentHospitalAlerts.length > 0 && (
                <div className="space-y-2.5">
                  <p className="text-[11px] font-mono text-[#22C55E]">ACTIVE HOSPITAL ALERTS</p>
                  {incidentHospitalAlerts.map((ha) => (
                    <div
                      key={ha.id}
                      className="p-3.5 rounded-lg bg-[#071A33] border border-white/10 space-y-2"
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <p className="text-xs font-semibold text-white">{ha.hospitalName}</p>
                          <p className="text-[11px] text-[#94A3B8] font-mono tabular-nums">
                            {ha.distanceKm} km · First Aid ETA ~{ha.firstAidEtaMinutes} min · {ha.hospitalPhone}
                          </p>
                        </div>
                        <StatusText status={ha.status} />
                      </div>
                      <div className="flex flex-wrap items-center gap-2 pt-1">
                        {ha.status !== 'First Aid Dispatched' && (
                          <button
                            type="button"
                            onClick={() => updateHospitalAlertStatus(ha.id, 'First Aid Dispatched')}
                            className="px-2.5 py-1 rounded bg-[#22C55E]/20 border border-[#22C55E]/40 hover:bg-[#22C55E] hover:text-[#071A33] text-[11px] font-medium text-white transition-colors"
                          >
                            Mark First Aid Dispatched
                          </button>
                        )}
                        {ha.status !== 'ER Trauma Standby' && (
                          <button
                            type="button"
                            onClick={() => updateHospitalAlertStatus(ha.id, 'ER Trauma Standby')}
                            className="px-2.5 py-1 rounded bg-[#168BFF]/20 border border-[#168BFF]/40 hover:bg-[#168BFF] text-[11px] font-medium text-white transition-colors"
                          >
                            Mark ER Trauma Standby
                          </button>
                        )}
                        <a
                          href={`tel:${ha.hospitalPhone.replace(/[^+\d]/g, '')}`}
                          className="inline-flex items-center gap-1 px-2.5 py-1 rounded border border-white/10 hover:border-[#38BDF8] text-[11px] font-mono text-[#38BDF8] ml-auto"
                        >
                          <PhoneCall className="w-3 h-3" />
                          Call Hospital
                        </a>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              <div className="space-y-2">
                <p className="text-[11px] font-mono text-[#94A3B8]">NEAREST HOSPITALS BY COORDINATES</p>
                {nearbyHospitals
                  .filter((h) => !incidentHospitalAlerts.some((a) => a.hospitalId === h.id))
                  .map((hosp) => (
                    <div
                      key={hosp.id}
                      className="p-3 rounded-lg bg-[#071A33] border border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs"
                    >
                      <div className="min-w-0">
                        <p className="font-semibold text-white truncate">{hosp.name}</p>
                        <p className="text-[11px] text-[#94A3B8] font-mono tabular-nums">
                          {hosp.distanceKm} km · First Aid ~{hosp.etaMinutes} min · {hosp.traumaLevel}
                        </p>
                      </div>
                      <button
                        type="button"
                        disabled={hospitalBusyId !== null}
                        onClick={async () => {
                          setHospitalBusyId(hosp.id);
                          try {
                            await notifyNearbyHospitals(incident.id, [hosp.id]);
                          } finally {
                            setHospitalBusyId(null);
                          }
                        }}
                        className="px-3 py-1.5 rounded-lg bg-[#12345A] hover:bg-[#168BFF] text-white text-[11px] font-semibold whitespace-nowrap shrink-0 transition-colors"
                      >
                        {hospitalBusyId === hosp.id ? 'Sending...' : 'Notify for First Aid'}
                      </button>
                    </div>
                  ))}
              </div>
            </div>

            <div className="bg-[#091426] border border-[#1E3A5F] rounded-xl p-5 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-sm font-bold text-white flex items-center gap-2">
                    <Navigation className="w-4 h-4 text-[#38BDF8]" />
                    Intelligent Rescue Team Recommendations
                  </h2>
                  <p className="text-xs text-[#94A3B8] mt-0.5">
                    Ranked by specialization match, road distance, ETA, and unit availability. Confirmation required.
                  </p>
                </div>
              </div>

              <div className="space-y-3">
                {recommendations.map((rec, idx) => (
                  <div
                    key={rec.team.id}
                    className={`p-4 rounded-xl border ${
                      idx === 0
                        ? 'bg-[#12345A]/45 border-[#38BDF8]/50'
                        : 'bg-[#071A33] border-white/10'
                    } flex flex-col sm:flex-row sm:items-center justify-between gap-3`}
                  >
                    <div className="space-y-1 min-w-0">
                      <div className="flex items-center gap-2 text-xs">
                        <span className="font-mono text-[#38BDF8]">#{idx + 1}</span>
                        <span className="font-semibold text-white truncate">{rec.team.name}</span>
                        {idx === 0 && (
                          <span className="text-[11px] font-mono text-[#22C55E]">RECOMMENDED</span>
                        )}
                      </div>
                      <p className="text-xs text-[#94A3B8]">{rec.rationale}</p>
                      <p className="text-[11px] font-mono text-[#D9EEFF]">
                        Suitability: {rec.suitabilityScore}/100 · {rec.team.vehicleInfo}
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => setConfirmDispatchTeamId(rec.team.id)}
                      className="px-3.5 py-2 rounded-lg bg-[#168BFF] hover:bg-[#38BDF8] hover:text-[#071A33] text-white text-xs font-semibold whitespace-nowrap shrink-0 transition-colors"
                    >
                      Assign Team
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      <ConfirmDialog
        open={Boolean(confirmDispatchTeamId)}
        title="Confirm Rescue Team Dispatch"
        description={
          teamToDispatch
            ? `Dispatch ${teamToDispatch.name} (${teamToDispatch.teamType}) to ${incident.incidentCode} at ${incident.address}? This will notify the team leader in real time.`
            : ''
        }
        confirmLabel="Confirm Dispatch"
        onCancel={() => setConfirmDispatchTeamId(null)}
        onConfirm={async () => {
          if (confirmDispatchTeamId) {
            await assignRescueTeam(incident.id, confirmDispatchTeamId);
            setConfirmDispatchTeamId(null);
          }
        }}
      />

      <ConfirmDialog
        open={Boolean(confirmMergeId)}
        title="Confirm Duplicate Incident Merge"
        description="Merging consolidates casualties and media into the primary report while preserving the original citizen submission in the audit log."
        confirmLabel="Merge Reports"
        onCancel={() => setConfirmMergeId(null)}
        onConfirm={async () => {
          if (confirmMergeId) {
            await mergeDuplicateIncident(confirmMergeId, incident.id);
            setConfirmMergeId(null);
            navigate(`/admin/incidents/${confirmMergeId}`);
          }
        }}
      />
    </PortalShell>
  );
};
