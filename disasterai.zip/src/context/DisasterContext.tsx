import React, { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react';
import { onAuthStateChanged, type User } from 'firebase/auth';
import {
  auth,
  ensureUserProfile,
  persistHospitalAlertToFirestore,
  persistIncidentToFirestore,
  signInWithGooglePopup,
  signOutFirebase,
  testFirestoreConnection,
} from '../lib/firebase';
import type {
  AIAnalysisResult,
  AppNotification,
  AssignmentStatus,
  AuditLog,
  DuplicateMatch,
  Hospital,
  HospitalAlert,
  HospitalAlertStatus,
  Incident,
  IncidentCategory,
  IncidentStatus,
  PriorityLevel,
  RescueOperationReport,
  RescueTeam,
  Resource,
  ResourceCategory,
  SystemStatePayload,
  TeamAssignment,
  TeamRecommendation,
  UserRole,
} from '../types/disaster';

export interface ToastMessage {
  id: string;
  title: string;
  description?: string;
  tone: 'info' | 'success' | 'warning' | 'critical';
}

export interface SessionUser {
  uid: string;
  displayName: string;
  email?: string;
  role: UserRole;
  city: string;
  teamId?: string;
  isDemoSession: boolean;
}

interface DisasterContextValue {
  loading: boolean;
  wsConnected: boolean;
  incidents: Incident[];
  teams: RescueTeam[];
  assignments: TeamAssignment[];
  resources: Resource[];
  notifications: AppNotification[];
  reports: RescueOperationReport[];
  auditLogs: AuditLog[];
  hospitals: Hospital[];
  hospitalAlerts: HospitalAlert[];
  smsConfigured: boolean;
  demoMode: boolean;
  sessionUser: SessionUser | null;
  firebaseUser: User | null;
  toasts: ToastMessage[];
  pushToast: (toast: Omit<ToastMessage, 'id'>) => void;
  dismissToast: (id: string) => void;
  signInWithGoogle: (preferredRole?: UserRole) => Promise<void>;
  signInDemoRole: (role: UserRole, name?: string, teamId?: string) => void;
  logout: () => Promise<void>;
  refreshState: () => Promise<void>;
  analyzeDraftIncident: (payload: {
    category?: string;
    title: string;
    description: string;
    city: string;
    address: string;
    peopleAffected: number;
    injuredCount: number;
    trapped: boolean;
    hazards: string[];
    imageUrls?: string[];
  }) => Promise<AIAnalysisResult>;
  checkDraftDuplicates: (payload: {
    category?: string;
    title: string;
    description: string;
    lat: number;
    lng: number;
  }) => Promise<DuplicateMatch[]>;
  submitIncident: (payload: {
    category: IncidentCategory;
    title: string;
    description: string;
    city: string;
    address: string;
    lat: number;
    lng: number;
    peopleAffected: number;
    injuredCount: number;
    trapped: boolean;
    hazards: string[];
    imageUrls: string[];
    videoUrl?: string;
    contactPhone?: string;
  }) => Promise<Incident>;
  updateIncident: (
    id: string,
    updates: {
      status?: IncidentStatus;
      severityScore?: number;
      priority?: PriorityLevel;
      operatorNotes?: string;
      isPublicAlert?: boolean;
      note?: string;
    }
  ) => Promise<Incident>;
  mergeDuplicateIncident: (primaryId: string, duplicateId: string) => Promise<void>;
  fetchTeamRecommendations: (incidentId: string) => Promise<TeamRecommendation[]>;
  assignRescueTeam: (incidentId: string, teamId: string) => Promise<void>;
  updateAssignmentStatus: (
    assignmentId: string,
    updates: {
      status?: AssignmentStatus;
      rejectionReason?: string;
      progressNotes?: string;
      requestedResources?: string[];
      peopleRescued?: number;
      casualtiesTreated?: number;
      summary?: string;
      photoUrls?: string[];
    }
  ) => Promise<void>;
  updateTeamLocation: (teamId: string, lat: number, lng: number, status?: RescueTeam['status']) => Promise<void>;
  updateResource: (
    resourceId: string,
    updates: {
      deltaAvailable?: number;
      availableQuantity?: number;
      assignedIncidentId?: string;
      responsibleTeamId?: string;
    }
  ) => Promise<void>;
  createResource: (payload: {
    name: string;
    category: ResourceCategory;
    quantity: number;
    locationName: string;
  }) => Promise<void>;
  markNotificationRead: (id: string) => Promise<void>;
  markAllNotificationsRead: () => Promise<void>;
  fetchNearbyHospitals: (lat: number, lng: number, limit?: number) => Promise<Hospital[]>;
  notifyNearbyHospitals: (
    incidentId: string,
    hospitalIds?: string[],
    notes?: string
  ) => Promise<HospitalAlert[]>;
  updateHospitalAlertStatus: (
    alertId: string,
    status: HospitalAlertStatus
  ) => Promise<HospitalAlert>;
  toggleDemoMode: (enabled: boolean) => Promise<void>;
  runDemoSimulation: (action: string) => Promise<string>;
}

const DisasterContext = createContext<DisasterContextValue | null>(null);

const DEMO_STORAGE_KEY = 'disasterai_demo_session';

export const DisasterProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [loading, setLoading] = useState(true);
  const [wsConnected, setWsConnected] = useState(false);
  const [incidents, setIncidents] = useState<Incident[]>([]);
  const [teams, setTeams] = useState<RescueTeam[]>([]);
  const [assignments, setAssignments] = useState<TeamAssignment[]>([]);
  const [resources, setResources] = useState<Resource[]>([]);
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [reports, setReports] = useState<RescueOperationReport[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [hospitals, setHospitals] = useState<Hospital[]>([]);
  const [hospitalAlerts, setHospitalAlerts] = useState<HospitalAlert[]>([]);
  const [smsConfigured, setSmsConfigured] = useState(false);
  const [demoMode, setDemoMode] = useState(true);
  const [firebaseUser, setFirebaseUser] = useState<User | null>(null);
  const [sessionUser, setSessionUser] = useState<SessionUser | null>(() => {
    try {
      const raw = sessionStorage.getItem(DEMO_STORAGE_KEY);
      return raw ? JSON.parse(raw) : null;
    } catch {
      return null;
    }
  });
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const wsRef = useRef<WebSocket | null>(null);

  const pushToast = useCallback((toast: Omit<ToastMessage, 'id'>) => {
    const id = `toast_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
    setToasts((prev) => [...prev.slice(-3), { ...toast, id }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 5000);
  }, []);

  const dismissToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const applyFullState = useCallback((data: SystemStatePayload) => {
    setIncidents(data.incidents || []);
    setTeams(data.teams || []);
    setAssignments(data.assignments || []);
    setResources(data.resources || []);
    setNotifications(data.notifications || []);
    setReports(data.reports || []);
    setAuditLogs(data.auditLogs || []);
    setHospitals(data.hospitals || []);
    setHospitalAlerts(data.hospitalAlerts || []);
    setSmsConfigured(Boolean(data.smsConfigured));
    setDemoMode(Boolean(data.demoMode));
  }, []);

  const refreshState = useCallback(async () => {
    try {
      const res = await fetch('/api/state');
      if (res.ok) {
        const data: SystemStatePayload = await res.json();
        applyFullState(data);
      }
    } catch (err) {
      console.error('Failed to load state:', err);
    } finally {
      setLoading(false);
    }
  }, [applyFullState]);

  // Boot Firestore connection check & Auth listener
  useEffect(() => {
    testFirestoreConnection();
    const unsub = onAuthStateChanged(auth, async (user) => {
      setFirebaseUser(user);
      if (user) {
        try {
          const profile = await ensureUserProfile(user);
          setSessionUser({
            uid: user.uid,
            displayName: profile.displayName,
            email: user.email || undefined,
            role: profile.role,
            city: profile.city,
            isDemoSession: false,
          });
        } catch {
          setSessionUser({
            uid: user.uid,
            displayName: user.displayName || 'Citizen User',
            email: user.email || undefined,
            role: 'Citizen',
            city: 'Karachi',
            isDemoSession: false,
          });
        }
      }
    });
    return () => unsub();
  }, []);

  // Initial fetch + WebSocket real-time sync
  useEffect(() => {
    refreshState();
    let reconnectTimer: ReturnType<typeof setTimeout> | null = null;
    let closed = false;

    const connectWs = () => {
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const ws = new WebSocket(`${protocol}//${window.location.host}/ws`);
      wsRef.current = ws;

      ws.onopen = () => setWsConnected(true);
      ws.onclose = () => {
        setWsConnected(false);
        if (!closed) {
          reconnectTimer = setTimeout(connectWs, 3000);
        }
      };
      ws.onerror = () => {
        setWsConnected(false);
      };
      ws.onmessage = (evt) => {
        try {
          const msg = JSON.parse(evt.data);
          const { event, payload } = msg;
          if (event === 'state:sync') {
            applyFullState(payload);
          } else if (event === 'incident:created') {
            setIncidents((prev) =>
              prev.some((i) => i.id === payload.id) ? prev : [payload, ...prev]
            );
          } else if (event === 'incident:updated') {
            setIncidents((prev) =>
              prev.map((i) => (i.id === payload.id ? payload : i))
            );
          } else if (event === 'assignment:created') {
            setAssignments((prev) =>
              prev.some((a) => a.id === payload.id) ? prev : [payload, ...prev]
            );
          } else if (event === 'assignment:updated') {
            setAssignments((prev) =>
              prev.map((a) => (a.id === payload.id ? payload : a))
            );
          } else if (event === 'team:updated') {
            setTeams((prev) =>
              prev.map((t) => (t.id === payload.id ? payload : t))
            );
          } else if (event === 'resource:updated') {
            setResources((prev) => {
              const exists = prev.some((r) => r.id === payload.id);
              return exists
                ? prev.map((r) => (r.id === payload.id ? payload : r))
                : [payload, ...prev];
            });
          } else if (event === 'notification:created') {
            setNotifications((prev) =>
              prev.some((n) => n.id === payload.id) ? prev : [payload, ...prev]
            );
            if (
              payload.type === 'critical_alert' ||
              payload.type === 'team_assignment' ||
              payload.type === 'hospital_alert'
            ) {
              pushToast({
                title: payload.title,
                description: payload.message,
                tone:
                  payload.type === 'critical_alert'
                    ? 'critical'
                    : payload.type === 'hospital_alert'
                    ? 'info'
                    : 'warning',
              });
            }
          } else if (event === 'notification:updated') {
            setNotifications((prev) =>
              prev.map((n) => (n.id === payload.id ? payload : n))
            );
          } else if (event === 'report:created') {
            setReports((prev) =>
              prev.some((r) => r.id === payload.id) ? prev : [payload, ...prev]
            );
          } else if (event === 'hospital:alert') {
            setHospitalAlerts((prev) =>
              prev.some((a) => a.id === payload.id) ? prev : [payload, ...prev]
            );
          } else if (event === 'hospital:updated') {
            setHospitalAlerts((prev) =>
              prev.map((a) => (a.id === payload.id ? payload : a))
            );
          }
        } catch {
          // Ignore malformed frame
        }
      };
    };

    connectWs();
    return () => {
      closed = true;
      if (reconnectTimer) clearTimeout(reconnectTimer);
      wsRef.current?.close();
    };
  }, [applyFullState, pushToast, refreshState]);

  const signInWithGoogle = useCallback(
    async (preferredRole?: UserRole) => {
      const cred = await signInWithGooglePopup();
      const profile = await ensureUserProfile(cred.user, preferredRole);
      sessionStorage.removeItem(DEMO_STORAGE_KEY);
      setSessionUser({
        uid: cred.user.uid,
        displayName: profile.displayName,
        email: cred.user.email || undefined,
        role: profile.role,
        city: profile.city,
        isDemoSession: false,
      });
      pushToast({
        title: `Signed in as ${profile.displayName}`,
        description: `Active role: ${profile.role}`,
        tone: 'success',
      });
    },
    [pushToast]
  );

  const signInDemoRole = useCallback(
    (role: UserRole, name?: string, teamId?: string) => {
      const defaultNames: Record<UserRole, string> = {
        Citizen: 'Ayesha Siddiqui (DEMO)',
        'Emergency Operator': 'Commander Tariq (DEMO)',
        'Rescue Team Leader': 'Bilal Baloch (DEMO)',
        Administrator: 'PDMA Director (DEMO)',
      };
      const demoUser: SessionUser = {
        uid: `demo_${role.toLowerCase().replace(/\s+/g, '_')}`,
        displayName: name || defaultNames[role],
        role,
        city: 'Karachi',
        teamId: teamId || (role === 'Rescue Team Leader' ? 'team_gulshan_usar' : undefined),
        isDemoSession: true,
      };
      sessionStorage.setItem(DEMO_STORAGE_KEY, JSON.stringify(demoUser));
      setSessionUser(demoUser);
      pushToast({
        title: `Demo Portal: ${role}`,
        description: 'Operating in hackathon demo session.',
        tone: 'info',
      });
    },
    [pushToast]
  );

  const logout = useCallback(async () => {
    sessionStorage.removeItem(DEMO_STORAGE_KEY);
    setSessionUser(null);
    if (auth.currentUser) {
      await signOutFirebase();
    }
    pushToast({ title: 'Signed out', tone: 'info' });
  }, [pushToast]);

  const analyzeDraftIncident = useCallback(async (payload: any) => {
    const res = await fetch('/api/ai/analyze', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    if (!res.ok) throw new Error('AI analysis request failed');
    return res.json();
  }, []);

  const checkDraftDuplicates = useCallback(async (payload: any) => {
    const res = await fetch('/api/ai/check-duplicates', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    if (!res.ok) return [];
    const data = await res.json();
    return data.matches || [];
  }, []);

  const submitIncident = useCallback(
    async (payload: any): Promise<Incident> => {
      const res = await fetch('/api/incidents', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...payload,
          reporterUid: sessionUser?.uid || 'citizen_guest',
          reporterName: sessionUser?.displayName || 'Citizen Reporter',
          isDemo: sessionUser?.isDemoSession ?? demoMode,
        }),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || 'Failed to submit incident');
      }
      const created: Incident = await res.json();
      if (auth.currentUser?.emailVerified) {
        persistIncidentToFirestore(created).catch((e) =>
          console.warn('Firestore backup sync notice:', e)
        );
      }
      pushToast({
        title: `Incident ${created.incidentCode} Submitted`,
        description: `AI Priority: ${created.priority} (${created.severityScore}/100)`,
        tone: created.priority === 'CRITICAL' ? 'critical' : 'success',
      });
      return created;
    },
    [demoMode, pushToast, sessionUser]
  );

  const updateIncident = useCallback(
    async (id: string, updates: any): Promise<Incident> => {
      const res = await fetch(`/api/incidents/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...updates,
          actorUid: sessionUser?.uid || 'operator',
          actorName: sessionUser?.displayName || 'Command Operator',
        }),
      });
      if (!res.ok) throw new Error('Failed to update incident');
      const updated = await res.json();
      pushToast({ title: `Updated ${updated.incidentCode}`, tone: 'success' });
      return updated;
    },
    [pushToast, sessionUser]
  );

  const mergeDuplicateIncident = useCallback(
    async (primaryId: string, duplicateId: string) => {
      const res = await fetch(`/api/incidents/${primaryId}/merge`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          duplicateId,
          actorUid: sessionUser?.uid || 'operator',
          actorName: sessionUser?.displayName || 'Command Operator',
        }),
      });
      if (!res.ok) throw new Error('Failed to merge duplicate reports');
      pushToast({
        title: 'Duplicate Reports Merged',
        description: 'Original citizen reports preserved in audit trail.',
        tone: 'success',
      });
    },
    [pushToast, sessionUser]
  );

  const fetchTeamRecommendations = useCallback(async (incidentId: string) => {
    const res = await fetch(`/api/incidents/${incidentId}/recommendations`);
    if (!res.ok) return [];
    const data = await res.json();
    return data.recommendations || [];
  }, []);

  const assignRescueTeam = useCallback(
    async (incidentId: string, teamId: string) => {
      const res = await fetch(`/api/incidents/${incidentId}/assign`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          teamId,
          actorUid: sessionUser?.uid || 'operator',
          actorName: sessionUser?.displayName || 'Command Operator',
        }),
      });
      if (!res.ok) throw new Error('Failed to dispatch rescue team');
      const data = await res.json();
      pushToast({
        title: `Dispatched ${data.team.name}`,
        description: `Assigned to ${data.incident.incidentCode} · ETA ${data.assignment.etaMinutes} min`,
        tone: 'success',
      });
    },
    [pushToast, sessionUser]
  );

  const updateAssignmentStatus = useCallback(
    async (assignmentId: string, updates: any) => {
      const res = await fetch(`/api/assignments/${assignmentId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...updates,
          actorUid: sessionUser?.uid || 'team_leader',
          actorName: sessionUser?.displayName || 'Rescue Team Leader',
        }),
      });
      if (!res.ok) throw new Error('Failed to update assignment');
      const data = await res.json();
      pushToast({
        title: `Assignment ${data.status}`,
        description: `${data.incidentCode} updated in Command Center.`,
        tone: 'success',
      });
    },
    [pushToast, sessionUser]
  );

  const updateTeamLocation = useCallback(
    async (teamId: string, lat: number, lng: number, status?: RescueTeam['status']) => {
      await fetch(`/api/teams/${teamId}/location`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ lat, lng, status }),
      });
    },
    []
  );

  const updateResource = useCallback(
    async (resourceId: string, updates: any) => {
      const res = await fetch(`/api/resources/${resourceId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...updates,
          actorUid: sessionUser?.uid || 'operator',
          actorName: sessionUser?.displayName || 'Command Operator',
        }),
      });
      if (!res.ok) throw new Error('Failed to update resource');
      pushToast({ title: 'Resource inventory updated', tone: 'success' });
    },
    [pushToast, sessionUser]
  );

  const createResource = useCallback(
    async (payload: { name: string; category: ResourceCategory; quantity: number; locationName: string }) => {
      const res = await fetch('/api/resources', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...payload, isDemo: demoMode }),
      });
      if (!res.ok) throw new Error('Failed to add resource');
      pushToast({ title: `Added ${payload.name}`, tone: 'success' });
    },
    [demoMode, pushToast]
  );

  const markNotificationRead = useCallback(async (id: string) => {
    await fetch(`/api/notifications/${id}/read`, { method: 'PATCH' });
  }, []);

  const markAllNotificationsRead = useCallback(async () => {
    await fetch('/api/notifications/read-all', { method: 'POST' });
  }, []);

  const fetchNearbyHospitals = useCallback(async (lat: number, lng: number, limit = 4): Promise<Hospital[]> => {
    const res = await fetch(`/api/hospitals/nearby?lat=${lat}&lng=${lng}&limit=${limit}`);
    if (!res.ok) return [];
    const data = await res.json();
    return data.hospitals || [];
  }, []);

  const notifyNearbyHospitals = useCallback(
    async (incidentId: string, hospitalIds?: string[], notes?: string): Promise<HospitalAlert[]> => {
      const res = await fetch(`/api/incidents/${incidentId}/notify-hospitals`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          hospitalIds,
          notes,
          actorUid: sessionUser?.uid || 'citizen_operator',
          actorName: sessionUser?.displayName || 'Citizen / Command Operator',
        }),
      });
      if (!res.ok) throw new Error('Failed to notify nearby hospitals');
      const data = await res.json();
      const alerts: HospitalAlert[] = data.alerts || [];
      if (auth.currentUser?.emailVerified) {
        alerts.forEach((alert) => {
          persistHospitalAlertToFirestore(alert).catch((e) =>
            console.warn('Firestore hospital alert backup notice:', e)
          );
        });
      }
      if (alerts.length > 0) {
        pushToast({
          title: `Notified ${alerts.length} Nearby Hospital${alerts.length > 1 ? 's' : ''}`,
          description: `${alerts[0].hospitalName} alerted for first aid (~${alerts[0].firstAidEtaMinutes} min ETA).`,
          tone: 'success',
        });
      } else {
        pushToast({
          title: 'Hospital already notified',
          description: 'Selected hospital has already received an alert for this incident.',
          tone: 'info',
        });
      }
      return alerts;
    },
    [pushToast, sessionUser]
  );

  const updateHospitalAlertStatus = useCallback(
    async (alertId: string, status: HospitalAlertStatus): Promise<HospitalAlert> => {
      const res = await fetch(`/api/hospital-alerts/${alertId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          status,
          actorUid: sessionUser?.uid || 'operator',
          actorName: sessionUser?.displayName || 'Command Operator',
        }),
      });
      if (!res.ok) throw new Error('Failed to update hospital alert status');
      const updated: HospitalAlert = await res.json();
      pushToast({
        title: `${updated.hospitalName}`,
        description: `Status updated to ${updated.status}.`,
        tone: 'success',
      });
      return updated;
    },
    [pushToast, sessionUser]
  );

  const toggleDemoMode = useCallback(async (enabled: boolean) => {
    const res = await fetch('/api/demo/mode', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ demoMode: enabled }),
    });
    if (res.ok) {
      setDemoMode(enabled);
      pushToast({
        title: enabled ? 'Demo Mode Enabled' : 'Demo Mode Disabled',
        tone: 'info',
      });
    }
  }, [pushToast]);

  const runDemoSimulation = useCallback(
    async (action: string): Promise<string> => {
      const res = await fetch('/api/demo/simulate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action }),
      });
      const data = await res.json();
      if (!res.ok) {
        pushToast({ title: data.error || 'Simulation step unavailable', tone: 'warning' });
        throw new Error(data.error || 'Simulation failed');
      }
      pushToast({ title: data.message, tone: 'info' });
      return data.message;
    },
    [pushToast]
  );

  return (
    <DisasterContext.Provider
      value={{
        loading,
        wsConnected,
        incidents,
        teams,
        assignments,
        resources,
        notifications,
        reports,
        auditLogs,
        hospitals,
        hospitalAlerts,
        smsConfigured,
        demoMode,
        sessionUser,
        firebaseUser,
        toasts,
        pushToast,
        dismissToast,
        signInWithGoogle,
        signInDemoRole,
        logout,
        refreshState,
        analyzeDraftIncident,
        checkDraftDuplicates,
        submitIncident,
        updateIncident,
        mergeDuplicateIncident,
        fetchTeamRecommendations,
        assignRescueTeam,
        updateAssignmentStatus,
        updateTeamLocation,
        updateResource,
        createResource,
        markNotificationRead,
        markAllNotificationsRead,
        fetchNearbyHospitals,
        notifyNearbyHospitals,
        updateHospitalAlertStatus,
        toggleDemoMode,
        runDemoSimulation,
      }}
    >
      {children}
    </DisasterContext.Provider>
  );
};

export function useDisaster() {
  const ctx = useContext(DisasterContext);
  if (!ctx) throw new Error('useDisaster must be used inside DisasterProvider');
  return ctx;
}
