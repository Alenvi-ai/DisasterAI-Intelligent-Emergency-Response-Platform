import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import { ErrorBoundary } from './components/ErrorBoundary';
import { ToastContainer } from './components/ui/DisasterPrimitives';
import { DisasterProvider } from './context/DisasterContext';
import {
  AboutPage,
  LandingPage,
  LoginPage,
  PublicSafetyPage,
} from './pages/PublicPages';
import {
  CitizenDashboardPage,
  CitizenMyReportsPage,
  CitizenSafetyCenterPage,
  ReportEmergencyPage,
  TrackEmergencyPage,
} from './pages/CitizenPages';
import {
  AdminDashboardPage,
  AdminIncidentDetailPage,
  AdminIncidentsPage,
  AdminLiveMapPage,
} from './pages/AdminPages';
import {
  AdminAnalyticsPage,
  AdminAssignmentsPage,
  AdminNotificationsPage,
  AdminRescueTeamsPage,
  AdminResourcesPage,
  AdminSettingsPage,
} from './pages/AdminOpsPages';
import {
  TeamAssignmentDetailPage,
  TeamAssignmentsPage,
  TeamDashboardPage,
  TeamHistoryPage,
  TeamResourcesPage,
} from './pages/TeamPages';

export default function App() {
  return (
    <ErrorBoundary>
      <DisasterProvider>
        <BrowserRouter>
          <Routes>
            {/* Public Routes */}
            <Route path="/" element={<LandingPage />} />
            <Route path="/login" element={<LoginPage mode="login" />} />
            <Route path="/register" element={<LoginPage mode="register" />} />
            <Route path="/about" element={<AboutPage />} />
            <Route path="/safety" element={<PublicSafetyPage />} />

            {/* Citizen Portal Routes */}
            <Route path="/citizen/dashboard" element={<CitizenDashboardPage />} />
            <Route path="/citizen/report-emergency" element={<ReportEmergencyPage />} />
            <Route path="/citizen/my-reports" element={<CitizenMyReportsPage />} />
            <Route path="/citizen/track/:incidentId" element={<TrackEmergencyPage />} />
            <Route path="/citizen/safety-center" element={<CitizenSafetyCenterPage />} />

            {/* Admin / Emergency Command Center Routes */}
            <Route path="/admin/dashboard" element={<AdminDashboardPage />} />
            <Route path="/admin/live-map" element={<AdminLiveMapPage />} />
            <Route path="/admin/incidents" element={<AdminIncidentsPage />} />
            <Route path="/admin/incidents/:incidentId" element={<AdminIncidentDetailPage />} />
            <Route path="/admin/rescue-teams" element={<AdminRescueTeamsPage />} />
            <Route path="/admin/assignments" element={<AdminAssignmentsPage />} />
            <Route path="/admin/resources" element={<AdminResourcesPage />} />
            <Route path="/admin/analytics" element={<AdminAnalyticsPage />} />
            <Route path="/admin/notifications" element={<AdminNotificationsPage />} />
            <Route path="/admin/settings" element={<AdminSettingsPage />} />

            {/* Rescue Team Portal Routes */}
            <Route path="/team/dashboard" element={<TeamDashboardPage />} />
            <Route path="/team/assignments" element={<TeamAssignmentsPage />} />
            <Route path="/team/assignments/:assignmentId" element={<TeamAssignmentDetailPage />} />
            <Route path="/team/resources" element={<TeamResourcesPage />} />
            <Route path="/team/history" element={<TeamHistoryPage />} />

            {/* Fallback */}
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
          <ToastContainer />
        </BrowserRouter>
      </DisasterProvider>
    </ErrorBoundary>
  );
}
