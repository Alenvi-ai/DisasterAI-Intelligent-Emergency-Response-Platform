import React from 'react';
import { AlertTriangle, RotateCcw } from 'lucide-react';

interface State {
  hasError: boolean;
  message: string;
}

export class ErrorBoundary extends React.Component<
  { children: React.ReactNode },
  State
> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false, message: '' };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, message: error.message || 'Unexpected application error' };
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-[#071A33] text-[#F8FAFC] flex items-center justify-center p-6">
          <div className="max-w-lg w-full bg-[#091426] border border-[#1E3A5F] rounded-xl p-6 space-y-4">
            <div className="flex items-center gap-3 text-[#EF4444]">
              <AlertTriangle className="w-6 h-6 shrink-0" />
              <h2 className="text-lg font-semibold">Application Recovery Notice</h2>
            </div>
            <p className="text-sm text-[#94A3B8] leading-relaxed">
              DisasterAI encountered a runtime error while synchronizing state. Your session data on the server remains intact.
            </p>
            <pre className="text-xs font-mono bg-[#071A33] border border-white/10 rounded-lg p-3 overflow-auto max-h-40 text-[#D9EEFF]">
              {this.state.message}
            </pre>
            <button
              onClick={() => window.location.reload()}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-[#168BFF] hover:bg-[#38BDF8] hover:text-[#071A33] text-white text-sm font-medium transition-colors"
            >
              <RotateCcw className="w-4 h-4" />
              Reload Command Interface
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}
