import React, { useState } from 'react';
import {
  AlertTriangle,
  Ambulance,
  CheckCircle2,
  Flame,
  Info,
  PhoneCall,
  ShieldAlert,
  X,
} from 'lucide-react';
import type { IncidentStatus, PriorityLevel } from '../../types/disaster';
import { useDisaster } from '../../context/DisasterContext';

export interface EmergencyHelpline {
  id: 'rescue1122' | 'edhi' | 'chhipa' | 'fire';
  name: string;
  shortLabel: string;
  number: string;
  telHref: string;
  category: 'Rescue' | 'Ambulance' | 'Fire';
  description: string;
  accent: 'red' | 'amber' | 'cyan';
}

export const EMERGENCY_HELPLINES: EmergencyHelpline[] = [
  {
    id: 'edhi',
    name: 'Edhi Ambulance Service',
    shortLabel: 'Edhi Ambulance',
    number: '115',
    telHref: 'tel:115',
    category: 'Ambulance',
    description: '24/7 emergency ambulance & patient transport across Pakistan',
    accent: 'cyan',
  },
  {
    id: 'chhipa',
    name: 'Chhipa Ambulance Service',
    shortLabel: 'Chhipa Ambulance',
    number: '1020',
    telHref: 'tel:1020',
    category: 'Ambulance',
    description: 'Rapid trauma, road accident & emergency ambulance response',
    accent: 'cyan',
  },
  {
    id: 'fire',
    name: 'Fire Brigade',
    shortLabel: 'Fire Brigade',
    number: '101',
    telHref: 'tel:101',
    category: 'Fire',
    description: 'Direct firefighting, chemical blaze & smoke rescue dispatch',
    accent: 'amber',
  },
  {
    id: 'rescue1122',
    name: 'Rescue 1122',
    shortLabel: 'Rescue 1122',
    number: '1122',
    telHref: 'tel:1122',
    category: 'Rescue',
    description: 'Provincial integrated rescue, USAR & medical emergency service',
    accent: 'red',
  },
];

export function PriorityBadgeText({ priority }: { priority: PriorityLevel }) {
  const styles: Record<PriorityLevel, string> = {
    CRITICAL: 'text-[#EF4444]',
    HIGH: 'text-orange-400',
    MEDIUM: 'text-[#FFD43B]',
    LOW: 'text-[#38BDF8]',
  };
  return (
    <span className={`font-mono text-xs font-semibold tracking-wide ${styles[priority]}`}>
      {priority}
    </span>
  );
}

export function StatusText({ status }: { status: IncidentStatus | string }) {
  const colorMap: Record<string, string> = {
    Submitted: 'text-[#D9EEFF]',
    'Under Review': 'text-[#FFD43B]',
    Verified: 'text-[#38BDF8]',
    'Team Assigned': 'text-[#38BDF8]',
    'Team En Route': 'text-[#FFD43B]',
    'Rescue in Progress': 'text-orange-400',
    Resolved: 'text-[#22C55E]',
    Closed: 'text-[#94A3B8]',
    Rejected: 'text-[#94A3B8]',
    Available: 'text-[#22C55E]',
    Assigned: 'text-[#38BDF8]',
    'En Route': 'text-[#FFD43B]',
    'On Site': 'text-orange-400',
    'In Progress': 'text-orange-400',
    Completed: 'text-[#22C55E]',
    'Low Stock': 'text-[#FFD43B]',
    Deployed: 'text-[#38BDF8]',
    Unavailable: 'text-[#EF4444]',
    Notified: 'text-[#FFD43B]',
    'First Aid Dispatched': 'text-[#22C55E]',
    'ER Trauma Standby': 'text-[#38BDF8]',
  };
  return (
    <span className={`text-xs font-medium ${colorMap[status] || 'text-[#F8FAFC]'}`}>
      {status}
    </span>
  );
}

export const EmergencyQuickDialStrip: React.FC<{
  compact?: boolean;
  highlightFire?: boolean;
  highlightAmbulance?: boolean;
}> = ({ compact = false, highlightFire = false, highlightAmbulance = false }) => {
  const [lastDialed, setLastDialed] = useState<EmergencyHelpline | null>(null);

  return (
    <div className="bg-[#091426] border border-[#1E3A5F] rounded-xl p-4 space-y-3">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div>
          <h2 className="text-sm font-bold text-white">Direct Emergency Service Calling</h2>
          <p className="text-xs text-[#94A3B8]">
            Tap any service to open your device dialer and call immediately.
          </p>
        </div>
        {lastDialed && (
          <p className="text-[11px] font-mono text-[#FFD43B]">
            Dialer requested for {lastDialed.shortLabel} ({lastDialed.number}) · Dial manually if on desktop
          </p>
        )}
      </div>

      <div className={`grid grid-cols-1 sm:grid-cols-2 ${compact ? 'lg:grid-cols-4' : 'xl:grid-cols-4'} gap-3`}>
        {EMERGENCY_HELPLINES.map((service) => {
          const isFire = service.id === 'fire';
          const isAmb = service.id === 'edhi' || service.id === 'chhipa';
          const emphasized =
            (highlightFire && isFire) || (highlightAmbulance && isAmb);

          const Icon = isFire ? Flame : isAmb ? Ambulance : PhoneCall;
          const borderStyle = emphasized
            ? 'border-[#EF4444] bg-[#EF4444]/15'
            : service.accent === 'red'
            ? 'border-[#EF4444]/40 bg-[#071A33] hover:border-[#EF4444]'
            : service.accent === 'amber'
            ? 'border-[#FFD43B]/35 bg-[#071A33] hover:border-[#FFD43B]'
            : 'border-[#38BDF8]/30 bg-[#071A33] hover:border-[#38BDF8]';

          const numColor =
            service.accent === 'red' || emphasized
              ? 'text-[#EF4444]'
              : service.accent === 'amber'
              ? 'text-[#FFD43B]'
              : 'text-[#38BDF8]';

          return (
            <a
              key={service.id}
              href={service.telHref}
              onClick={() => setLastDialed(service)}
              className={`rounded-lg border p-3.5 flex items-center justify-between gap-3 transition-colors ${borderStyle}`}
            >
              <div className="min-w-0">
                <div className="flex items-center gap-1.5">
                  <Icon className={`w-4 h-4 shrink-0 ${numColor}`} />
                  <span className="text-xs font-semibold text-white truncate">
                    {service.shortLabel}
                  </span>
                </div>
                {!compact && (
                  <p className="text-[11px] text-[#94A3B8] mt-1 line-clamp-1">
                    {service.description}
                  </p>
                )}
              </div>
              <div className="shrink-0 text-right">
                <span className={`font-mono text-base font-bold tabular-nums ${numColor}`}>
                  {service.number}
                </span>
                <p className="text-[10px] text-[#D9EEFF] whitespace-nowrap">Call Now</p>
              </div>
            </a>
          );
        })}
      </div>
    </div>
  );
};

export const Call1122Modal: React.FC<{
  open: boolean;
  onClose: () => void;
}> = ({ open, onClose }) => {
  const [dialedService, setDialedService] = useState<EmergencyHelpline | null>(null);

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-[1200] bg-black/70 backdrop-blur-sm flex items-center justify-center p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="call-1122-title"
    >
      <div className="max-w-lg w-full bg-[#091426] border border-[#EF4444]/40 rounded-xl p-6 space-y-5 shadow-2xl">
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-[#EF4444]/15 border border-[#EF4444]/30 flex items-center justify-center text-[#EF4444]">
              <PhoneCall className="w-5 h-5" />
            </div>
            <div>
              <h3 id="call-1122-title" className="text-lg font-bold text-[#F8FAFC]">
                Direct Emergency Helplines
              </h3>
              <p className="text-xs text-[#94A3B8]">
                Ambulance (Edhi 115 · Chhipa 1020) · Fire Brigade 101 · Rescue 1122
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-[#94A3B8] hover:text-white hover:bg-white/5"
            aria-label="Close emergency call dialog"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="bg-[#071A33] border border-[#FFD43B]/30 rounded-lg p-3.5 space-y-1.5">
          <div className="flex items-center gap-2 text-[#FFD43B] text-xs font-semibold">
            <AlertTriangle className="w-4 h-4 shrink-0" />
            <span>Official Emergency Service Notice</span>
          </div>
          <p className="text-xs text-[#D9EEFF] leading-relaxed">
            Clicking any service opens your device&apos;s native dialer directly. If your desktop browser does not support telephone links, dial the number shown manually on your mobile phone.
          </p>
        </div>

        <div className="space-y-2.5">
          {EMERGENCY_HELPLINES.map((service) => {
            const Icon =
              service.id === 'fire'
                ? Flame
                : service.id === 'edhi' || service.id === 'chhipa'
                ? Ambulance
                : PhoneCall;

            return (
              <div
                key={service.id}
                className="bg-[#071A33] border border-white/10 rounded-lg p-3.5 flex items-center justify-between gap-3"
              >
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <Icon
                      className={`w-4 h-4 shrink-0 ${
                        service.id === 'fire'
                          ? 'text-[#FFD43B]'
                          : service.id === 'rescue1122'
                          ? 'text-[#EF4444]'
                          : 'text-[#38BDF8]'
                      }`}
                    />
                    <span className="text-sm font-semibold text-white truncate">
                      {service.name}
                    </span>
                  </div>
                  <p className="text-[11px] text-[#94A3B8] mt-0.5 truncate">
                    {service.description}
                  </p>
                </div>

                <a
                  href={service.telHref}
                  onClick={() => setDialedService(service)}
                  className={`inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-semibold whitespace-nowrap shrink-0 transition-colors ${
                    service.id === 'rescue1122'
                      ? 'bg-[#EF4444] hover:bg-red-600 text-white'
                      : service.id === 'fire'
                      ? 'bg-[#FFD43B] hover:bg-[#FFF0A6] text-[#071A33]'
                      : 'bg-[#168BFF] hover:bg-[#38BDF8] hover:text-[#071A33] text-white'
                  }`}
                >
                  <PhoneCall className="w-3.5 h-3.5" />
                  <span className="font-mono tabular-nums">Call {service.number}</span>
                </a>
              </div>
            );
          })}
        </div>

        {dialedService && (
          <p className="text-xs text-[#94A3B8]">
            Telephone handoff requested via{' '}
            <span className="font-mono text-white">{dialedService.telHref}</span> for{' '}
            {dialedService.name}. Confirm the call on your device screen, or dial{' '}
            <span className="font-mono text-white">{dialedService.number}</span> manually.
          </p>
        )}

        <div className="flex items-center justify-end pt-1">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-lg text-sm font-medium text-[#94A3B8] hover:text-white border border-white/10 hover:bg-white/5 transition-colors whitespace-nowrap"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

export const ConfirmDialog: React.FC<{
  open: boolean;
  title: string;
  description: string;
  confirmLabel: string;
  danger?: boolean;
  onConfirm: () => void;
  onCancel: () => void;
}> = ({ open, title, description, confirmLabel, danger, onConfirm, onCancel }) => {
  if (!open) return null;
  return (
    <div
      className="fixed inset-0 z-[1200] bg-black/70 backdrop-blur-sm flex items-center justify-center p-4"
      role="dialog"
      aria-modal="true"
    >
      <div className="max-w-md w-full bg-[#091426] border border-[#1E3A5F] rounded-xl p-6 space-y-4 shadow-2xl">
        <div className="flex items-center gap-3">
          <ShieldAlert className={`w-5 h-5 shrink-0 ${danger ? 'text-[#EF4444]' : 'text-[#FFD43B]'}`} />
          <h3 className="text-base font-bold text-[#F8FAFC]">{title}</h3>
        </div>
        <p className="text-sm text-[#94A3B8] leading-relaxed">{description}</p>
        <div className="flex items-center justify-end gap-3 pt-2">
          <button
            onClick={onCancel}
            className="px-4 py-2 rounded-lg text-sm font-medium text-[#94A3B8] hover:text-white border border-white/10 hover:bg-white/5 transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={onConfirm}
            className={`px-4 py-2 rounded-lg text-sm font-semibold transition-colors ${
              danger
                ? 'bg-[#EF4444] hover:bg-red-600 text-white'
                : 'bg-[#168BFF] hover:bg-[#38BDF8] hover:text-[#071A33] text-white'
            }`}
          >
            {confirmLabel}
          </button>
        </div>
      </div>
    </div>
  );
};

export const ToastContainer: React.FC = () => {
  const { toasts, dismissToast } = useDisaster();
  if (toasts.length === 0) return null;

  return (
    <div className="fixed bottom-4 right-4 z-[1300] flex flex-col gap-2 max-w-sm w-full pointer-events-none px-4 sm:px-0">
      {toasts.map((t) => {
        const borderClass =
          t.tone === 'critical'
            ? 'border-[#EF4444]/60'
            : t.tone === 'warning'
            ? 'border-[#FFD43B]/50'
            : t.tone === 'success'
            ? 'border-[#22C55E]/50'
            : 'border-[#38BDF8]/40';
        const Icon =
          t.tone === 'critical' || t.tone === 'warning'
            ? AlertTriangle
            : t.tone === 'success'
            ? CheckCircle2
            : Info;
        const iconColor =
          t.tone === 'critical'
            ? 'text-[#EF4444]'
            : t.tone === 'warning'
            ? 'text-[#FFD43B]'
            : t.tone === 'success'
            ? 'text-[#22C55E]'
            : 'text-[#38BDF8]';

        return (
          <div
            key={t.id}
            className={`pointer-events-auto bg-[#091426]/95 backdrop-blur-md border ${borderClass} rounded-xl p-3.5 shadow-xl flex items-start gap-3`}
          >
            <Icon className={`w-4 h-4 mt-0.5 shrink-0 ${iconColor}`} />
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-[#F8FAFC] truncate">{t.title}</p>
              {t.description && (
                <p className="text-xs text-[#94A3B8] mt-0.5 line-clamp-2">{t.description}</p>
              )}
            </div>
            <button
              onClick={() => dismissToast(t.id)}
              className="text-[#94A3B8] hover:text-white p-0.5"
              aria-label="Dismiss notification"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        );
      })}
    </div>
  );
};

export const SAFETY_PROTOCOLS = [
  {
    id: 'flood',
    title: 'Urban & Monsoon Floods',
    summary: 'Critical actions during Karachi stormwater surges and flash flooding.',
    steps: [
      'Move immediately to upper floors or elevated dry ground; never wait for water to breach doorways.',
      'Shut off the main electrical breaker and gas valve if floodwater approaches outlets.',
      'Never walk, swim, or drive through moving floodwater or near fallen overhead cables.',
      'Keep emergency drinking water, medicines, CNIC documents, and charged power banks in a waterproof pouch.',
    ],
  },
  {
    id: 'fire',
    title: 'Structural & Industrial Fires',
    summary: 'Smoke survival, electrical fire containment, and safe evacuation.',
    steps: [
      'Activate building fire alarm and call 1122 from outside the hazard perimeter.',
      'Stay low beneath toxic smoke layers and cover nose/mouth with a damp cloth.',
      'Test closed doors with the back of your hand before opening; never use elevators.',
      'Never pour water on electrical transformer or oil/chemical fires; use CO2 or dry powder extinguishers.',
    ],
  },
  {
    id: 'earthquake',
    title: 'Earthquakes & Structural Tremors',
    summary: 'Drop, Cover, and Hold On during seismic shocks and aftershocks.',
    steps: [
      'Drop onto hands and knees, cover your head/neck under sturdy furniture away from glass and exterior walls.',
      'Wait until shaking stops completely before evacuating via stairways.',
      'Do not re-enter buildings showing diagonal concrete cracks or tilted columns.',
      'Expect aftershocks and keep emergency access roads clear for USAR vehicles.',
    ],
  },
  {
    id: 'road',
    title: 'Road & Highway Accidents',
    summary: 'Scene safety and trauma stabilization on high-speed corridors.',
    steps: [
      'Park safely off the carriageway with hazard lights on and place warning triangles 30m upstream.',
      'Do not move casualties with suspected neck or spinal trauma unless threatened by fire or traffic.',
      'Check for fuel leaks and keep flames or cigarettes away from the collision site.',
      'Share exact flyover/milestone coordinates via DisasterAI GPS reporting.',
    ],
  },
  {
    id: 'medical',
    title: 'Medical & Heatstroke Emergencies',
    summary: 'Immediate response for cardiac distress, bleeding, and heat exhaustion.',
    steps: [
      'For suspected cardiac arrest, check responsiveness and begin chest compressions if trained while calling 1122.',
      'Apply firm direct pressure with clean sterile cloth to control heavy bleeding.',
      'For heatstroke, move the person to shade, cool with wet cloths around neck/armpits, and avoid forcing fluids if drowsy.',
      'Keep patient airway clear and prepare medical history/medications for ALS paramedics.',
    ],
  },
];
