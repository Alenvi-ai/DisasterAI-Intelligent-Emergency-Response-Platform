import React, { useEffect, useMemo, useRef, useState } from 'react';
import L from 'leaflet';
import { Layers, LocateFixed, Navigation, Search, ZoomIn, ZoomOut } from 'lucide-react';
import type {
  Hospital,
  Incident,
  IncidentCategory,
  PriorityLevel,
  RescueTeam,
} from '../../types/disaster';

interface EmergencyMapProps {
  incidents: Incident[];
  teams?: RescueTeam[];
  hospitals?: Hospital[];
  selectedIncidentId?: string | null;
  onSelectIncident?: (incident: Incident) => void;
  pickLocationMode?: boolean;
  pickedCoords?: { lat: number; lng: number } | null;
  onPickCoords?: (lat: number, lng: number) => void;
  heightClass?: string;
  showControls?: boolean;
  center?: [number, number];
  zoom?: number;
}

const CITY_PRESETS: Array<{ label: string; lat: number; lng: number; zoom: number }> = [
  { label: 'Karachi Hub', lat: 24.8607, lng: 67.0311, zoom: 12 },
  { label: 'Korangi', lat: 24.835, lng: 67.12, zoom: 13 },
  { label: 'Lyari / Saddar', lat: 24.865, lng: 67.01, zoom: 13 },
  { label: 'Gulshan / Nazimabad', lat: 24.916, lng: 67.06, zoom: 13 },
  { label: 'Clifton / DHA', lat: 24.805, lng: 67.04, zoom: 13 },
  { label: 'Lahore', lat: 31.5497, lng: 74.3436, zoom: 12 },
  { label: 'Islamabad', lat: 33.6844, lng: 73.0479, zoom: 12 },
];

function getIncidentMarkerColor(inc: Incident): string {
  if (inc.status === 'Resolved' || inc.status === 'Closed') return '#22C55E';
  switch (inc.priority) {
    case 'CRITICAL':
      return '#EF4444';
    case 'HIGH':
      return '#FB923C';
    case 'MEDIUM':
      return '#FFD43B';
    default:
      return '#168BFF';
  }
}

export const EmergencyMap: React.FC<EmergencyMapProps> = ({
  incidents,
  teams = [],
  hospitals = [],
  selectedIncidentId,
  onSelectIncident,
  pickLocationMode = false,
  pickedCoords = null,
  onPickCoords,
  heightClass = 'h-[540px]',
  showControls = true,
  center = [24.865, 67.045],
  zoom = 12,
}) => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const mapRef = useRef<L.Map | null>(null);
  const markerLayerRef = useRef<L.LayerGroup | null>(null);
  const routeLayerRef = useRef<L.LayerGroup | null>(null);
  const pickMarkerRef = useRef<L.CircleMarker | null>(null);

  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<IncidentCategory | 'All'>('All');
  const [severityFilter, setSeverityFilter] = useState<PriorityLevel | 'All'>('All');
  const [clusterEnabled, setClusterEnabled] = useState(true);
  const [darkMapStyle, setDarkMapStyle] = useState(true);
  const [activeRouteInfo, setActiveRouteInfo] = useState<{
    teamName: string;
    incidentCode: string;
    distanceKm: number;
    durationMinutes: number;
    source: string;
  } | null>(null);

  const filteredIncidents = useMemo(() => {
    return incidents.filter((inc) => {
      if (categoryFilter !== 'All' && inc.category !== categoryFilter) return false;
      if (severityFilter !== 'All' && inc.priority !== severityFilter) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const hit =
          inc.incidentCode.toLowerCase().includes(q) ||
          inc.title.toLowerCase().includes(q) ||
          inc.address.toLowerCase().includes(q) ||
          inc.city.toLowerCase().includes(q);
        if (!hit) return false;
      }
      return true;
    });
  }, [incidents, categoryFilter, severityFilter, searchQuery]);

  // Initialize Leaflet map
  useEffect(() => {
    if (!containerRef.current || mapRef.current) return;

    const map = L.map(containerRef.current, {
      center,
      zoom,
      zoomControl: false,
    });

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; OpenStreetMap contributors',
      maxZoom: 19,
    }).addTo(map);

    markerLayerRef.current = L.layerGroup().addTo(map);
    routeLayerRef.current = L.layerGroup().addTo(map);
    mapRef.current = map;

    return () => {
      map.remove();
      mapRef.current = null;
      markerLayerRef.current = null;
      routeLayerRef.current = null;
      pickMarkerRef.current = null;
    };
  }, []);

  // Apply tile filter class for dark command center feel
  useEffect(() => {
    const pane = containerRef.current?.querySelector('.leaflet-tile-pane') as HTMLElement | null;
    if (pane) {
      pane.style.filter = darkMapStyle
        ? 'invert(100%) hue-rotate(195deg) brightness(88%) contrast(94%) saturate(65%)'
        : 'none';
    }
  }, [darkMapStyle]);

  // Handle manual coordinate picking
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;

    const handleClick = (e: L.LeafletMouseEvent) => {
      if (pickLocationMode && onPickCoords) {
        onPickCoords(Number(e.latlng.lat.toFixed(6)), Number(e.latlng.lng.toFixed(6)));
      }
    };

    map.on('click', handleClick);
    return () => {
      map.off('click', handleClick);
    };
  }, [pickLocationMode, onPickCoords]);

  useEffect(() => {
    const map = mapRef.current;
    if (!map || !pickLocationMode) return;

    if (pickedCoords) {
      if (!pickMarkerRef.current) {
        pickMarkerRef.current = L.circleMarker([pickedCoords.lat, pickedCoords.lng], {
          radius: 9,
          color: '#FFFFFF',
          weight: 2,
          fillColor: '#168BFF',
          fillOpacity: 0.95,
        }).addTo(map);
      } else {
        pickMarkerRef.current.setLatLng([pickedCoords.lat, pickedCoords.lng]);
      }
      map.setView([pickedCoords.lat, pickedCoords.lng], Math.max(map.getZoom(), 13));
    }
  }, [pickLocationMode, pickedCoords]);

  // Draw OSRM route when an incident is selected
  useEffect(() => {
    const routeLayer = routeLayerRef.current;
    if (!routeLayer) return;
    routeLayer.clearLayers();
    setActiveRouteInfo(null);

    if (!selectedIncidentId) return;
    const incident = incidents.find((i) => i.id === selectedIncidentId);
    if (!incident) return;

    const assignedTeam = incident.assignedTeamId
      ? teams.find((t) => t.id === incident.assignedTeamId)
      : teams.find((t) => t.status === 'Available') || teams[0];

    if (!assignedTeam) return;

    let cancelled = false;
    fetch(
      `/api/route?fromLat=${assignedTeam.lat}&fromLng=${assignedTeam.lng}&toLat=${incident.lat}&toLng=${incident.lng}`
    )
      .then((r) => (r.ok ? r.json() : null))
      .then((route) => {
        if (cancelled || !route?.coordinates?.length || !routeLayerRef.current) return;
        L.polyline(route.coordinates, {
          color: '#38BDF8',
          weight: 4,
          opacity: 0.85,
          dashArray: route.source === 'estimated' ? '6 8' : undefined,
        }).addTo(routeLayerRef.current);

        setActiveRouteInfo({
          teamName: assignedTeam.name,
          incidentCode: incident.incidentCode,
          distanceKm: route.distanceKm,
          durationMinutes: route.durationMinutes,
          source: route.source,
        });
      })
      .catch(() => {});

    return () => {
      cancelled = true;
    };
  }, [selectedIncidentId, incidents, teams]);

  // Render incident markers (with proximity clustering) + rescue team markers
  useEffect(() => {
    const map = mapRef.current;
    const layer = markerLayerRef.current;
    if (!map || !layer) return;

    const renderMarkers = () => {
      layer.clearLayers();
      const currentZoom = map.getZoom();
      const shouldCluster = clusterEnabled && currentZoom <= 12 && !pickLocationMode;

      if (shouldCluster) {
        const visited = new Set<string>();
        const clusters: Incident[][] = [];

        for (const inc of filteredIncidents) {
          if (visited.has(inc.id)) continue;
          visited.add(inc.id);
          const group = [inc];
          for (const other of filteredIncidents) {
            if (visited.has(other.id)) continue;
            const dLat = Math.abs(inc.lat - other.lat);
            const dLng = Math.abs(inc.lng - other.lng);
            if (dLat < 0.015 && dLng < 0.015) {
              visited.add(other.id);
              group.push(other);
            }
          }
          clusters.push(group);
        }

        for (const group of clusters) {
          if (group.length > 1) {
            const avgLat = group.reduce((s, i) => s + i.lat, 0) / group.length;
            const avgLng = group.reduce((s, i) => s + i.lng, 0) / group.length;
            const hasCritical = group.some(
              (i) => i.priority === 'CRITICAL' && i.status !== 'Resolved' && i.status !== 'Closed'
            );
            const clusterColor = hasCritical ? '#EF4444' : '#168BFF';
            const icon = L.divIcon({
              className: '',
              html: `<div style="width:34px;height:34px;border-radius:9999px;background:${clusterColor};border:2px solid #F8FAFC;color:#fff;font-family:'JetBrains Mono',monospace;font-size:12px;font-weight:700;display:flex;align-items:center;justify-content:center;box-shadow:0 4px 14px rgba(0,0,0,0.45);">${group.length}</div>`,
              iconSize: [34, 34],
              iconAnchor: [17, 17],
            });
            const marker = L.marker([avgLat, avgLng], { icon }).addTo(layer);
            marker.bindPopup(
              `<div style="min-width:190px;font-size:12px;">
                <div style="font-weight:700;margin-bottom:4px;">${group.length} Clustered Incidents</div>
                <div style="color:#94A3B8;margin-bottom:6px;">Click zoom or click cluster to inspect individual reports.</div>
                ${group
                  .slice(0, 4)
                  .map(
                    (g) =>
                      `<div style="margin-bottom:3px;"><strong>${g.incidentCode}</strong> · ${g.category} (${g.priority})</div>`
                  )
                  .join('')}
              </div>`
            );
            marker.on('click', () => {
              map.setView([avgLat, avgLng], 14);
            });
            continue;
          }

          const inc = group[0];
          addSingleIncidentMarker(inc, layer);
        }
      } else {
        for (const inc of filteredIncidents) {
          addSingleIncidentMarker(inc, layer);
        }
      }

      // Render rescue team markers
      for (const team of teams) {
        const teamColor =
          team.status === 'Available'
            ? '#22C55E'
            : team.status === 'En Route'
            ? '#FFD43B'
            : '#38BDF8';
        const teamIcon = L.divIcon({
          className: '',
          html: `<div style="width:26px;height:26px;border-radius:6px;background:#091426;border:2px solid ${teamColor};color:${teamColor};font-family:'JetBrains Mono',monospace;font-size:10px;font-weight:700;display:flex;align-items:center;justify-content:center;box-shadow:0 3px 10px rgba(0,0,0,0.5);">RT</div>`,
          iconSize: [26, 26],
          iconAnchor: [13, 13],
        });
        const tMarker = L.marker([team.lat, team.lng], { icon: teamIcon }).addTo(layer);
        tMarker.bindPopup(
          `<div style="min-width:200px;font-size:12px;">
            <div style="font-weight:700;color:#38BDF8;">${team.name}</div>
            <div style="color:#94A3B8;margin-top:2px;">${team.teamType} · ${team.status}</div>
            <div style="margin-top:6px;">Vehicle: ${team.vehicleInfo}</div>
            <div>Leader: ${team.leaderName}</div>
          </div>`
        );
      }

      // Render nearby hospital markers
      for (const hosp of hospitals) {
        const hospIcon = L.divIcon({
          className: '',
          html: `<div style="width:24px;height:24px;border-radius:6px;background:#071A33;border:2px solid #22C55E;color:#22C55E;font-family:'JetBrains Mono',monospace;font-size:11px;font-weight:700;display:flex;align-items:center;justify-content:center;box-shadow:0 3px 10px rgba(0,0,0,0.5);">H+</div>`,
          iconSize: [24, 24],
          iconAnchor: [12, 12],
        });
        const hMarker = L.marker([hosp.lat, hosp.lng], { icon: hospIcon }).addTo(layer);
        hMarker.bindPopup(
          `<div style="min-width:210px;font-size:12px;">
            <div style="font-weight:700;color:#22C55E;">${hosp.name}</div>
            <div style="color:#94A3B8;margin-top:2px;">${hosp.traumaLevel} · First Aid Ready</div>
            <div style="margin-top:5px;">${hosp.address}</div>
            <div style="margin-top:4px;font-family:'JetBrains Mono',monospace;color:#38BDF8;">${hosp.emergencyPhone}</div>
          </div>`
        );
      }
    };

    const addSingleIncidentMarker = (inc: Incident, targetLayer: L.LayerGroup) => {
      const color = getIncidentMarkerColor(inc);
      const isSelected = selectedIncidentId === inc.id;
      const marker = L.circleMarker([inc.lat, inc.lng], {
        radius: isSelected ? 11 : inc.priority === 'CRITICAL' ? 9 : 7,
        color: isSelected ? '#FFFFFF' : '#071A33',
        weight: isSelected ? 3 : 2,
        fillColor: color,
        fillOpacity: 0.92,
      }).addTo(targetLayer);

      marker.bindPopup(
        `<div style="min-width:220px;font-size:12px;line-height:1.45;">
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px;">
            <strong style="font-family:'JetBrains Mono',monospace;color:#38BDF8;">${inc.incidentCode}</strong>
            <span style="font-weight:700;color:${color};">${inc.priority}</span>
          </div>
          <div style="font-weight:600;color:#F8FAFC;margin-bottom:4px;">${inc.title}</div>
          <div style="color:#94A3B8;">Type: ${inc.category} · Affected: ${inc.peopleAffected}</div>
          <div style="color:#94A3B8;">Status: ${inc.status}</div>
          <div style="color:#94A3B8;">Team: ${inc.assignedTeamName || 'Unassigned'}</div>
        </div>`
      );

      marker.on('click', () => {
        if (onSelectIncident) onSelectIncident(inc);
      });
    };

    renderMarkers();
    map.on('zoomend', renderMarkers);
    return () => {
      map.off('zoomend', renderMarkers);
    };
  }, [filteredIncidents, teams, hospitals, selectedIncidentId, clusterEnabled, pickLocationMode, onSelectIncident]);

  return (
    <div className="bg-[#091426] border border-[#1E3A5F] rounded-xl overflow-hidden flex flex-col">
      {showControls && (
        <div className="p-3 border-b border-white/10 flex flex-wrap items-center gap-2.5 bg-[#071A33]/70">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="w-4 h-4 text-[#94A3B8] absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search incident ID, neighborhood, or city..."
              className="w-full pl-9 pr-3 py-1.5 rounded-lg bg-[#091426] border border-white/10 text-xs text-[#F8FAFC] placeholder:text-[#94A3B8] focus:outline-none focus:border-[#38BDF8]"
            />
          </div>

          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value as IncidentCategory | 'All')}
            className="px-2.5 py-1.5 rounded-lg bg-[#091426] border border-white/10 text-xs text-[#F8FAFC] focus:outline-none focus:border-[#38BDF8]"
            aria-label="Filter map by emergency category"
          >
            <option value="All">All Categories</option>
            <option value="Flood">Flood</option>
            <option value="Fire">Fire</option>
            <option value="Building Collapse">Building Collapse</option>
            <option value="Road Accident">Road Accident</option>
            <option value="Medical Emergency">Medical Emergency</option>
            <option value="Earthquake">Earthquake</option>
            <option value="Missing Person">Missing Person</option>
            <option value="Rescue Request">Rescue Request</option>
          </select>

          <select
            value={severityFilter}
            onChange={(e) => setSeverityFilter(e.target.value as PriorityLevel | 'All')}
            className="px-2.5 py-1.5 rounded-lg bg-[#091426] border border-white/10 text-xs text-[#F8FAFC] focus:outline-none focus:border-[#38BDF8]"
            aria-label="Filter map by severity"
          >
            <option value="All">All Severities</option>
            <option value="CRITICAL">Critical</option>
            <option value="HIGH">High</option>
            <option value="MEDIUM">Medium</option>
            <option value="LOW">Low</option>
          </select>

          <div className="flex items-center gap-1">
            {CITY_PRESETS.slice(0, 4).map((preset) => (
              <button
                key={preset.label}
                type="button"
                onClick={() => mapRef.current?.setView([preset.lat, preset.lng], preset.zoom)}
                className="px-2.5 py-1.5 rounded-lg text-xs text-[#D9EEFF] bg-[#12345A]/60 hover:bg-[#168BFF] hover:text-white transition-colors whitespace-nowrap"
              >
                {preset.label}
              </button>
            ))}
          </div>

          <button
            type="button"
            onClick={() => setClusterEnabled((v) => !v)}
            className={`inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium border transition-colors whitespace-nowrap ${
              clusterEnabled
                ? 'bg-[#168BFF]/20 border-[#168BFF]/50 text-[#38BDF8]'
                : 'bg-[#091426] border-white/10 text-[#94A3B8]'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            Clustering
          </button>

          <button
            type="button"
            onClick={() => setDarkMapStyle((v) => !v)}
            className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium bg-[#091426] border border-white/10 text-[#94A3B8] hover:text-white transition-colors whitespace-nowrap"
          >
            <LocateFixed className="w-3.5 h-3.5" />
            {darkMapStyle ? 'Standard Map' : 'Night Map'}
          </button>
        </div>
      )}

      <div className={`relative w-full ${heightClass}`}>
        <div ref={containerRef} className="w-full h-full z-0" />

        {/* Custom Zoom Controls */}
        <div className="absolute top-3 right-3 z-[400] flex flex-col gap-1.5">
          <button
            type="button"
            onClick={() => mapRef.current?.zoomIn()}
            className="w-8 h-8 rounded-lg bg-[#091426]/90 border border-white/15 text-[#F8FAFC] hover:bg-[#12345A] flex items-center justify-center shadow"
            aria-label="Zoom in"
          >
            <ZoomIn className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={() => mapRef.current?.zoomOut()}
            className="w-8 h-8 rounded-lg bg-[#091426]/90 border border-white/15 text-[#F8FAFC] hover:bg-[#12345A] flex items-center justify-center shadow"
            aria-label="Zoom out"
          >
            <ZoomOut className="w-4 h-4" />
          </button>
        </div>

        {/* Active Route Overlay */}
        {activeRouteInfo && (
          <div className="absolute bottom-3 left-3 z-[400] bg-[#091426]/95 border border-[#38BDF8]/40 rounded-lg px-3.5 py-2.5 text-xs shadow-lg max-w-xs">
            <div className="flex items-center gap-2 text-[#38BDF8] font-semibold">
              <Navigation className="w-3.5 h-3.5" />
              <span>Estimated Route · {activeRouteInfo.incidentCode}</span>
            </div>
            <p className="text-[#D9EEFF] mt-1">
              {activeRouteInfo.teamName}
            </p>
            <p className="font-mono text-[#94A3B8] mt-0.5">
              {activeRouteInfo.distanceKm} km · ~{activeRouteInfo.durationMinutes} min ({activeRouteInfo.source.toUpperCase()})
            </p>
          </div>
        )}

        {/* Map Legend */}
        <div className="absolute bottom-3 right-3 z-[400] bg-[#091426]/90 border border-white/10 rounded-lg px-3 py-2 text-[11px] flex flex-wrap items-center gap-3 text-[#D9EEFF]">
          <span className="inline-flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-[#EF4444]" /> Critical
          </span>
          <span className="inline-flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-[#FB923C]" /> High
          </span>
          <span className="inline-flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-[#FFD43B]" /> Medium
          </span>
          <span className="inline-flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-[#168BFF]" /> Low
          </span>
          <span className="inline-flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-[#22C55E]" /> Resolved
          </span>
        </div>
      </div>
    </div>
  );
};
