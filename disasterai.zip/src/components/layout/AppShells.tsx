import React, { useState } from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import {
  Activity,
  AlertTriangle,
  BarChart3,
  Bell,
  ClipboardList,
  FileText,
  History,
  LayoutDashboard,
  LogOut,
  Map as MapIcon,
  Menu,
  Package,
  PhoneCall,
  Radio,
  Settings,
  Shield,
  ShieldCheck,
  Truck,
  Users,
  X,
} from 'lucide-react';
import { useDisaster } from '../../context/DisasterContext';
import { Call1122Modal } from '../ui/DisasterPrimitives';

export const PublicTopBar: React.FC = () => {
  const { sessionUser } = useDisaster();
  const portalHref =
    sessionUser?.role === 'Administrator' || sessionUser?.role === 'Emergency Operator'
      ? '/admin/dashboard'
      : sessionUser?.role === 'Rescue Team Leader'
      ? '/team/dashboard'
      : sessionUser
      ? '/citizen/dashboard'
      : '/login';

  return (
    <header className="sticky top-0 z-50 bg-[#071A33]/95 backdrop-blur-md border-b border-white/10">
      <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between gap-8">
        <Link
          to="/"
          className="text-lg font-display font-bold tracking-tight text-[#F8FAFC] whitespace-nowrap shrink-0"
        >
          DisasterAI
        </Link>

        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-[#D9EEFF]">
          <Link to="/citizen/dashboard" className="hover:text-white transition-colors whitespace-nowrap shrink-0">
            Citizen Portal
          </Link>
          <Link to="/admin/dashboard" className="hover:text-white transition-colors whitespace-nowrap shrink-0">
            Command Center
          </Link>
          <Link to="/team/dashboard" className="hover:text-white transition-colors whitespace-nowrap shrink-0">
            Rescue Teams
          </Link>
          <Link to="/safety" className="hover:text-white transition-colors whitespace-nowrap shrink-0">
            Safety Center
          </Link>
          <Link to="/about" className="hover:text-white transition-colors whitespace-nowrap shrink-0">
            About
          </Link>
        </nav>

        <div className="flex items-center shrink-0">
          <Link
            to={portalHref}
            className="px-4 py-2 rounded-lg bg-[#168BFF] hover:bg-[#38BDF8] hover:text-[#071A33] text-white text-xs font-semibold transition-colors whitespace-nowrap shrink-0"
          >
            {sessionUser ? 'Open Workspace' : 'Sign In'}
          </Link>
        </div>
      </div>
    </header>
  );
};

interface NavItem {
  to: string;
  label: string;
  icon: React.FC<{ className?: string }>;
}

const CITIZEN_NAV: NavItem[] = [
  { to: '/citizen/dashboard', label: 'Emergency Home', icon: LayoutDashboard },
  { to: '/citizen/report-emergency', label: 'Report Emergency', icon: AlertTriangle },
  { to: '/citizen/my-reports', label: 'My Reports', icon: FileText },
  { to: '/citizen/safety-center', label: 'Safety Center', icon: ShieldCheck },
];

const ADMIN_NAV: NavItem[] = [
  { to: '/admin/dashboard', label: 'Command Overview', icon: LayoutDashboard },
  { to: '/admin/live-map', label: 'Live GIS Map', icon: MapIcon },
  { to: '/admin/incidents', label: 'Incidents Queue', icon: ClipboardList },
  { to: '/admin/rescue-teams', label: 'Rescue Teams', icon: Users },
  { to: '/admin/assignments', label: 'Team Assignments', icon: Truck },
  { to: '/admin/resources', label: 'Resources & Fleet', icon: Package },
  { to: '/admin/analytics', label: 'Analytics', icon: BarChart3 },
  { to: '/admin/notifications', label: 'Notifications', icon: Bell },
  { to: '/admin/settings', label: 'Settings & Demo', icon: Settings },
];

const TEAM_NAV: NavItem[] = [
  { to: '/team/dashboard', label: 'Team Operations', icon: Radio },
  { to: '/team/assignments', label: 'Active Assignments', icon: Truck },
  { to: '/team/resources', label: 'Unit Resources', icon: Package },
  { to: '/team/history', label: 'Mission History', icon: History },
];

export const PortalShell: React.FC<{
  portal: 'citizen' | 'admin' | 'team';
  breadcrumb: string;
  children: React.ReactNode;
}> = ({ portal, breadcrumb, children }) => {
  const {
    sessionUser,
    wsConnected,
    demoMode,
    notifications,
    logout,
    signInDemoRole,
  } = useDisaster();
  const navigate = useNavigate();
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [callOpen, setCallOpen] = useState(false);

  const navItems =
    portal === 'admin' ? ADMIN_NAV : portal === 'team' ? TEAM_NAV : CITIZEN_NAV;

  const unreadCount = notifications.filter((n) => !n.read).length;

  const portalTitle =
    portal === 'admin'
      ? 'Command Center'
      : portal === 'team'
      ? 'Rescue Operations'
      : 'Citizen Portal';

  const handlePortalSwitch = (target: 'citizen' | 'admin' | 'team') => {
    if (target === 'citizen') {
      if (!sessionUser || sessionUser.isDemoSession) signInDemoRole('Citizen');
      navigate('/citizen/dashboard');
    } else if (target === 'admin') {
      if (!sessionUser || sessionUser.isDemoSession) signInDemoRole('Emergency Operator');
      navigate('/admin/dashboard');
    } else {
      if (!sessionUser || sessionUser.isDemoSession) signInDemoRole('Rescue Team Leader');
      navigate('/team/dashboard');
    }
  };

  return (
    <div className="min-h-screen bg-[#071A33] text-[#F8FAFC] flex">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex w-[260px] shrink-0 flex-col bg-[#091426] border-r border-white/10">
        <div className="h-16 px-5 flex items-center justify-between border-b border-white/10">
          <Link to="/" className="font-display font-bold text-lg tracking-tight text-white">
            DisasterAI
          </Link>
          {demoMode && (
            <span className="font-mono text-[10px] font-semibold text-[#FFD43B] tracking-wider">
              DEMO
            </span>
          )}
        </div>

        <div className="px-4 py-3 border-b border-white/10">
          <p className="text-xs text-[#94A3B8] mb-2">{portalTitle}</p>
          <div className="grid grid-cols-3 gap-1 p-1 bg-[#071A33] rounded-lg border border-white/5">
            <button
              type="button"
              onClick={() => handlePortalSwitch('citizen')}
              className={`py-1.5 text-[11px] font-medium rounded-md transition-colors ${
                portal === 'citizen'
                  ? 'bg-[#168BFF] text-white'
                  : 'text-[#94A3B8] hover:text-white'
              }`}
            >
              Citizen
            </button>
            <button
              type="button"
              onClick={() => handlePortalSwitch('admin')}
              className={`py-1.5 text-[11px] font-medium rounded-md transition-colors ${
                portal === 'admin'
                  ? 'bg-[#168BFF] text-white'
                  : 'text-[#94A3B8] hover:text-white'
              }`}
            >
              Command
            </button>
            <button
              type="button"
              onClick={() => handlePortalSwitch('team')}
              className={`py-1.5 text-[11px] font-medium rounded-md transition-colors ${
                portal === 'team'
                  ? 'bg-[#168BFF] text-white'
                  : 'text-[#94A3B8] hover:text-white'
              }`}
            >
              Rescue
            </button>
          </div>
        </div>

        <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
          {navItems.map((item) => {
            const Icon = item.icon;
            return (
              <NavLink
                key={item.to}
                to={item.to}
                className={({ isActive }) =>
                  `flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                    isActive
                      ? 'bg-[#12345A] text-white border border-[#38BDF8]/30'
                      : 'text-[#94A3B8] hover:text-white hover:bg-white/5'
                  }`
                }
              >
                <Icon className="w-4 h-4 shrink-0" />
                <span className="truncate">{item.label}</span>
              </NavLink>
            );
          })}
        </nav>

        <div className="p-4 border-t border-white/10 space-y-3">
          <button
            type="button"
            onClick={() => setCallOpen(true)}
            className="w-full flex items-center justify-center gap-2 px-3 py-2.5 rounded-lg bg-[#EF4444] hover:bg-red-600 text-white text-xs font-semibold transition-colors whitespace-nowrap"
          >
            <PhoneCall className="w-4 h-4 shrink-0" />
            <span>Emergency 1122 · 115 · 101</span>
          </button>

          {sessionUser ? (
            <div className="flex items-center justify-between gap-2 pt-1">
              <div className="min-w-0">
                <p className="text-xs font-semibold text-white truncate">
                  {sessionUser.displayName}
                </p>
                <p className="text-[11px] text-[#94A3B8] truncate">{sessionUser.role}</p>
              </div>
              <button
                type="button"
                onClick={async () => {
                  await logout();
                  navigate('/login');
                }}
                className="p-2 rounded-lg text-[#94A3B8] hover:text-white hover:bg-white/5"
                title="Sign out"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <Link
              to="/login"
              className="block text-center px-3 py-2 rounded-lg border border-white/10 text-xs font-medium text-[#D9EEFF] hover:bg-white/5"
            >
              Sign In / Switch Role
            </Link>
          )}
        </div>
      </aside>

      {/* Mobile Drawer */}
      {drawerOpen && (
        <div className="fixed inset-0 z-[1100] lg:hidden flex">
          <div
            className="fixed inset-0 bg-black/60"
            onClick={() => setDrawerOpen(false)}
          />
          <aside className="relative w-72 max-w-[85vw] bg-[#091426] border-r border-white/10 flex flex-col h-full z-10">
            <div className="h-16 px-4 flex items-center justify-between border-b border-white/10">
              <span className="font-display font-bold text-lg text-white">DisasterAI</span>
              <button
                onClick={() => setDrawerOpen(false)}
                className="p-2 text-[#94A3B8] hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-3 border-b border-white/10 grid grid-cols-3 gap-1">
              <button
                onClick={() => {
                  setDrawerOpen(false);
                  handlePortalSwitch('citizen');
                }}
                className={`py-1.5 text-xs rounded ${portal === 'citizen' ? 'bg-[#168BFF] text-white' : 'text-[#94A3B8]'}`}
              >
                Citizen
              </button>
              <button
                onClick={() => {
                  setDrawerOpen(false);
                  handlePortalSwitch('admin');
                }}
                className={`py-1.5 text-xs rounded ${portal === 'admin' ? 'bg-[#168BFF] text-white' : 'text-[#94A3B8]'}`}
              >
                Command
              </button>
              <button
                onClick={() => {
                  setDrawerOpen(false);
                  handlePortalSwitch('team');
                }}
                className={`py-1.5 text-xs rounded ${portal === 'team' ? 'bg-[#168BFF] text-white' : 'text-[#94A3B8]'}`}
              >
                Rescue
              </button>
            </div>
            <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
              {navItems.map((item) => {
                const Icon = item.icon;
                return (
                  <NavLink
                    key={item.to}
                    to={item.to}
                    onClick={() => setDrawerOpen(false)}
                    className={({ isActive }) =>
                      `flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium ${
                        isActive ? 'bg-[#12345A] text-white' : 'text-[#94A3B8]'
                      }`
                    }
                  >
                    <Icon className="w-4 h-4" />
                    <span>{item.label}</span>
                  </NavLink>
                );
              })}
            </nav>
          </aside>
        </div>
      )}

      {/* Main Content Area */}
      <div className="flex-1 min-w-0 flex flex-col">
        <header className="h-16 px-4 lg:px-8 border-b border-white/10 bg-[#091426]/60 backdrop-blur-md flex items-center justify-between gap-4 sticky top-0 z-30">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setDrawerOpen(true)}
              className="lg:hidden p-2 rounded-lg text-[#D9EEFF] hover:bg-white/5"
              aria-label="Open navigation menu"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-2 text-sm min-w-0">
              <Shield className="w-4 h-4 text-[#38BDF8] shrink-0 hidden sm:block" />
              <span className="text-[#94A3B8] truncate">{portalTitle}</span>
              <span className="text-[#94A3B8]" aria-hidden="true">/</span>
              <span className="font-semibold text-[#F8FAFC] truncate">{breadcrumb}</span>
            </div>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            {demoMode && (
              <span className="hidden sm:inline-block text-xs font-mono text-[#FFD43B]">
                DEMO DATA ACTIVE
              </span>
            )}
            <div
              className="hidden md:flex items-center gap-1.5 text-xs text-[#94A3B8]"
              title={wsConnected ? 'Live WebSocket Telemetry Connected' : 'Reconnecting WebSocket'}
            >
              <Activity className={`w-3.5 h-3.5 ${wsConnected ? 'text-[#22C55E]' : 'text-[#FFD43B]'}`} />
              <span>{wsConnected ? 'Live Sync' : 'Syncing'}</span>
            </div>

            <Link
              to="/admin/notifications"
              className="relative p-2 rounded-lg text-[#D9EEFF] hover:bg-white/5 border border-white/10"
              aria-label="View notifications"
            >
              <Bell className="w-4 h-4" />
              {unreadCount > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-[#EF4444] text-[10px] font-mono font-bold text-white flex items-center justify-center">
                  {unreadCount > 9 ? '9+' : unreadCount}
                </span>
              )}
            </Link>

            {portal === 'citizen' ? (
              <Link
                to="/citizen/report-emergency"
                className="px-3.5 py-2 rounded-lg bg-[#168BFF] hover:bg-[#38BDF8] hover:text-[#071A33] text-white text-xs font-semibold transition-colors whitespace-nowrap"
              >
                Report Emergency
              </Link>
            ) : (
              <Link
                to="/admin/live-map"
                className="px-3.5 py-2 rounded-lg bg-[#168BFF] hover:bg-[#38BDF8] hover:text-[#071A33] text-white text-xs font-semibold transition-colors whitespace-nowrap"
              >
                Live Map
              </Link>
            )}
          </div>
        </header>

        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-[1440px] w-full mx-auto">
          {children}
        </main>
      </div>

      <Call1122Modal open={callOpen} onClose={() => setCallOpen(false)} />
    </div>
  );
};
