export type UserRole =
  | 'Citizen'
  | 'Emergency Operator'
  | 'Rescue Team Leader'
  | 'Administrator';

export type IncidentCategory =
  | 'Flood'
  | 'Road Accident'
  | 'Fire'
  | 'Earthquake'
  | 'Building Collapse'
  | 'Medical Emergency'
  | 'Missing Person'
  | 'Rescue Request'
  | 'Other';

export type IncidentStatus =
  | 'Submitted'
  | 'Under Review'
  | 'Verified'
  | 'Team Assigned'
  | 'Team En Route'
  | 'Rescue in Progress'
  | 'Resolved'
  | 'Closed'
  | 'Rejected';

export type PriorityLevel = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';

export type TeamType =
  | 'Medical Response Team'
  | 'Fire & Rescue Team'
  | 'Flood Rescue Team'
  | 'Disaster Recovery Team'
  | 'General Emergency Team';

export type TeamStatus =
  | 'Available'
  | 'Assigned'
  | 'En Route'
  | 'On Site'
  | 'Busy'
  | 'Offline';

export type AssignmentStatus =
  | 'Pending'
  | 'Accepted'
  | 'Rejected'
  | 'En Route'
  | 'On Site'
  | 'In Progress'
  | 'Completed';

export type ResourceCategory =
  | 'Ambulance'
  | 'Rescue Vehicle'
  | 'Fire Truck'
  | 'Medical Kit'
  | 'First Aid'
  | 'Life Jackets'
  | 'Boat'
  | 'Rescue Equipment'
  | 'Emergency Shelter'
  | 'Medical Supplies';

export type ResourceAvailability =
  | 'Available'
  | 'Deployed'
  | 'Low Stock'
  | 'Unavailable';

export type NotificationType =
  | 'new_incident'
  | 'critical_alert'
  | 'team_assignment'
  | 'team_response'
  | 'status_change'
  | 'resource_shortage'
  | 'duplicate_warning'
  | 'hospital_alert';

export interface RiskFactor {
  factor: string;
  impact: number;
  detail: string;
}

export interface ImageAnalysisResult {
  predictedCategory: string;
  confidence: number;
  visualFindings: string;
  hazardDetected: boolean;
}

export interface AIAnalysisResult {
  predictedCategory: IncidentCategory;
  severityScore: number;
  priority: PriorityLevel;
  confidence: number;
  riskFactors: RiskFactor[];
  explanation: string;
  recommendedActions: string[];
  imageAnalysis?: ImageAnalysisResult | null;
  modelUsed: 'gemini-4-hydrogen' | 'rule-based-fallback';
}

export interface DuplicateMatch {
  incidentId: string;
  incidentCode: string;
  title: string;
  category: IncidentCategory;
  distanceKm: number;
  similarityScore: number;
  reason: string;
  reportedAt: string;
}

export interface IncidentStatusUpdate {
  id: string;
  incidentId: string;
  status: IncidentStatus;
  note: string;
  actorUid: string;
  actorName: string;
  createdAt: string;
}

export interface Incident {
  id: string;
  incidentCode: string;
  reporterUid: string;
  reporterName: string;
  contactPhone?: string;
  category: IncidentCategory;
  title: string;
  description: string;
  city: string;
  address: string;
  lat: number;
  lng: number;
  peopleAffected: number;
  injuredCount: number;
  trapped: boolean;
  hazards: string[];
  imageUrls: string[];
  videoUrl?: string;
  status: IncidentStatus;
  severityScore: number;
  priority: PriorityLevel;
  aiConfidence: number;
  aiExplanation: string;
  aiRiskFactors: RiskFactor[];
  aiRecommendedActions: string[];
  aiImageAnalysis?: ImageAnalysisResult | null;
  aiModelUsed?: string;
  duplicateMatches?: DuplicateMatch[];
  mergedChildIds?: string[];
  duplicateOfId?: string;
  assignedTeamId?: string;
  assignedTeamName?: string;
  assignedTeamLeaderUid?: string;
  etaMinutes?: number;
  operatorNotes?: string;
  isPublicAlert: boolean;
  isDemo: boolean;
  createdAt: string;
  updatedAt: string;
  statusHistory: IncidentStatusUpdate[];
}

export interface RescueTeam {
  id: string;
  teamCode: string;
  name: string;
  leaderName: string;
  leaderUid?: string;
  contactNumber: string;
  teamType: TeamType;
  status: TeamStatus;
  lat: number;
  lng: number;
  city: string;
  memberCount: number;
  vehicleInfo: string;
  equipment: string[];
  currentIncidentId?: string;
  incidentsHandled: number;
  isActive: boolean;
  isDemo: boolean;
  updatedAt: string;
}

export interface TeamRecommendation {
  team: RescueTeam;
  distanceKm: number;
  etaMinutes: number;
  suitabilityScore: number;
  specializationMatch: boolean;
  rationale: string;
}

export interface TeamAssignment {
  id: string;
  incidentId: string;
  incidentCode: string;
  incidentTitle: string;
  incidentCategory: IncidentCategory;
  incidentPriority: PriorityLevel;
  incidentAddress: string;
  incidentLat: number;
  incidentLng: number;
  teamId: string;
  teamName: string;
  teamLeaderUid?: string;
  assignedByUid: string;
  assignedByName: string;
  status: AssignmentStatus;
  rejectionReason?: string;
  etaMinutes: number;
  distanceKm: number;
  progressNotes: string;
  requestedResources?: string[];
  createdAt: string;
  updatedAt: string;
}

export interface Resource {
  id: string;
  resourceCode: string;
  name: string;
  category: ResourceCategory;
  quantity: number;
  availableQuantity: number;
  locationName: string;
  availability: ResourceAvailability;
  assignedIncidentId?: string;
  responsibleTeamId?: string;
  responsibleTeamName?: string;
  isActive: boolean;
  isDemo: boolean;
  updatedAt: string;
}

export interface AppNotification {
  id: string;
  targetUid?: string;
  targetRole: UserRole | 'All';
  type: NotificationType;
  title: string;
  message: string;
  incidentId?: string;
  read: boolean;
  isDemo: boolean;
  createdAt: string;
}

export interface RescueOperationReport {
  id: string;
  incidentId: string;
  incidentCode: string;
  assignmentId: string;
  teamId: string;
  teamName: string;
  submittedByUid: string;
  submittedByName: string;
  summary: string;
  peopleRescued: number;
  casualtiesTreated: number;
  photoUrls: string[];
  createdAt: string;
}

export interface AuditLog {
  id: string;
  actorUid: string;
  actorName: string;
  action: string;
  entityType: string;
  entityId: string;
  details: string;
  createdAt: string;
}

export type HospitalAlertStatus =
  | 'Notified'
  | 'First Aid Dispatched'
  | 'ER Trauma Standby';

export interface Hospital {
  id: string;
  name: string;
  city: string;
  address: string;
  lat: number;
  lng: number;
  emergencyPhone: string;
  traumaLevel: 'Level 1 Trauma' | 'General Emergency' | 'Cardiac & Burns';
  firstAidReady: boolean;
  availableAmbulances: number;
  distanceKm?: number;
  etaMinutes?: number;
}

export interface HospitalAlert {
  id: string;
  incidentId: string;
  incidentCode: string;
  hospitalId: string;
  hospitalName: string;
  hospitalAddress: string;
  hospitalPhone: string;
  distanceKm: number;
  status: HospitalAlertStatus;
  firstAidEtaMinutes: number;
  notifiedByUid: string;
  notes?: string;
  isDemo: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface SystemStatePayload {
  incidents: Incident[];
  teams: RescueTeam[];
  assignments: TeamAssignment[];
  resources: Resource[];
  notifications: AppNotification[];
  reports: RescueOperationReport[];
  auditLogs: AuditLog[];
  hospitals: Hospital[];
  hospitalAlerts: HospitalAlert[];
  smsConfigured: boolean;
  demoMode: boolean;
  serverTime: string;
}
