# DisasterAI Security Specification (Phase 0)

## 1. Data Invariants
1. **Identity Integrity**: A citizen may only create an incident where `reporterUid == request.auth.uid`. Citizens cannot set `status` to anything other than `"Submitted"` on creation or assign rescue teams.
2. **PII Isolation**: User email, phone, and physical address reside in `/users/{userId}/private/{docId}` and are readable only by the owning user or verified admins.
3. **Privilege Escalation Prevention**: Users creating `/users/{userId}` cannot self-assign `Emergency Operator` or `Administrator` roles unless verified as the bootstrapped admin email.
4. **Immutable Ownership & Timestamps**: `createdAt` must equal `request.time` on creation and remain immutable on update. `reporterUid` cannot be modified after creation.
5. **Terminal State Locking**: Incidents in `Closed` state cannot be modified by non-admin accounts.
6. **Subcollection Master Gate**: `/incidents/{incidentId}/statusHistory/{historyId}` requires the parent incident to exist and validates actor ownership or operator/assigned-team authority.

## 2. Dirty Dozen Adversarial Payloads (Expected: PERMISSION_DENIED)
1. **Unauthenticated incident creation**: `auth = null` attempting `create /incidents/inc_1`.
2. **Unverified email incident creation**: `email_verified = false` attempting `create /incidents/inc_1`.
3. **Identity spoofing on incident**: User A (`uid_a`) creating `/incidents/inc_1` with `reporterUid: "uid_b"`.
4. **Self-assigning Admin role**: Citizen creating `/users/uid_a` with `role: "Administrator"`.
5. **Shadow field injection**: Citizen creating `/incidents/inc_1` with undocumented extra key `shadowVerified: true`.
6. **Direct admin list mutation**: Citizen writing to `/admins/uid_a`.
7. **PII read leak**: User B reading `/users/uid_a/private/info`.
8. **Invalid ID poisoning**: Creating `/incidents/bad$id..with.spaces` (fails `isValidId`).
9. **Resource exhaustion**: Creating `/incidents/inc_1` with a 50,000-character `title`.
10. **Unauthorized status shortcut**: Citizen updating `/incidents/inc_1` directly to `status: "Team Assigned"`.
11. **Backdated timestamp injection**: Creating `/incidents/inc_1` with `createdAt` different from `request.time`.
12. **Blanket query scraping**: Citizen listing `/incidents` where `reporterUid != request.auth.uid` and `isPublicAlert == false`.
