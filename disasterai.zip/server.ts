import 'dotenv/config';
import express from 'express';
import http from 'http';
import path from 'path';
import { fileURLToPath } from 'url';
import { WebSocket, WebSocketServer } from 'ws';
import { analyzeIncidentWithAI } from './server/aiEngine.ts';
import {
  detectDuplicates,
  fetchOSRMRoute,
  findNearestHospitals,
  recommendTeamsForIncident,
} from './server/geoEngine.ts';
import { store } from './server/store.ts';
import type { HospitalAlertStatus, ResourceCategory } from './src/types/disaster.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT || 3000);
const app = express();
app.use(express.json({ limit: '15mb' }));

// Simple in-memory rate limiter for /api/*
const requestBuckets = new Map<string, { count: number; resetAt: number }>();
app.use('/api', (req, res, next) => {
  const ip = req.ip || 'local';
  const now = Date.now();
  const bucket = requestBuckets.get(ip);
  if (!bucket || bucket.resetAt < now) {
    requestBuckets.set(ip, { count: 1, resetAt: now + 60_000 });
    return next();
  }
  if (bucket.count > 240) {
    return res.status(429).json({ error: 'Rate limit exceeded. Please wait a moment.' });
  }
  bucket.count += 1;
  next();
});

const server = http.createServer(app);
const wss = new WebSocketServer({ server, path: '/ws' });

function broadcast(event: string, payload: unknown) {
  const frame = JSON.stringify({ event, payload, ts: Date.now() });
  wss.clients.forEach((client) => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(frame);
    }
  });
}

store.setBroadcaster(broadcast);

wss.on('connection', (ws) => {
  ws.send(
    JSON.stringify({
      event: 'state:sync',
      payload: store.getState(),
      ts: Date.now(),
    })
  );
});

// Health & System State
app.get('/api/health', (_req, res) => {
  res.json({
    ok: true,
    service: 'DisasterAI',
    geminiConfigured: Boolean(
      process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY !== 'MY_GEMINI_API_KEY'
    ),
    smsConfigured: Boolean(
      process.env.TWILIO_ACCOUNT_SID && process.env.TWILIO_AUTH_TOKEN && process.env.TWILIO_FROM_NUMBER
    ),
  });
});

app.get('/api/state', (_req, res) => {
  res.json(store.getState());
});

// AI Classification & Severity Analysis
app.post('/api/ai/analyze', async (req, res) => {
  try {
    const body = req.body || {};
    if (!body.title || !body.description) {
      return res.status(400).json({ error: 'Title and description are required for AI analysis.' });
    }
    const analysis = await analyzeIncidentWithAI({
      category: body.category,
      title: String(body.title).slice(0, 200),
      description: String(body.description).slice(0, 3000),
      city: String(body.city || 'Karachi'),
      address: String(body.address || 'Karachi'),
      peopleAffected: Math.max(0, Number(body.peopleAffected) || 0),
      injuredCount: Math.max(0, Number(body.injuredCount) || 0),
      trapped: Boolean(body.trapped),
      hazards: Array.isArray(body.hazards) ? body.hazards : [],
      imageDataUrls: Array.isArray(body.imageUrls) ? body.imageUrls : [],
    });
    res.json(analysis);
  } catch (err) {
    console.error('AI analyze error:', err);
    res.status(500).json({ error: 'Failed to analyze incident.' });
  }
});

app.post('/api/ai/check-duplicates', (req, res) => {
  const body = req.body || {};
  const matches = detectDuplicates(
    {
      category: body.category || 'Other',
      title: String(body.title || ''),
      description: String(body.description || ''),
      lat: Number(body.lat) || 24.8607,
      lng: Number(body.lng) || 67.0011,
    },
    store.incidents
  );
  res.json({ matches });
});

// Intelligent Team Recommendations & OSRM Routing
app.get('/api/incidents/:id/recommendations', (req, res) => {
  const incident = store.incidents.find((i) => i.id === req.params.id);
  if (!incident) {
    return res.status(404).json({ error: 'Incident not found' });
  }
  const recommendations = recommendTeamsForIncident(incident, store.teams);
  res.json({ recommendations });
});

// Nearby Hospitals Lookup & First-Aid Notifications
app.get('/api/hospitals/nearby', (req, res) => {
  const lat = Number(req.query.lat ?? 24.8607);
  const lng = Number(req.query.lng ?? 67.0011);
  const limit = Math.max(1, Math.min(10, Number(req.query.limit ?? 4)));
  if (Number.isNaN(lat) || Number.isNaN(lng)) {
    return res.status(400).json({ error: 'Valid numeric lat and lng are required.' });
  }
  const hospitals = findNearestHospitals(lat, lng, store.hospitals, limit);
  res.json({ hospitals });
});

app.post('/api/incidents/:id/notify-hospitals', (req, res) => {
  const incident = store.incidents.find((i) => i.id === req.params.id);
  if (!incident) {
    return res.status(404).json({ error: 'Incident not found' });
  }
  const body = req.body || {};
  const alerts = store.notifyNearbyHospitals({
    incidentId: incident.id,
    hospitalIds: Array.isArray(body.hospitalIds) ? body.hospitalIds : undefined,
    limit: typeof body.limit === 'number' ? body.limit : 2,
    notes: body.notes ? String(body.notes).slice(0, 500) : undefined,
    actorUid: String(body.actorUid || 'operator'),
    actorName: String(body.actorName || 'Citizen / Command Operator'),
  });
  res.status(201).json({ alerts });
});

app.patch('/api/hospital-alerts/:id', (req, res) => {
  const body = req.body || {};
  const validStatuses: HospitalAlertStatus[] = [
    'Notified',
    'First Aid Dispatched',
    'ER Trauma Standby',
  ];
  if (!validStatuses.includes(body.status)) {
    return res.status(400).json({ error: 'Invalid hospital alert status' });
  }
  const updated = store.updateHospitalAlertStatus(
    req.params.id,
    body.status,
    String(body.actorUid || 'operator'),
    String(body.actorName || 'Command Operator'),
    body.notes ? String(body.notes).slice(0, 500) : undefined
  );
  if (!updated) {
    return res.status(404).json({ error: 'Hospital alert not found' });
  }
  res.json(updated);
});

app.get('/api/route', async (req, res) => {
  const fromLat = Number(req.query.fromLat);
  const fromLng = Number(req.query.fromLng);
  const toLat = Number(req.query.toLat);
  const toLng = Number(req.query.toLng);
  if ([fromLat, fromLng, toLat, toLng].some((v) => Number.isNaN(v))) {
    return res.status(400).json({ error: 'Valid numeric coordinates required.' });
  }
  const route = await fetchOSRMRoute(fromLat, fromLng, toLat, toLng);
  res.json(route);
});

// Incidents CRUD
app.post('/api/incidents', async (req, res) => {
  try {
    const body = req.body || {};
    if (!body.title || !body.description || !body.address) {
      return res.status(400).json({ error: 'Title, description, and address are required.' });
    }
    const lat = Number(body.lat);
    const lng = Number(body.lng);
    if (Number.isNaN(lat) || Number.isNaN(lng)) {
      return res.status(400).json({ error: 'Valid latitude and longitude are required.' });
    }

    const incident = await store.createIncident({
      reporterUid: String(body.reporterUid || 'citizen_user'),
      reporterName: String(body.reporterName || 'Citizen Reporter'),
      contactPhone: body.contactPhone ? String(body.contactPhone) : undefined,
      category: body.category,
      title: String(body.title).trim().slice(0, 160),
      description: String(body.description).trim().slice(0, 3000),
      city: String(body.city || 'Karachi').trim(),
      address: String(body.address).trim().slice(0, 300),
      lat,
      lng,
      peopleAffected: Math.max(0, Math.round(Number(body.peopleAffected) || 0)),
      injuredCount: Math.max(0, Math.round(Number(body.injuredCount) || 0)),
      trapped: Boolean(body.trapped),
      hazards: Array.isArray(body.hazards) ? body.hazards.slice(0, 10) : [],
      imageUrls: Array.isArray(body.imageUrls) ? body.imageUrls.slice(0, 4) : [],
      videoUrl: body.videoUrl ? String(body.videoUrl) : undefined,
      isDemo: Boolean(body.isDemo),
    });

    res.status(201).json(incident);
  } catch (err) {
    console.error('Create incident error:', err);
    res.status(500).json({ error: 'Failed to submit emergency report.' });
  }
});

app.patch('/api/incidents/:id', (req, res) => {
  const body = req.body || {};
  const updated = store.updateIncident(req.params.id, {
    status: body.status,
    severityScore: body.severityScore,
    priority: body.priority,
    operatorNotes: body.operatorNotes,
    isPublicAlert: body.isPublicAlert,
    note: body.note,
    actorUid: String(body.actorUid || 'operator'),
    actorName: String(body.actorName || 'Command Operator'),
  });
  if (!updated) return res.status(404).json({ error: 'Incident not found' });
  res.json(updated);
});

app.post('/api/incidents/:id/merge', (req, res) => {
  const body = req.body || {};
  if (!body.duplicateId) {
    return res.status(400).json({ error: 'duplicateId is required' });
  }
  const result = store.mergeIncidents(
    req.params.id,
    String(body.duplicateId),
    String(body.actorUid || 'operator'),
    String(body.actorName || 'Command Operator')
  );
  if (!result) return res.status(404).json({ error: 'Incident pair not found' });
  res.json(result);
});

app.post('/api/incidents/:id/assign', (req, res) => {
  const body = req.body || {};
  if (!body.teamId) {
    return res.status(400).json({ error: 'teamId is required' });
  }
  const result = store.assignTeam({
    incidentId: req.params.id,
    teamId: String(body.teamId),
    actorUid: String(body.actorUid || 'operator'),
    actorName: String(body.actorName || 'Command Operator'),
    etaMinutes: typeof body.etaMinutes === 'number' ? body.etaMinutes : undefined,
  });
  if (!result) return res.status(404).json({ error: 'Incident or rescue team not found' });
  res.status(201).json(result);
});

// Assignments & Rescue Team Operations
app.patch('/api/assignments/:id', (req, res) => {
  const body = req.body || {};
  const updated = store.updateAssignment(req.params.id, {
    status: body.status,
    rejectionReason: body.rejectionReason,
    progressNotes: body.progressNotes,
    requestedResources: Array.isArray(body.requestedResources) ? body.requestedResources : undefined,
    peopleRescued: typeof body.peopleRescued === 'number' ? body.peopleRescued : undefined,
    casualtiesTreated: typeof body.casualtiesTreated === 'number' ? body.casualtiesTreated : undefined,
    summary: body.summary,
    photoUrls: Array.isArray(body.photoUrls) ? body.photoUrls : undefined,
    actorUid: String(body.actorUid || 'team_leader'),
    actorName: String(body.actorName || 'Rescue Team Leader'),
  });
  if (!updated) return res.status(404).json({ error: 'Assignment not found' });
  res.json(updated);
});

app.post('/api/teams/:id/location', (req, res) => {
  const body = req.body || {};
  const lat = Number(body.lat);
  const lng = Number(body.lng);
  if (Number.isNaN(lat) || Number.isNaN(lng)) {
    return res.status(400).json({ error: 'Valid lat and lng required' });
  }
  const team = store.updateTeamLocation(req.params.id, lat, lng, body.status);
  if (!team) return res.status(404).json({ error: 'Team not found' });
  res.json(team);
});

// Resources
app.post('/api/resources', (req, res) => {
  const body = req.body || {};
  if (!body.name || !body.category || !body.locationName) {
    return res.status(400).json({ error: 'Name, category, and locationName are required.' });
  }
  const qty = Math.max(1, Math.round(Number(body.quantity) || 1));
  const resource = {
    id: `res_${Date.now()}`,
    resourceCode: `RES-${Math.floor(100 + Math.random() * 900)}`,
    name: String(body.name).trim(),
    category: body.category as ResourceCategory,
    quantity: qty,
    availableQuantity: qty,
    locationName: String(body.locationName).trim(),
    availability: 'Available' as const,
    isActive: true,
    isDemo: Boolean(body.isDemo),
    updatedAt: new Date().toISOString(),
  };
  store.resources.unshift(resource);
  broadcast('resource:updated', resource);
  res.status(201).json(resource);
});

app.patch('/api/resources/:id', (req, res) => {
  const body = req.body || {};
  const updated = store.updateResource(req.params.id, {
    deltaAvailable: typeof body.deltaAvailable === 'number' ? body.deltaAvailable : undefined,
    availableQuantity: typeof body.availableQuantity === 'number' ? body.availableQuantity : undefined,
    assignedIncidentId: body.assignedIncidentId,
    responsibleTeamId: body.responsibleTeamId,
    actorUid: String(body.actorUid || 'operator'),
    actorName: String(body.actorName || 'Command Operator'),
  });
  if (!updated) return res.status(404).json({ error: 'Resource not found' });
  res.json(updated);
});

// Notifications
app.patch('/api/notifications/:id/read', (req, res) => {
  const updated = store.markNotificationRead(req.params.id);
  if (!updated) return res.status(404).json({ error: 'Notification not found' });
  res.json(updated);
});

app.post('/api/notifications/read-all', (_req, res) => {
  store.markAllNotificationsRead();
  res.json({ ok: true });
});

// Demo Mode & Hackathon Simulation Actions
app.post('/api/demo/mode', (req, res) => {
  store.demoMode = Boolean(req.body?.demoMode);
  broadcast('state:sync', store.getState());
  res.json({ demoMode: store.demoMode });
});

app.post('/api/demo/simulate', async (req, res) => {
  const action = String(req.body?.action || '');
  try {
    if (action === 'reset') {
      store.resetDemo();
      return res.json({ message: 'Demo environment reset to baseline Karachi scenario.', state: store.getState() });
    }

    if (action === 'new_flood') {
      const incident = await store.createIncident({
        reporterUid: 'demo_sim_citizen',
        reporterName: 'Kamran Baloch (DEMO)',
        contactPhone: '+92-300-5544332',
        category: 'Flood',
        title: 'Monsoon Surge Trapping Families in Korangi Crossing Nullah',
        description:
          'Stormwater overflowing drainage channel near Korangi Crossing. Water entering ground-floor rooms; 12 people including children stranded on rooftop.',
        city: 'Karachi',
        address: 'Korangi Crossing Road, Sector 31, Karachi',
        lat: 24.8265,
        lng: 67.1088,
        peopleAffected: 12,
        injuredCount: 1,
        trapped: true,
        hazards: ['Flooding', 'Electrocution Risk'],
        imageUrls: ['/src/assets/images/demo_flood_karachi_1794977833542.jpg'],
        isDemo: true,
      });
      return res.json({ message: `Simulated flood report ${incident.incidentCode}`, incident });
    }

    if (action === 'critical_fire') {
      const incident = await store.createIncident({
        reporterUid: 'demo_sim_citizen',
        reporterName: 'Salman Sheikh (DEMO)',
        contactPhone: '+92-321-7788990',
        category: 'Fire',
        title: 'Critical Electronics Market Fire at Saddar Regal Chowk',
        description:
          'Short circuit triggered fast-spreading fire in ground floor battery shop at Regal Chowk, Saddar. Smoke filling upper apartment floors with 6 residents trapped.',
        city: 'Karachi',
        address: 'Regal Chowk, Saddar Town, Karachi',
        lat: 24.8592,
        lng: 67.0267,
        peopleAffected: 28,
        injuredCount: 4,
        trapped: true,
        hazards: ['Fire / Explosion Risk', 'Toxic Smoke'],
        imageUrls: ['/src/assets/images/demo_fire_warehouse_1794977834025.jpg'],
        isDemo: true,
      });
      return res.json({ message: `Simulated critical fire ${incident.incidentCode}`, incident });
    }

    if (action === 'nearby_duplicate') {
      const base = store.incidents.find((i) => i.status !== 'Closed' && i.status !== 'Resolved') || store.incidents[0];
      const incident = await store.createIncident({
        reporterUid: 'demo_sim_neighbor',
        reporterName: 'Nabeel Ahmed (DEMO)',
        contactPhone: '+92-333-1239876',
        category: base.category,
        title: `Neighbor Report: ${base.title.slice(0, 48)}`,
        description: `Corroborating citizen alert 180m away from ${base.address}. Urgent rescue needed for same incident zone.`,
        city: base.city,
        address: `Adjacent Lane, ${base.address}`,
        lat: base.lat + 0.0014,
        lng: base.lng - 0.0011,
        peopleAffected: 6,
        injuredCount: 1,
        trapped: base.trapped,
        hazards: base.hazards,
        isDemo: true,
      });
      return res.json({ message: `Simulated nearby duplicate ${incident.incidentCode}`, incident });
    }

    if (action === 'team_accept') {
      const pending = store.assignments.find((a) => a.status === 'Pending');
      if (!pending) return res.status(400).json({ error: 'No pending assignments to accept.' });
      const updated = store.updateAssignment(pending.id, {
        status: 'Accepted',
        progressNotes: 'Team leader accepted dispatch order (DEMO).',
        actorUid: 'demo_team_leader',
        actorName: pending.teamName,
      });
      return res.json({ message: `Accepted assignment for ${pending.incidentCode}`, assignment: updated });
    }

    if (action === 'team_enroute') {
      const active = store.assignments.find((a) => a.status === 'Accepted' || a.status === 'Pending');
      if (!active) return res.status(400).json({ error: 'No accepted assignment to move en route.' });
      const team = store.teams.find((t) => t.id === active.teamId);
      if (team) {
        store.updateTeamLocation(
          team.id,
          (team.lat + active.incidentLat) / 2,
          (team.lng + active.incidentLng) / 2,
          'En Route'
        );
      }
      const updated = store.updateAssignment(active.id, {
        status: 'En Route',
        progressNotes: 'Vehicle lights & sirens active; midway to incident.',
        actorUid: 'demo_team_leader',
        actorName: active.teamName,
      });
      return res.json({ message: `${active.teamName} is now En Route`, assignment: updated });
    }

    if (action === 'team_arrive') {
      const enroute = store.assignments.find((a) => a.status === 'En Route' || a.status === 'Accepted');
      if (!enroute) return res.status(400).json({ error: 'No en-route team available to arrive.' });
      const updated = store.updateAssignment(enroute.id, {
        status: 'On Site',
        progressNotes: 'Arrived on site and established rescue perimeter.',
        actorUid: 'demo_team_leader',
        actorName: enroute.teamName,
      });
      return res.json({ message: `${enroute.teamName} arrived On Site`, assignment: updated });
    }

    if (action === 'resolve_incident') {
      const activeAsg = store.assignments.find(
        (a) => a.status === 'On Site' || a.status === 'In Progress' || a.status === 'En Route'
      );
      if (activeAsg) {
        const updated = store.updateAssignment(activeAsg.id, {
          status: 'Completed',
          summary: 'Demo simulation: All occupants safely evacuated and scene stabilized.',
          peopleRescued: 12,
          casualtiesTreated: 2,
          actorUid: 'demo_team_leader',
          actorName: activeAsg.teamName,
        });
        return res.json({ message: `Resolved ${activeAsg.incidentCode}`, assignment: updated });
      }
      const openInc = store.incidents.find((i) => i.status !== 'Resolved' && i.status !== 'Closed');
      if (openInc) {
        const updated = store.updateIncident(openInc.id, {
          status: 'Resolved',
          note: 'Marked resolved via demo simulation.',
          actorUid: 'demo_op',
          actorName: 'Command Operator (DEMO)',
        });
        return res.json({ message: `Resolved ${openInc.incidentCode}`, incident: updated });
      }
      return res.status(400).json({ error: 'No active incidents to resolve.' });
    }

    return res.status(400).json({ error: 'Unknown simulation action' });
  } catch (err) {
    console.error('Demo simulate error:', err);
    res.status(500).json({ error: 'Demo simulation failed' });
  }
});

// Vite / Static Hosting
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`DisasterAI server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
