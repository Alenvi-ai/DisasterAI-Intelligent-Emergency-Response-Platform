import type {
  DuplicateMatch,
  Hospital,
  Incident,
  IncidentCategory,
  RescueTeam,
  TeamRecommendation,
  TeamType,
} from '../src/types/disaster.ts';

export function haversineKm(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLng = ((lng2 - lng1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLng / 2) *
      Math.sin(dLng / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Number((R * c).toFixed(2));
}

function tokenize(text: string): Set<string> {
  return new Set(
    text
      .toLowerCase()
      .replace(/[^a-z0-9\s]/g, ' ')
      .split(/\s+/)
      .filter((t) => t.length > 2)
  );
}

function jaccardSimilarity(a: string, b: string): number {
  const setA = tokenize(a);
  const setB = tokenize(b);
  if (setA.size === 0 || setB.size === 0) return 0;
  let intersection = 0;
  for (const item of setA) {
    if (setB.has(item)) intersection++;
  }
  const union = setA.size + setB.size - intersection;
  return union === 0 ? 0 : intersection / union;
}

export function detectDuplicates(
  candidate: {
    id?: string;
    category: IncidentCategory;
    title: string;
    description: string;
    lat: number;
    lng: number;
    createdAt?: string;
  },
  existingIncidents: Incident[]
): DuplicateMatch[] {
  const nowMs = candidate.createdAt ? new Date(candidate.createdAt).getTime() : Date.now();
  const matches: DuplicateMatch[] = [];

  for (const existing of existingIncidents) {
    if (candidate.id && existing.id === candidate.id) continue;
    if (existing.status === 'Closed' || existing.status === 'Rejected' || existing.duplicateOfId) {
      continue;
    }

    const distanceKm = haversineKm(candidate.lat, candidate.lng, existing.lat, existing.lng);
    const hoursDiff = Math.abs(nowMs - new Date(existing.createdAt).getTime()) / (1000 * 60 * 60);
    const textSim = jaccardSimilarity(
      `${candidate.title} ${candidate.description}`,
      `${existing.title} ${existing.description}`
    );
    const sameCategory = candidate.category === existing.category;

    const geoScore = distanceKm <= 0.5 ? 0.5 : distanceKm <= 1.5 ? 0.38 : distanceKm <= 3.0 ? 0.22 : 0;
    const catScore = sameCategory ? 0.28 : 0.05;
    const timeScore = hoursDiff <= 2 ? 0.14 : hoursDiff <= 8 ? 0.08 : 0;
    const simScore = Number(Math.min(0.99, geoScore + catScore + timeScore + textSim * 0.35).toFixed(2));

    if ((distanceKm <= 2.5 && sameCategory && hoursDiff <= 12) || (distanceKm <= 1.0 && simScore >= 0.52)) {
      matches.push({
        incidentId: existing.id,
        incidentCode: existing.incidentCode,
        title: existing.title,
        category: existing.category,
        distanceKm,
        similarityScore: simScore,
        reason: `${distanceKm} km apart · ${sameCategory ? 'Matching category' : 'Related hazard'} · ${Math.round(simScore * 100)}% composite similarity`,
        reportedAt: existing.createdAt,
      });
    }
  }

  return matches.sort((a, b) => b.similarityScore - a.similarityScore).slice(0, 4);
}

const CATEGORY_TO_TEAM: Record<IncidentCategory, TeamType[]> = {
  Flood: ['Flood Rescue Team', 'Disaster Recovery Team', 'General Emergency Team'],
  Fire: ['Fire & Rescue Team', 'Disaster Recovery Team'],
  'Building Collapse': ['Disaster Recovery Team', 'Fire & Rescue Team', 'Medical Response Team'],
  Earthquake: ['Disaster Recovery Team', 'Medical Response Team', 'Fire & Rescue Team'],
  'Medical Emergency': ['Medical Response Team', 'General Emergency Team'],
  'Road Accident': ['Medical Response Team', 'Fire & Rescue Team', 'General Emergency Team'],
  'Missing Person': ['General Emergency Team', 'Flood Rescue Team'],
  'Rescue Request': ['General Emergency Team', 'Disaster Recovery Team', 'Flood Rescue Team'],
  Other: ['General Emergency Team', 'Medical Response Team'],
};

export function recommendTeamsForIncident(
  incident: Incident,
  teams: RescueTeam[]
): TeamRecommendation[] {
  const preferredTypes = CATEGORY_TO_TEAM[incident.category] || ['General Emergency Team'];

  const ranked = teams
    .filter((t) => t.isActive && t.status !== 'Offline')
    .map((team) => {
      const distanceKm = haversineKm(incident.lat, incident.lng, team.lat, team.lng);
      const roadFactor = 1.28; // Urban arterial factor for Karachi traffic
      const avgSpeedKmh = incident.priority === 'CRITICAL' ? 44 : 34;
      const etaMinutes = Math.max(3, Math.round(((distanceKm * roadFactor) / avgSpeedKmh) * 60));

      const specIndex = preferredTypes.indexOf(team.teamType);
      const specializationMatch = specIndex === 0;
      const specScore = specIndex === 0 ? 40 : specIndex > 0 ? 25 : 10;
      const availabilityScore =
        team.status === 'Available' ? 32 : team.status === 'Assigned' ? 8 : 4;
      const distanceScore = Math.max(0, 28 - distanceKm * 1.6);

      const suitabilityScore = Math.max(
        10,
        Math.min(100, Math.round(specScore + availabilityScore + distanceScore))
      );

      const rationaleParts = [
        `${distanceKm} km away (~${etaMinutes} min ETA)`,
        specializationMatch
          ? `Direct specialization (${team.teamType})`
          : `Secondary capability (${team.teamType})`,
        team.status === 'Available' ? 'Unit immediately available' : `Currently ${team.status}`,
      ];

      return {
        team,
        distanceKm,
        etaMinutes,
        suitabilityScore,
        specializationMatch,
        rationale: rationaleParts.join(' · '),
      };
    });

  return ranked.sort((a, b) => b.suitabilityScore - a.suitabilityScore);
}

export async function fetchOSRMRoute(
  fromLat: number,
  fromLng: number,
  toLat: number,
  toLng: number
): Promise<{
  coordinates: [number, number][];
  distanceKm: number;
  durationMinutes: number;
  source: 'osrm' | 'estimated';
}> {
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 3500);
    const url = `https://router.project-osrm.org/route/v1/driving/${fromLng},${fromLat};${toLng},${toLat}?overview=full&geometries=geojson`;
    const res = await fetch(url, { signal: controller.signal });
    clearTimeout(timer);

    if (res.ok) {
      const data = await res.json();
      const route = data?.routes?.[0];
      if (route?.geometry?.coordinates?.length) {
        const coords: [number, number][] = route.geometry.coordinates.map(
          ([lng, lat]: [number, number]) => [lat, lng]
        );
        return {
          coordinates: coords,
          distanceKm: Number((route.distance / 1000).toFixed(2)),
          durationMinutes: Math.max(2, Math.round(route.duration / 60)),
          source: 'osrm',
        };
      }
    }
  } catch {
    // Fallback to clean straight-line arterial estimate
  }

  const dist = haversineKm(fromLat, fromLng, toLat, toLng);
  return {
    coordinates: [
      [fromLat, fromLng],
      [(fromLat + toLat) / 2 + 0.002, (fromLng + toLng) / 2 - 0.002],
      [toLat, toLng],
    ],
    distanceKm: dist,
    durationMinutes: Math.max(3, Math.round(((dist * 1.3) / 36) * 60)),
    source: 'estimated',
  };
}

export function findNearestHospitals(
  lat: number,
  lng: number,
  hospitals: Hospital[],
  limit = 4
): Hospital[] {
  return hospitals
    .map((h) => {
      const distanceKm = haversineKm(lat, lng, h.lat, h.lng);
      const etaMinutes = Math.max(3, Math.round(((distanceKm * 1.25) / 38) * 60));
      return {
        ...h,
        distanceKm,
        etaMinutes,
      };
    })
    .sort((a, b) => (a.distanceKm ?? 0) - (b.distanceKm ?? 0))
    .slice(0, limit);
}
