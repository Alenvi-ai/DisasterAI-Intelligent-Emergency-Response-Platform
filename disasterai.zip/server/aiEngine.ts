import { GoogleGenAI, Type } from '@google/genai';
import type {
  AIAnalysisResult,
  IncidentCategory,
  PriorityLevel,
  RiskFactor,
} from '../src/types/disaster.ts';

const VALID_CATEGORIES: IncidentCategory[] = [
  'Flood',
  'Road Accident',
  'Fire',
  'Earthquake',
  'Building Collapse',
  'Medical Emergency',
  'Missing Person',
  'Rescue Request',
  'Other',
];

function getGeminiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY' || apiKey.trim() === '') {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

export function scoreToPriority(score: number): PriorityLevel {
  if (score >= 75) return 'CRITICAL';
  if (score >= 50) return 'HIGH';
  if (score >= 25) return 'MEDIUM';
  return 'LOW';
}

export function runRuleBasedFallback(input: {
  category?: string;
  title: string;
  description: string;
  peopleAffected: number;
  injuredCount: number;
  trapped: boolean;
  hazards: string[];
  hasImages?: boolean;
}): AIAnalysisResult {
  const text = `${input.title} ${input.description}`.toLowerCase();
  let predictedCategory: IncidentCategory = VALID_CATEGORIES.includes(
    input.category as IncidentCategory
  )
    ? (input.category as IncidentCategory)
    : 'Other';

  if (!input.category || input.category === 'Other') {
    if (/flood|water|monsoon|submerged|rain|drain|nullah/.test(text)) {
      predictedCategory = 'Flood';
    } else if (/fire|smoke|flame|burn|explosion|blast|cylinder/.test(text)) {
      predictedCategory = 'Fire';
    } else if (/collapse|rubble|debris|crack|building|roof/.test(text)) {
      predictedCategory = 'Building Collapse';
    } else if (/crash|collision|highway|truck|bus|accident|motorcycle/.test(text)) {
      predictedCategory = 'Road Accident';
    } else if (/quake|tremor|seismic|aftershock/.test(text)) {
      predictedCategory = 'Earthquake';
    } else if (/cardiac|bleeding|unconscious|ambulance|medical|trauma|oxygen/.test(text)) {
      predictedCategory = 'Medical Emergency';
    } else if (/missing|lost|child|elderly|disappeared/.test(text)) {
      predictedCategory = 'Missing Person';
    } else if (/stranded|rescue|evacuate|help/.test(text)) {
      predictedCategory = 'Rescue Request';
    }
  }

  const riskFactors: RiskFactor[] = [];
  let score = 12;

  const categoryWeights: Record<IncidentCategory, number> = {
    'Building Collapse': 28,
    Fire: 24,
    Earthquake: 25,
    Flood: 20,
    'Medical Emergency': 22,
    'Road Accident': 18,
    'Rescue Request': 16,
    'Missing Person': 12,
    Other: 10,
  };
  const catWeight = categoryWeights[predictedCategory] ?? 12;
  score += catWeight;
  riskFactors.push({
    factor: 'Emergency Category Baseline',
    impact: catWeight,
    detail: `${predictedCategory} carries inherent structural or life-safety risk.`,
  });

  if (input.trapped) {
    score += 24;
    riskFactors.push({
      factor: 'Trapped Individuals Reported',
      impact: 24,
      detail: 'Immediate extrication or water/fire rescue required.',
    });
  }

  if (input.injuredCount > 0) {
    const injuryImpact = Math.min(24, input.injuredCount * 4 + 6);
    score += injuryImpact;
    riskFactors.push({
      factor: 'Active Casualties / Injuries',
      impact: injuryImpact,
      detail: `${input.injuredCount} injured person(s) requiring trauma stabilization.`,
    });
  }

  if (input.peopleAffected >= 5) {
    const scaleImpact = Math.min(18, Math.round(Math.log2(input.peopleAffected) * 3.5));
    score += scaleImpact;
    riskFactors.push({
      factor: 'Affected Population Scale',
      impact: scaleImpact,
      detail: `${input.peopleAffected} people impacted within the incident perimeter.`,
    });
  }

  const hazardImpact = Math.min(18, input.hazards.length * 7);
  if (hazardImpact > 0) {
    score += hazardImpact;
    riskFactors.push({
      factor: 'Secondary Hazards',
      impact: hazardImpact,
      detail: `Active hazards flagged: ${input.hazards.join(', ')}.`,
    });
  }

  if (/chemical|gas|hospital|school|elderly|infant|transformer|high voltage/.test(text)) {
    score += 10;
    riskFactors.push({
      factor: 'Vulnerable Site / Critical Infrastructure',
      impact: 10,
      detail: 'Description references high-risk infrastructure or vulnerable persons.',
    });
  }

  const clamped = Math.max(5, Math.min(100, Math.round(score)));
  const priority = scoreToPriority(clamped);

  const recommendedActions: string[] = [];
  if (priority === 'CRITICAL') {
    recommendedActions.push('Dispatch specialized rescue unit immediately with trauma support.');
  }
  if (predictedCategory === 'Fire') {
    recommendedActions.push('Deploy Fire & Rescue tender and isolate nearby electrical feeders.');
  } else if (predictedCategory === 'Flood') {
    recommendedActions.push('Stage inflatable rescue boats, life jackets, and dewatering pumps.');
  } else if (predictedCategory === 'Building Collapse') {
    recommendedActions.push('Establish 50m structural exclusion perimeter and deploy USAR acoustic sensors.');
  } else if (predictedCategory === 'Medical Emergency' || input.injuredCount > 0) {
    recommendedActions.push('Pre-alert nearest tertiary trauma hospital (JPMC / Civil / Aga Khan).');
  } else {
    recommendedActions.push('Verify citizen coordinates and route closest available response unit.');
  }
  recommendedActions.push('Maintain citizen phone contact until first responders reach on-site perimeter.');

  return {
    predictedCategory,
    severityScore: clamped,
    priority,
    confidence: input.hasImages ? 0.81 : 0.76,
    riskFactors,
    explanation: `Rule-based triage scored ${clamped}/100 (${priority}) based on ${predictedCategory} risk, ${input.injuredCount} reported injuries, and ${input.peopleAffected} people affected.`,
    recommendedActions,
    imageAnalysis: input.hasImages
      ? {
          predictedCategory,
          confidence: 0.72,
          visualFindings: `Prototype visual classifier cross-checked uploaded imagery against ${predictedCategory} hazard indicators.`,
          hazardDetected: clamped >= 50,
        }
      : null,
    modelUsed: 'rule-based-fallback',
  };
}

function parseDataUrl(dataUrl: string): { mimeType: string; data: string } | null {
  const match = dataUrl.match(/^data:(image\/[a-zA-Z0-9.+-]+);base64,(.+)$/);
  if (!match) return null;
  return { mimeType: match[1], data: match[2] };
}

export async function analyzeIncidentWithAI(input: {
  category?: string;
  title: string;
  description: string;
  city: string;
  address: string;
  peopleAffected: number;
  injuredCount: number;
  trapped: boolean;
  hazards: string[];
  imageDataUrls?: string[];
}): Promise<AIAnalysisResult> {
  const ai = getGeminiClient();
  const hasImages = Boolean(input.imageDataUrls && input.imageDataUrls.length > 0);

  if (!ai) {
    return runRuleBasedFallback({ ...input, hasImages });
  }

  try {
    const parts: Array<{ text: string } | { inlineData: { mimeType: string; data: string } }> = [];

    if (input.imageDataUrls && input.imageDataUrls.length > 0) {
      for (const img of input.imageDataUrls.slice(0, 2)) {
        const parsed = parseDataUrl(img);
        if (parsed) {
          parts.push({ inlineData: parsed });
        }
      }
    }

    const promptText = `You are the DisasterAI Emergency Triage & Hazard Assessment Engine serving Rescue 1122 and PDMA command centers in Pakistan.
Analyze the citizen emergency report below (and any attached imagery) to produce an explainable severity assessment.

Reported Category: ${input.category || 'Unspecified'}
Title: ${input.title}
Description: ${input.description}
City / Location: ${input.city} — ${input.address}
People Affected: ${input.peopleAffected}
Injured Count: ${input.injuredCount}
Anyone Trapped: ${input.trapped ? 'YES' : 'NO'}
Reported Hazards: ${input.hazards.length ? input.hazards.join(', ') : 'None specified'}

Scoring bands:
0-24: LOW
25-49: MEDIUM
50-74: HIGH
75-100: CRITICAL

Return strict JSON matching the schema. Never dismiss an emergency report; always give transparent risk factors whose impacts explain the score.`;

    parts.push({ text: promptText });

    const response = await ai.models.generateContent({
      model: 'gemini-4-hydrogen',
      contents: { parts },
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            predictedCategory: {
              type: Type.STRING,
              description:
                'One of: Flood, Road Accident, Fire, Earthquake, Building Collapse, Medical Emergency, Missing Person, Rescue Request, Other',
            },
            severityScore: {
              type: Type.INTEGER,
              description: 'Integer 0 to 100',
            },
            priority: {
              type: Type.STRING,
              description: 'One of LOW, MEDIUM, HIGH, CRITICAL',
            },
            confidence: {
              type: Type.NUMBER,
              description: 'Confidence score from 0.0 to 1.0',
            },
            explanation: {
              type: Type.STRING,
              description: 'Concise 2-sentence explanation of why this score was assigned.',
            },
            riskFactors: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  factor: { type: Type.STRING },
                  impact: { type: Type.INTEGER },
                  detail: { type: Type.STRING },
                },
                required: ['factor', 'impact', 'detail'],
              },
            },
            recommendedActions: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
            },
            imageFindings: {
              type: Type.STRING,
              description: 'Visual findings from uploaded images, or empty string if no images.',
            },
            imageHazardDetected: {
              type: Type.BOOLEAN,
            },
          },
          required: [
            'predictedCategory',
            'severityScore',
            'priority',
            'confidence',
            'explanation',
            'riskFactors',
            'recommendedActions',
          ],
        },
      },
    });

    const raw = (response.text ?? '').trim();
    const parsed = JSON.parse(raw);

    const predictedCategory: IncidentCategory = VALID_CATEGORIES.includes(
      parsed.predictedCategory
    )
      ? parsed.predictedCategory
      : runRuleBasedFallback({ ...input, hasImages }).predictedCategory;

    const severityScore = Math.max(
      0,
      Math.min(100, Math.round(Number(parsed.severityScore) || 50))
    );
    const priority = scoreToPriority(severityScore);
    const confidence = Math.max(0.4, Math.min(0.99, Number(parsed.confidence) || 0.85));

    return {
      predictedCategory,
      severityScore,
      priority,
      confidence,
      riskFactors: Array.isArray(parsed.riskFactors) && parsed.riskFactors.length > 0
        ? parsed.riskFactors.slice(0, 6)
        : runRuleBasedFallback({ ...input, hasImages }).riskFactors,
      explanation: parsed.explanation || 'AI triage assessment complete.',
      recommendedActions:
        Array.isArray(parsed.recommendedActions) && parsed.recommendedActions.length > 0
          ? parsed.recommendedActions.slice(0, 5)
          : ['Verify coordinates and dispatch closest specialized team.'],
      imageAnalysis:
        hasImages && parsed.imageFindings
          ? {
              predictedCategory,
              confidence,
              visualFindings: parsed.imageFindings,
              hazardDetected: Boolean(parsed.imageHazardDetected),
            }
          : null,
      modelUsed: 'gemini-4-hydrogen',
    };
  } catch (err) {
    console.warn('Gemini AI analysis unavailable, using rule-based fallback:', err);
    return runRuleBasedFallback({ ...input, hasImages });
  }
}
