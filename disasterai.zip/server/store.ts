import type {
  AppNotification,
  AssignmentStatus,
  AuditLog,
  Hospital,
  HospitalAlert,
  HospitalAlertStatus,
  Incident,
  IncidentCategory,
  IncidentStatus,
  PriorityLevel,
  RescueOperationReport,
  RescueTeam,
  Resource,
  SystemStatePayload,
  TeamAssignment,
} from '../src/types/disaster.ts';
import { analyzeIncidentWithAI, scoreToPriority } from './aiEngine.ts';
import { detectDuplicates, findNearestHospitals, haversineKm } from './geoEngine.ts';
import { createDemoSeedData } from './seed.ts';

class DisasterStore {
  public incidents: Incident[] = [];
  public teams: RescueTeam[] = [];
  public assignments: TeamAssignment[] = [];
  public resources: Resource[] = [];
  public notifications: AppNotification[] = [];
  public reports: RescueOperationReport[] = [];
  public auditLogs: AuditLog[] = [];
  public hospitals: Hospital[] = [];
  public hospitalAlerts: HospitalAlert[] = [];
  public demoMode = true;
  private counter = 1016;
  private broadcastFn: ((event: string, payload: unknown) => void) | null = null;

  constructor() {
    this.resetDemo();
  }

  setBroadcaster(fn: (event: string, payload: unknown) => void) {
    this.broadcastFn = fn;
  }

  private emit(event: string, payload: unknown) {
    if (this.broadcastFn) {
      this.broadcastFn(event, payload);
    }
  }

  private addAudit(actorUid: string, actorName: string, action: string, entityType: string, entityId: string, details: string) {
    const entry: AuditLog = {
      id: `aud_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      actorUid,
      actorName,
      action,
      entityType,
      entityId,
      details,
      createdAt: new Date().toISOString(),
    };
    this.auditLogs.unshift(entry);
    if (this.auditLogs.length > 100) this.auditLogs.pop();
  }

  private addNotification(n: Omit<AppNotification, 'id' | 'createdAt' | 'read'>) {
    const notif: AppNotification = {
      ...n,
      id: `notif_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      read: false,
      createdAt: new Date().toISOString(),
    };
    this.notifications.unshift(notif);
    if (this.notifications.length > 80) this.notifications.pop();
    this.emit('notification:created', notif);
    return notif;
  }

  getState(): SystemStatePayload {
    const smsConfigured = Boolean(
      process.env.TWILIO_ACCOUNT_SID &&
      process.env.TWILIO_AUTH_TOKEN &&
      process.env.TWILIO_FROM_NUMBER
    );
    return {
      incidents: this.incidents,
      teams: this.teams,
      assignments: this.assignments,
      resources: this.resources,
      notifications: this.notifications,
      reports: this.reports,
      auditLogs: this.auditLogs,
      hospitals: this.hospitals,
      hospitalAlerts: this.hospitalAlerts,
      smsConfigured,
      demoMode: this.demoMode,
      serverTime: new Date().toISOString(),
    };
  }

  resetDemo() {
    const seed = createDemoSeedData();
    this.incidents = seed.incidents;
    this.teams = seed.teams;
    this.assignments = seed.assignments;
    this.resources = seed.resources;
    this.notifications = seed.notifications;
    this.reports = seed.reports;
    this.auditLogs = seed.auditLogs;
    this.hospitals = seed.hospitals;
    this.hospitalAlerts = seed.hospitalAlerts;
    this.counter = 1016;
    this.emit('state:sync', this.getState());
  }

  async createIncident(input: {
    reporterUid: string;
    reporterName: string;
    contactPhone?: string;
    category?: IncidentCategory;
    title: string;
    description: string;
    city: string;
    address: string;
    lat: number;
    lng: number;
    peopleAffected: number;
    injuredCount: number;
    trapped: boolean;
    hazards: string[];
    imageUrls?: string[];
    videoUrl?: string;
    isDemo?: boolean;
  }): Promise<Incident> {
    const now = new Date().toISOString();
    const code = `INC-2026-${this.counter++}`;
    const id = `inc_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;

    const ai = await analyzeIncidentWithAI({
      category: input.category,
      title: input.title,
      description: input.description,
      city: input.city,
      address: input.address,
      peopleAffected: input.peopleAffected,
      injuredCount: input.injuredCount,
      trapped: input.trapped,
      hazards: input.hazards,
      imageDataUrls: input.imageUrls,
    });

    const finalCategory: IncidentCategory = input.category && input.category !== 'Other'
      ? input.category
      : ai.predictedCategory;

    const duplicates = detectDuplicates(
      {
        id,
        category: finalCategory,
        title: input.title,
        description: input.description,
        lat: input.lat,
        lng: input.lng,
        createdAt: now,
      },
      this.incidents
    );

    const incident: Incident = {
      id,
      incidentCode: code,
      reporterUid: input.reporterUid,
      reporterName: input.reporterName,
      contactPhone: input.contactPhone,
      category: finalCategory,
      title: input.title,
      description: input.description,
      city: input.city,
      address: input.address,
      lat: input.lat,
      lng: input.lng,
      peopleAffected: input.peopleAffected,
      injuredCount: input.injuredCount,
      trapped: input.trapped,
      hazards: input.hazards,
      imageUrls: input.imageUrls || [],
      videoUrl: input.videoUrl,
      status: 'Submitted',
      severityScore: ai.severityScore,
      priority: ai.priority,
      aiConfidence: ai.confidence,
      aiExplanation: ai.explanation,
      aiRiskFactors: ai.riskFactors,
      aiRecommendedActions: ai.recommendedActions,
      aiImageAnalysis: ai.imageAnalysis,
      aiModelUsed: ai.modelUsed,
      duplicateMatches: duplicates,
      isPublicAlert: ai.priority === 'CRITICAL' || ai.priority === 'HIGH',
      isDemo: Boolean(input.isDemo),
      createdAt: now,
      updatedAt: now,
      statusHistory: [
        {
          id: `hist_${Date.now()}`,
          incidentId: id,
          status: 'Submitted',
          note: `Emergency report submitted (${ai.priority} · AI Score ${ai.severityScore}/100).`,
          actorUid: input.reporterUid,
          actorName: input.reporterName,
          createdAt: now,
        },
      ],
    };

    this.incidents.unshift(incident);
    this.emit('incident:created', incident);

    this.addNotification({
      targetRole: 'Emergency Operator',
      type: incident.priority === 'CRITICAL' ? 'critical_alert' : 'new_incident',
      title: `${incident.priority === 'CRITICAL' ? 'Critical' : 'New'} ${incident.category}: ${incident.incidentCode}`,
      message: `${incident.title} (${incident.city}) — Severity ${incident.severityScore}/100.`,
      incidentId: incident.id,
      isDemo: incident.isDemo,
    });

    if (duplicates.length > 0) {
      this.addNotification({
        targetRole: 'Emergency Operator',
        type: 'duplicate_warning',
        title: `Possible Duplicate Detected (${incident.incidentCode})`,
        message: `Matches ${duplicates[0].incidentCode} (${duplicates[0].distanceKm} km apart). Review before merging.`,
        incidentId: incident.id,
        isDemo: incident.isDemo,
      });
    }

    const shouldAlertHospitals =
      incident.injuredCount > 0 ||
      incident.trapped ||
      incident.priority === 'CRITICAL' ||
      incident.priority === 'HIGH' ||
      incident.category === 'Medical Emergency' ||
      incident.category === 'Fire' ||
      incident.category === 'Road Accident';

    if (shouldAlertHospitals) {
      this.notifyNearbyHospitals({
        incidentId: incident.id,
        limit: 2,
        notes: `Auto-notified on submission for ${incident.category} first-aid standby (${incident.injuredCount} injured).`,
        actorUid: input.reporterUid,
        actorName: input.reporterName,
      });
    }

    return incident;
  }

  updateIncident(
    incidentId: string,
    updates: {
      status?: IncidentStatus;
      severityScore?: number;
      priority?: PriorityLevel;
      operatorNotes?: string;
      isPublicAlert?: boolean;
      note?: string;
      actorUid: string;
      actorName: string;
    }
  ): Incident | null {
    const incident = this.incidents.find((i) => i.id === incidentId);
    if (!incident) return null;

    const now = new Date().toISOString();
    const prevStatus = incident.status;

    if (updates.status) incident.status = updates.status;
    if (typeof updates.severityScore === 'number') {
      incident.severityScore = Math.max(0, Math.min(100, Math.round(updates.severityScore)));
      incident.priority = updates.priority || scoreToPriority(incident.severityScore);
    } else if (updates.priority) {
      incident.priority = updates.priority;
    }
    if (typeof updates.operatorNotes === 'string') {
      incident.operatorNotes = updates.operatorNotes;
    }
    if (typeof updates.isPublicAlert === 'boolean') {
      incident.isPublicAlert = updates.isPublicAlert;
    }
    incident.updatedAt = now;

    if (updates.status && updates.status !== prevStatus) {
      incident.statusHistory.push({
        id: `hist_${Date.now()}_${Math.random().toString(36).slice(2, 5)}`,
        incidentId: incident.id,
        status: updates.status,
        note: updates.note || `Status updated from ${prevStatus} to ${updates.status}.`,
        actorUid: updates.actorUid,
        actorName: updates.actorName,
        createdAt: now,
      });

      this.addNotification({
        targetRole: 'All',
        targetUid: incident.reporterUid,
        type: 'status_change',
        title: `${incident.incidentCode} → ${updates.status}`,
        message: updates.note || `${incident.title} is now ${updates.status}.`,
        incidentId: incident.id,
        isDemo: incident.isDemo,
      });
    }

    this.addAudit(
      updates.actorUid,
      updates.actorName,
      'UPDATE_INCIDENT',
      'incident',
      incident.incidentCode,
      updates.note || `Updated status/severity (${incident.status}, ${incident.severityScore}/100).`
    );

    this.emit('incident:updated', incident);
    return incident;
  }

  mergeIncidents(
    primaryId: string,
    duplicateId: string,
    actorUid: string,
    actorName: string
  ): { primary: Incident; duplicate: Incident } | null {
    const primary = this.incidents.find((i) => i.id === primaryId);
    const duplicate = this.incidents.find((i) => i.id === duplicateId);
    if (!primary || !duplicate || primary.id === duplicate.id) return null;

    const now = new Date().toISOString();
    duplicate.duplicateOfId = primary.id;
    duplicate.status = 'Closed';
    duplicate.updatedAt = now;
    duplicate.statusHistory.push({
      id: `hist_${Date.now()}`,
      incidentId: duplicate.id,
      status: 'Closed',
      note: `Merged into primary incident ${primary.incidentCode} by ${actorName}. Original report preserved.`,
      actorUid,
      actorName,
      createdAt: now,
    });

    primary.mergedChildIds = Array.from(new Set([...(primary.mergedChildIds || []), duplicate.id]));
    primary.peopleAffected += duplicate.peopleAffected;
    primary.injuredCount = Math.max(primary.injuredCount, duplicate.injuredCount);
    primary.imageUrls = Array.from(new Set([...primary.imageUrls, ...duplicate.imageUrls]));
    primary.updatedAt = now;
    primary.statusHistory.push({
      id: `hist_${Date.now()}_m`,
      incidentId: primary.id,
      status: primary.status,
      note: `Merged citizen report ${duplicate.incidentCode} (${duplicate.reporterName}) into this case.`,
      actorUid,
      actorName,
      createdAt: now,
    });

    this.addAudit(
      actorUid,
      actorName,
      'MERGE_DUPLICATE_INCIDENT',
      'incident',
      primary.incidentCode,
      `Merged ${duplicate.incidentCode} into ${primary.incidentCode} while preserving original report.`
    );

    this.emit('incident:updated', primary);
    this.emit('incident:updated', duplicate);
    return { primary, duplicate };
  }

  assignTeam(input: {
    incidentId: string;
    teamId: string;
    actorUid: string;
    actorName: string;
    etaMinutes?: number;
  }): { assignment: TeamAssignment; incident: Incident; team: RescueTeam } | null {
    const incident = this.incidents.find((i) => i.id === input.incidentId);
    const team = this.teams.find((t) => t.id === input.teamId);
    if (!incident || !team) return null;

    const now = new Date().toISOString();
    const distanceKm = haversineKm(incident.lat, incident.lng, team.lat, team.lng);
    const etaMinutes =
      input.etaMinutes ?? Math.max(4, Math.round(((distanceKm * 1.28) / 40) * 60));

    const assignment: TeamAssignment = {
      id: `asg_${Date.now()}_${Math.random().toString(36).slice(2, 5)}`,
      incidentId: incident.id,
      incidentCode: incident.incidentCode,
      incidentTitle: incident.title,
      incidentCategory: incident.category,
      incidentPriority: incident.priority,
      incidentAddress: incident.address,
      incidentLat: incident.lat,
      incidentLng: incident.lng,
      teamId: team.id,
      teamName: team.name,
      teamLeaderUid: team.leaderUid,
      assignedByUid: input.actorUid,
      assignedByName: input.actorName,
      status: 'Pending',
      etaMinutes,
      distanceKm,
      progressNotes: `Dispatched to ${incident.address}.`,
      createdAt: now,
      updatedAt: now,
    };

    this.assignments.unshift(assignment);

    incident.assignedTeamId = team.id;
    incident.assignedTeamName = team.name;
    incident.assignedTeamLeaderUid = team.leaderUid;
    incident.etaMinutes = etaMinutes;
    incident.status = 'Team Assigned';
    incident.updatedAt = now;
    incident.statusHistory.push({
      id: `hist_${Date.now()}`,
      incidentId: incident.id,
      status: 'Team Assigned',
      note: `Assigned ${team.name} (ETA ${etaMinutes} min · ${distanceKm} km).`,
      actorUid: input.actorUid,
      actorName: input.actorName,
      createdAt: now,
    });

    team.status = 'Assigned';
    team.currentIncidentId = incident.id;
    team.updatedAt = now;

    this.addNotification({
      targetRole: 'Rescue Team Leader',
      type: 'team_assignment',
      title: `Dispatch Order: ${incident.incidentCode}`,
      message: `${team.name} assigned to ${incident.title} (${etaMinutes} min ETA).`,
      incidentId: incident.id,
      isDemo: incident.isDemo,
    });

    this.addAudit(
      input.actorUid,
      input.actorName,
      'DISPATCH_TEAM',
      'team_assignment',
      assignment.id,
      `Assigned ${team.name} to ${incident.incidentCode}.`
    );

    this.emit('assignment:created', assignment);
    this.emit('incident:updated', incident);
    this.emit('team:updated', team);
    return { assignment, incident, team };
  }

  updateAssignment(
    assignmentId: string,
    updates: {
      status?: AssignmentStatus;
      rejectionReason?: string;
      progressNotes?: string;
      requestedResources?: string[];
      peopleRescued?: number;
      casualtiesTreated?: number;
      summary?: string;
      photoUrls?: string[];
      actorUid: string;
      actorName: string;
    }
  ): TeamAssignment | null {
    const assignment = this.assignments.find((a) => a.id === assignmentId);
    if (!assignment) return null;

    const incident = this.incidents.find((i) => i.id === assignment.incidentId);
    const team = this.teams.find((t) => t.id === assignment.teamId);
    const now = new Date().toISOString();

    if (updates.status) assignment.status = updates.status;
    if (updates.rejectionReason) assignment.rejectionReason = updates.rejectionReason;
    if (updates.progressNotes) assignment.progressNotes = updates.progressNotes;
    if (updates.requestedResources) assignment.requestedResources = updates.requestedResources;
    assignment.updatedAt = now;

    if (updates.status && incident && team) {
      if (updates.status === 'Accepted') {
        team.status = 'Assigned';
        incident.statusHistory.push({
          id: `hist_${Date.now()}`,
          incidentId: incident.id,
          status: incident.status,
          note: `${team.name} accepted dispatch order.`,
          actorUid: updates.actorUid,
          actorName: updates.actorName,
          createdAt: now,
        });
      } else if (updates.status === 'Rejected') {
        team.status = 'Available';
        team.currentIncidentId = undefined;
        incident.assignedTeamId = undefined;
        incident.assignedTeamName = undefined;
        incident.status = 'Verified';
        incident.statusHistory.push({
          id: `hist_${Date.now()}`,
          incidentId: incident.id,
          status: 'Verified',
          note: `${team.name} declined assignment: ${updates.rejectionReason || 'Unit unavailable'}.`,
          actorUid: updates.actorUid,
          actorName: updates.actorName,
          createdAt: now,
        });
      } else if (updates.status === 'En Route') {
        team.status = 'En Route';
        incident.status = 'Team En Route';
        incident.statusHistory.push({
          id: `hist_${Date.now()}`,
          incidentId: incident.id,
          status: 'Team En Route',
          note: `${team.name} is en route to incident perimeter.`,
          actorUid: updates.actorUid,
          actorName: updates.actorName,
          createdAt: now,
        });
      } else if (updates.status === 'On Site' || updates.status === 'In Progress') {
        team.status = 'On Site';
        team.lat = incident.lat;
        team.lng = incident.lng;
        incident.status = 'Rescue in Progress';
        incident.etaMinutes = 0;
        incident.statusHistory.push({
          id: `hist_${Date.now()}`,
          incidentId: incident.id,
          status: 'Rescue in Progress',
          note: updates.progressNotes || `${team.name} arrived on site and initiated rescue operations.`,
          actorUid: updates.actorUid,
          actorName: updates.actorName,
          createdAt: now,
        });
      } else if (updates.status === 'Completed') {
        team.status = 'Available';
        team.currentIncidentId = undefined;
        team.incidentsHandled += 1;
        incident.status = 'Resolved';
        incident.statusHistory.push({
          id: `hist_${Date.now()}`,
          incidentId: incident.id,
          status: 'Resolved',
          note: updates.summary || `${team.name} completed rescue operation.`,
          actorUid: updates.actorUid,
          actorName: updates.actorName,
          createdAt: now,
        });

        const report: RescueOperationReport = {
          id: `rep_${Date.now()}`,
          incidentId: incident.id,
          incidentCode: incident.incidentCode,
          assignmentId: assignment.id,
          teamId: team.id,
          teamName: team.name,
          submittedByUid: updates.actorUid,
          submittedByName: updates.actorName,
          summary: updates.summary || assignment.progressNotes || 'Operation completed successfully.',
          peopleRescued: updates.peopleRescued ?? incident.peopleAffected,
          casualtiesTreated: updates.casualtiesTreated ?? incident.injuredCount,
          photoUrls: updates.photoUrls || [],
          createdAt: now,
        };
        this.reports.unshift(report);
        this.emit('report:created', report);
      }

      team.updatedAt = now;
      incident.updatedAt = now;

      this.addNotification({
        targetRole: 'Emergency Operator',
        type: 'team_response',
        title: `${team.name} → ${updates.status}`,
        message: `${incident.incidentCode}: ${updates.progressNotes || updates.rejectionReason || `Status changed to ${updates.status}`}`,
        incidentId: incident.id,
        isDemo: incident.isDemo,
      });

      this.emit('incident:updated', incident);
      this.emit('team:updated', team);
    }

    if (updates.requestedResources && updates.requestedResources.length > 0 && incident) {
      this.addNotification({
        targetRole: 'Emergency Operator',
        type: 'resource_shortage',
        title: `Resource Request from ${assignment.teamName}`,
        message: `Requested for ${incident.incidentCode}: ${updates.requestedResources.join(', ')}`,
        incidentId: incident.id,
        isDemo: incident.isDemo,
      });
    }

    this.emit('assignment:updated', assignment);
    return assignment;
  }

  updateTeamLocation(teamId: string, lat: number, lng: number, status?: RescueTeam['status']): RescueTeam | null {
    const team = this.teams.find((t) => t.id === teamId);
    if (!team) return null;
    team.lat = lat;
    team.lng = lng;
    if (status) team.status = status;
    team.updatedAt = new Date().toISOString();
    this.emit('team:updated', team);
    return team;
  }

  updateResource(
    resourceId: string,
    updates: {
      deltaAvailable?: number;
      availableQuantity?: number;
      assignedIncidentId?: string;
      responsibleTeamId?: string;
      actorUid: string;
      actorName: string;
    }
  ): Resource | null {
    const res = this.resources.find((r) => r.id === resourceId);
    if (!res) return null;

    if (typeof updates.availableQuantity === 'number') {
      res.availableQuantity = Math.max(0, Math.min(res.quantity, updates.availableQuantity));
    } else if (typeof updates.deltaAvailable === 'number') {
      res.availableQuantity = Math.max(0, Math.min(res.quantity, res.availableQuantity + updates.deltaAvailable));
    }

    if (updates.assignedIncidentId !== undefined) {
      res.assignedIncidentId = updates.assignedIncidentId || undefined;
    }
    if (updates.responsibleTeamId !== undefined) {
      res.responsibleTeamId = updates.responsibleTeamId || undefined;
      const team = this.teams.find((t) => t.id === updates.responsibleTeamId);
      res.responsibleTeamName = team?.name;
    }

    if (res.availableQuantity === 0) {
      res.availability = res.assignedIncidentId ? 'Deployed' : 'Unavailable';
    } else if (res.availableQuantity / Math.max(1, res.quantity) <= 0.25) {
      res.availability = 'Low Stock';
      this.addNotification({
        targetRole: 'Emergency Operator',
        type: 'resource_shortage',
        title: `Low Stock Alert: ${res.name}`,
        message: `Only ${res.availableQuantity} of ${res.quantity} units remaining at ${res.locationName}.`,
        isDemo: res.isDemo,
      });
    } else if (res.availableQuantity < res.quantity && res.assignedIncidentId) {
      res.availability = 'Deployed';
    } else {
      res.availability = 'Available';
    }

    res.updatedAt = new Date().toISOString();
    this.addAudit(
      updates.actorUid,
      updates.actorName,
      'UPDATE_RESOURCE',
      'resource',
      res.resourceCode,
      `Available quantity updated to ${res.availableQuantity}/${res.quantity} (${res.availability}).`
    );

    this.emit('resource:updated', res);
    return res;
  }

  markNotificationRead(id: string) {
    const n = this.notifications.find((item) => item.id === id);
    if (n) {
      n.read = true;
      this.emit('notification:updated', n);
    }
    return n;
  }

  markAllNotificationsRead() {
    this.notifications.forEach((n) => {
      n.read = true;
    });
    this.emit('state:sync', this.getState());
  }

  notifyNearbyHospitals(input: {
    incidentId: string;
    hospitalIds?: string[];
    limit?: number;
    notes?: string;
    actorUid: string;
    actorName: string;
  }): HospitalAlert[] {
    const incident = this.incidents.find((i) => i.id === input.incidentId);
    if (!incident) return [];

    const ranked = findNearestHospitals(
      incident.lat,
      incident.lng,
      this.hospitals,
      this.hospitals.length
    );

    const targets =
      input.hospitalIds && input.hospitalIds.length > 0
        ? ranked.filter((h) => input.hospitalIds!.includes(h.id))
        : ranked.slice(0, input.limit || 2);

    const now = new Date().toISOString();
    const createdAlerts: HospitalAlert[] = [];

    for (const hosp of targets) {
      const alreadyExists = this.hospitalAlerts.some(
        (a) => a.incidentId === incident.id && a.hospitalId === hosp.id
      );
      if (alreadyExists) continue;

      const alert: HospitalAlert = {
        id: `ha_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        incidentId: incident.id,
        incidentCode: incident.incidentCode,
        hospitalId: hosp.id,
        hospitalName: hosp.name,
        hospitalAddress: hosp.address,
        hospitalPhone: hosp.emergencyPhone,
        distanceKm: hosp.distanceKm ?? 0,
        status: 'Notified',
        firstAidEtaMinutes: hosp.etaMinutes ?? 8,
        notifiedByUid: input.actorUid,
        notes:
          input.notes ||
          `First-aid dispatch & trauma alert requested for ${incident.category} at ${incident.address}.`,
        isDemo: incident.isDemo,
        createdAt: now,
        updatedAt: now,
      };

      this.hospitalAlerts.unshift(alert);
      createdAlerts.push(alert);
      this.emit('hospital:alert', alert);
    }

    if (createdAlerts.length > 0) {
      const names = createdAlerts.map((a) => a.hospitalName).join(', ');
      this.addNotification({
        targetRole: 'All',
        targetUid: incident.reporterUid,
        type: 'hospital_alert',
        title: `Nearby Hospital Alert Sent (${incident.incidentCode})`,
        message: `Notified ${names} to prepare ER trauma bay & dispatch first aid (${createdAlerts[0].firstAidEtaMinutes} min ETA).`,
        incidentId: incident.id,
        isDemo: incident.isDemo,
      });

      this.addAudit(
        input.actorUid,
        input.actorName,
        'NOTIFY_NEARBY_HOSPITALS',
        'hospital_alert',
        incident.incidentCode,
        `Notified ${names} for first-aid support.`
      );
    }

    return createdAlerts;
  }

  updateHospitalAlertStatus(
    alertId: string,
    status: HospitalAlertStatus,
    actorUid: string,
    actorName: string,
    notes?: string
  ): HospitalAlert | null {
    const alert = this.hospitalAlerts.find((a) => a.id === alertId);
    if (!alert) return null;

    alert.status = status;
    if (notes) alert.notes = notes;
    alert.updatedAt = new Date().toISOString();

    const incident = this.incidents.find((i) => i.id === alert.incidentId);
    this.addNotification({
      targetRole: 'All',
      targetUid: incident?.reporterUid,
      type: 'hospital_alert',
      title: `${alert.hospitalName} → ${status}`,
      message: `${alert.incidentCode}: ${
        status === 'First Aid Dispatched'
          ? `Mobile first-aid paramedic unit en route (~${alert.firstAidEtaMinutes} min ETA).`
          : `Hospital ER trauma bay ready for casualties.`
      }`,
      incidentId: alert.incidentId,
      isDemo: alert.isDemo,
    });

    this.addAudit(
      actorUid,
      actorName,
      'UPDATE_HOSPITAL_ALERT',
      'hospital_alert',
      alert.id,
      `${alert.hospitalName} status updated to ${status} for ${alert.incidentCode}.`
    );

    this.emit('hospital:updated', alert);
    return alert;
  }
}

export const store = new DisasterStore();
